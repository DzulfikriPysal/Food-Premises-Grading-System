<?php
session_start();
if (isset($_SESSION['staffid'])) {
  $_SESSION['directory'] = "notice.php";
$timeout = 5; // Set timeout minutes
$logout_redirect_url = "sessiontimeout.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
  
  
    if ($elapsed_time >= $timeout) {
  
        header("Location: $logout_redirect_url");
    
    }
  else{
    
    $_SESSION['start_time'] = time();
    
  }
}
else{
  
$_SESSION['start_time'] = time(); 
}
}
else{
  header("Location: homepage.php");
}
 
 if(empty($_SESSION['check'])){
      $_SESSION['check'] = 0;

  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>
<body>

<div id="header" style=" height:100px; ">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px;color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px;  "></td>
  </tr>
</table>


</div>

<div id="o-wrapper" class="o-wrapper" style="margin-right:40px;">
<div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
  
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>

  <main class="o-content" style="height:400px;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">
	
	<h1>News and Notice</h1>
       <form name="myform3"  method = "post" action = "viewnews.php">
                
                
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                           
                    
                           <input name = "search" type = "hidden" id="search"
                              value = "Search" style="background-color:#ffc107; color:#FFF; border:none" >
               </form>

               <form name="myform12"  method = "post" action = "addnews.php">
                
                
                  <input name = "searchid12" type = "hidden" 
                           id = "textbox" required >
                           
                    
                           <input name = "search12" type = "hidden" id="search12"
                              value = "Search" style="background-color:#ffc107; color:#FFF; border:none" >
               </form>

 <table width="100%" style="text-align:left" border="0">
  <tr>
    <td><form  method = "post" action = "<?php $_PHP_SELF ?>">
                  <input name = "viewalldata" type = "submit" id="viewbutton"  value = "Refresh" style="background-color:#ffc107; border:none" >
                  
                  
                  <input name = "sbox" type = "text"  size="40"  placeholder="  News title.." id = "namanyay-search-box" onKeyPress="return submitenter(this,event)"   >
                 
                  <input name = "sdata" type = "submit" id="sdata" value = "Search" >
               </form></td>
    <td style="text-align:right;">
    <form  name="bulk_action_form" action="deleteaction.php" method="post" onSubmit="return delete_confirm();"/>
    <input  name = "ayam" onClick="return new_news();" id="c-button--slide-top" type="button" class="ph-button ph-btn-red"  value="&nbsp;&nbsp;Add&nbsp;&nbsp;">
    <form  name="bulk_action_form" action="deleteaction.php" method="post" onSubmit="return delete_confirm();"/>
    <input id="deletebutton"  type="submit" class="ph-button ph-btn-red" name="bulk_delete_submit" value="Delete"/></td>
  </tr>
 
</table>



 <table width="100%" border="0">
  
  <tr>
    <td width="100%">  <?php
    
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

?>

<?php
 if(isset($_POST['viewalldata'])){
    $_SESSION["check"] = 0; 
    $_SESSION["page"] = 0;
    $_GET['page'] = 0;
   }
   
if(isset($_POST['sdata'])){
  $_SESSION["check"] = 1;
  $_SESSION["searchrow"] = $_POST['sbox'];
  $_SESSION["page"] = 0;
  $_GET['page'] = 0;
  ?>
    
    <?php
}


if($_SESSION["check"] == 1){
  
  $value =  $_SESSION["searchrow"];
 
  
    $tbl_name="notice";   
  
  $adjacents = 5;
  
  $query = "SELECT COUNT(*) as num FROM $tbl_name WHERE title LIKE '%$value%'";
  $total_pages = mysql_fetch_array(mysql_query($query));
  $total_pages = $total_pages['num'];
  
  
  $targetpage1 = "notice.php";  
  $limit = 10;                
  
  
  
  
  if(isset($_GET['page']) ) {
         
         $_SESSION["page"] = $_GET['page'];
      
   }else {
          $_SESSION["page"] = $_SESSION["page"];
   }
  
  if($_SESSION["page"]) 
    $start1 = ($_SESSION["page"] - 1) * $limit;       
  else
    $start1 = 0;                
  
  
  $sql = "SELECT * FROM $tbl_name WHERE title LIKE '%$value%' LIMIT $start1, $limit";
  $result = mysql_query($sql);
  
  
  if ($_SESSION["page"] == 0) $_SESSION["page"] = 1;          
  $prev1 = $_SESSION["page"] - 1;             
  $next1 = $_SESSION["page"] + 1;             
  $lastpage1 = ceil($total_pages/$limit);   
  $lpm1 = $lastpage1 - 1;           
  
  
  $pagination = "";
  if($lastpage1 > 1)
  { 
    $pagination.= "<div class=\"pagination\" style=\"height:50px;\">";
    
    if ($_SESSION["page"] > 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";  
    
    
    if ($lastpage1 < 7 + ($adjacents * 2))  
    { 
      for ($counter = 1; $counter <= $lastpage1; $counter++)
      {
        if ($counter == $_SESSION["page"])
        $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
        else
          $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";   
          }
    }
    elseif($lastpage1 > 5 + ($adjacents * 2)) 
    {
      
      if($page1 < 1 + ($adjacents * 2))   
      {
        for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
        {
          if ($counter == $page1)
              $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>"; 
                    
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      else
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
        {
          if ($counter == $page1)
          $pagination.= "<a class='next' onClick='return false;'style='background-color:#999;cursor:default;' href=\"$targetpage1?page=$counter\">$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";           
        }
      }
    }
    
    
    if ($_SESSION["page"] < $counter - 1) 
        $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\" onClick='return false' style='cursor:default'> >> </a>";
    $pagination.= "</div>\n";   
  }
  mysql_close($con);
?>

  <?php
 echo "<div style='height:450px;'>";
  echo '
    <table id="customers" border="0">
        <thead><tr>
            <th style="height:40px;">Title</th>
            <th style="height:40px;">Date</th>
            <th style="height:40px;">View</th>
            <th style="height:40px;"><input type="checkbox" id="checkall" name="select_all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
    if($total_pages > 0){
    while($row = mysql_fetch_array($result))
    {     
      echo '<tr> <td>'  . $row['title'] . '</td>'.
            '<td>'  . $row['datez'] . '</td>'.
            '<td><input id="updatebutton"  type="button" name="'.$row['id'].'" onClick=    
               "reply_click(this.name)"  value="View News"/></td>
            <td align="center">
            <input type="checkbox" name="checked_id[]" class="checkbox" value="'. $row['id'].'"/></td>    
        </tr> ';
  
    }
    }else{
    echo ' <tr><td colspan="5">No records found.</td></tr> '; 
    }
    echo ' </table>';
    echo "</div><br/><br/>";
  ?>
    
  <?php 
}
else if($_SESSION["check"] == 0){



  $tbl_name="notice";   
  
  $adjacents = 5;
  
  $query = "SELECT COUNT(*) as num FROM $tbl_name ";
  $total_pages = mysql_fetch_array(mysql_query($query));
  $total_pages = $total_pages['num'];
  
  
  
  $targetpage1 = "notice.php";  
  $limit = 10;  
  if(isset($_GET['page']) ) {
          $page1 = $_GET['page'];
   }else {
          $page1 = 0;
   }
  if($page1) 
    $start1 = ($page1 - 1) * $limit;      
  else
    $start1 = 0;                
  
  
  $sql = "SELECT * FROM $tbl_name  LIMIT $start1, $limit";
  $result = mysql_query($sql);
  
  
  if ($page1 == 0) $page1 = 1;          
  $prev1 = $page1 - 1;              
  $next1 = $page1 + 1;              
  $lastpage1 = ceil($total_pages/$limit);   
  $lpm1 = $lastpage1 - 1;           
  
  
  $pagination = "";
  if($lastpage1 > 1)
  { 
    $pagination.= "<div class=\"pagination\" style=\"height:18px;\">";
    
    if ($page1 > 1) 
        $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";  
    
    
    if ($lastpage1 < 7 + ($adjacents * 2))  
    { 
      for ($counter = 1; $counter <= $lastpage1; $counter++)
      {
        if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999; cursor:default;'>$counter</a>";
        else
          $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
      }
    }
    elseif($lastpage1 > 5 + ($adjacents * 2)) 
    {
      
      if($page1 < 1 + ($adjacents * 2))   
      {
        for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";       
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";       
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      else
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
      }
    }
    
    
    if ($page1 < $counter - 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='cursor:default;'> >></a>";
    $pagination.= "</div>\n";   
  }
  mysql_close($con);
?>

  <?php
  echo "<div style='height:450px;'>";
  echo '
    <table id="customers" border="0" style="table-layout:fixed; width:100%;">
        <thead><tr>
            <th style="height:40px;width:500px;text-align:center;">Title</th>
            <th style="height:40px;text-align:center;">View</th>
            <th style="height:40px;text-align:center;"><input type="checkbox" id="checkall" name="select_all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
    if($total_pages > 0){
    while($row = mysql_fetch_array($result))
    {     
     
	 echo ' <tr style="text-align:center;"><td width="500px" style="text-overflow: ellipsis; overflow: hidden; white-space:nowrap;">' . $row['title'] . '</td> '; 
	
	 echo ' <td style="text-align:center;"><input id="updatebutton"  type="button" name="'.$row['id'].'" onClick=    
               "reply_click(this.name)"  value="View News"/></td> '; 
	 echo '  <td align="center;"style="text-align:center;">
            <input type="checkbox" style="text-align:center;" name="checked_id[]" class="checkbox" value="'. $row['id'].'"/></td>    
			 '; 
  
    }
    }else{
    echo ' <tr><td colspan="5">No records found.</td></tr> '; 
    }
    echo ' </table>';
    echo "</div><br/><br/>";
    ?>

        <?php
}
?>
</td>

  </tr>
 
</table>

<table width="100%" height="100px" border="0">
  <tr>
    <td><?=$pagination?></td>
  </tr>
</table>


   
</form>   
    


    </div><!-- /o-container -->
  </main><!-- /o-content -->

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
     <div class="top">
          
           
           
           </div>
             <div class="c2">
           </div>
            <div class="c1">
             <?php
          echo "USER : ".$_SESSION["staffid"];
        echo "<br/>MODE : ";
        
            if($_SESSION["mode"] == 2){
                  echo " USER ";
                }
                else{
                  echo " Admin ";
                }
          
          echo "<br/> Last seen : ".$_SESSION['lastseen']."";
       ?>
            
            </div>
           
            <div class="mid">
           <button class="menubutton" id="menubutton" type="button" onclick="" >User Management</button>
           
            <script type="text/javascript">
            document.getElementById("menubutton").onclick = function () {
            location.href = "usermodule.php";
            };
          </script>
            
           <button class="reportbutton" id="reportbutton" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("reportbutton").onclick = function () {
            location.href = "searchform.php";
            };
          </script>
            <button class="reportbutton" id="myinfo" type="button" onclick="">myinfo</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo.php";
            };
          </script>

          
          </script>
            
            
              <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="logout">
            </form>
            
            
           <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
             if(result){
          return true;
             }else{
              return false;
             }
            };
          </script>
           
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
           </div>
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  



  function reply_click(clicked_id)
{
   
  document.myform3.searchid.value = clicked_id;
  document.forms["myform3"].submit();
  document.getElementById("search").click();
  
}

 function new_news(clicked_id)
{
   
  document.myform12.searchid12.value = clicked_id;
  document.forms["myform12"].submit();
  document.getElementById("search12").click();
  
}



function delete_confirm(){
  var result = confirm("Are you sure to delete Notice?");
  if(result){
    return true;
  }else{
    return false;
  }
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
  
  $('.checkbox').on('click',function(){
    if($('.checkbox:checked').length == $('.checkbox').length){
      $('#select_all').prop('checked',true);
    }else{
      $('#select_all').prop('checked',false);
    }
  });
});

  

</script>


</script>

</body>
</html>