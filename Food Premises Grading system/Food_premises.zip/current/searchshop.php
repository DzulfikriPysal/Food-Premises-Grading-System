
 <html>
         
         <head>
           <link rel="stylesheet" href="css2.css">
           <link rel="stylesheet" href="css3.css">
           <link rel="stylesheet" href="css1.css">
           <link rel="stylesheet" href="css4.css">
            <script type = "text/javascript" 
         src = "jquery.js"></script>
            <style>
  a {
    color: black;
    padding: 4px 4px;
    text-decoration: none;
    border-radius: 3px;
}
  </style>
         </head>
         
         <body>
         
          
         
          <form name="myformz" target='_parent'  method = "post" action = "addreport.php">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                           
                           <input name = "search321" type = "hidden" id="search" 
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>
               
                <form name="myformx" target='_parent'  method = "post" action = "viewreport.php">
                  <input name = "searchid2" type = "hidden" id = "textbox" required >
                    
                  <input name = "search2" type = "hidden" id="search"  value = "Search" style="background-color:#ffc107; border:none" >
               </form>
         
         <table width="990px" border="0" style="float:left; top:31px; position:absolute; padding-right:5px;  margin-top:5px; border-collapse:collapse;">
  <tr>
    <td >        
         
         </td>
          <td width="98px">     
           <form  name="" action="" method="post" onSubmit=""/>   
           <input name = "searchidx" type = "button" id = "viewbutton" value="Add grading" onClick="grading();">
           </form>
           
           <script>
		   function grading(){
	          parent.addgrading();
           }

		   
		   </script>
         
         </td>
        
    <td width="200px">
           <form  name="bulk_action_form" action="action5.php" method="post" onSubmit="return delete_confirm();"/>   
           <input style="margin-left:3px" id="viewbutton" type="submit" class="ph-button ph-btn-red" name="bulk_delete_submit" value="Delete" />
           <input name = "searchidx" type = "button" id = "viewbutton"  value="Cancel" onClick="closepopup();">
         
      </td>
  </tr>
</table>
<br/><br/><br/>

<table width="50px" height="300px" border="0" style="position:absolute; margin-top:20px;">
  <tr>
    <td><?php
session_start();	
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

?>
<?php
if(isset($_POST['delete1'])){
	echo "<script>document.getElementById('viewbutton').click();</script>";
}


 if(isset($_POST['search'])){
		$_SESSION["check1"] = 0; 
		$_SESSION["page1"] = 0;
		$_GET['page1'] = 0;
		$sid1 =  $_POST['searchid'];
	    $_SESSION['sid1'] = $sid1;
	 }
	  if(isset($_POST['viewalldata'])){
		$_SESSION["check1"] = 0; 
		$_SESSION["page1"] = 0;
		$_GET['page1'] = 0;
	 }
	 
if(isset($_POST['sdata'])){
	$_SESSION["check1"] = 1;
	$_SESSION["searchrow"] = $_POST['sbox'];
	$_SESSION["sdown"] = $_POST['sdown'];
	$_SESSION["page1"] = 0;
	$_GET['page1'] = 0;
	?>
    
    <?php
}

if($_SESSION["check1"] == 1){
	
	$tbl_name="premisesdetail";	
	$sid1 = $_SESSION['sid1'];
	$searchrow = $_SESSION['searchrow'];
	$sdown = $_SESSION['sdown'];
	
	$adjacents = 5;
	
	if( $searchrow == ""){
		$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE connection_id = '$sid1' ";
	}
	else{
		$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE connection_id = '$sid1' AND ".$sdown." LIKE '%$searchrow%' ";
	}
	
	
	$total_page1s = mysql_fetch_array(mysql_query($query));
	$total_page1s = $total_page1s['num'];
	
	
	
	$targetpage11 = "searchshop.php"; 	
	$limit = 7; 	
	if(isset($_GET['page1']) ) {
          $page11 = $_GET['page1'];
   }else {
          $page11 = 0;
   }
	if($page11) 
		$start1 = ($page11 - 1) * $limit; 			
	else
		$start1 = 0;								
	
	
	
	if( $searchrow == ""){
		
		$sql = "SELECT * FROM $tbl_name WHERE connection_id = '$sid1' LIMIT $start1, $limit";
	}
	else{
		$sql = "SELECT * FROM $tbl_name WHERE connection_id = '$sid1' AND ".$sdown." LIKE '%$searchrow%' LIMIT $start1, $limit";
	}
	$result = mysql_query($sql);
	
	
	if ($page11 == 0) $page11 = 1;					
	$prev1 = $page11 - 1;							
	$next1 = $page11 + 1;							
	$lastpage11 = ceil($total_page1s/$limit);		
	$lpm1 = $lastpage11 - 1;						
	
	
	$pagination = "";
	if($lastpage11 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px; text-align:center; \">";
		
		if ($page11 > 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$prev1\"> << </a>";
		else
			$pagination.= "<span class=\"disabled\"> << </span>";	
		
		
		if ($lastpage11 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage11; $counter++)
			{
				if ($counter == $page11)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage11 > 5 + ($adjacents * 2))	
		{
			
			if($page11 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			elseif($lastpage11 - ($adjacents * 2) > $page11 && $page11 > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page11 - $adjacents; $counter <= $page11 + $adjacents; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			else
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage11 - (2 + ($adjacents * 2)); $counter <= $lastpage11; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($page11 < $counter - 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$next1\"> >> </a>";
		else
			$pagination.= "<span class=\"disabled\"> >> </span>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
?>

	<?php
	echo "<div style='height:240px;  '>";
	echo '
    <table id="customers" style="width:970px;">
        <thead><tr>
           <th>No siri Borang</th>
			<th>Nama Syarikat</th>
			<th>Tarikh</th>
            <th style="text-align:center">View Detail</th>
            <th style="text-align:center">Update</th>
            <th><input type="checkbox" id="checkall" name="select_all" id="select_all" value=""/></th>     
         
        </tr>
        </thead>';
		if($total_page1s > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>' . $row['nosiriborang'] . '</td>'.
	       '<td>'  . $row['namasyarikat'] . '</td>'.
		   '<td>'  . $row['tarikh'] . '</td>'.
		   
		     '
		   
	       <td style="text-align:center;"> <input id="viewdetail" type="button" name="'.$row['nosiriborang'].'" onClick=    
               "viewrecord(this.name)"  value="View Detail"/>
            
            
            </td>
            <td style="text-align:center;"><input id="updatebutton"type="button" name="'.$row['nosiriborang'].'" onClick=    
               "update(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" name="checked_id[]" class="checkbox" value="'. $row['nosiriborang'].'"/></td>    
          </tr> ';
	
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		}
		echo ' </table>';
		echo "</div><br/><br/><br/>";
		?>
       
        <?php
}
 if($_SESSION["check1"] == 0){
	    

	$tbl_name="premisesdetail";	
	$sid1 = $_SESSION['sid1'];
	
	$adjacents = 5;
	
	$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE connection_id = '$sid1' ";
	$total_page1s = mysql_fetch_array(mysql_query($query));
	$total_page1s = $total_page1s['num'];
	
	
	
	$targetpage11 = "searchshop.php"; 	
	$limit = 7; 	
	if(isset($_GET['page1']) ) {
          $page11 = $_GET['page1'];
   }else {
          $page11 = 0;
   }
	if($page11) 
		$start1 = ($page11 - 1) * $limit; 			
	else
		$start1 = 0;								
	
	
	$sql = "SELECT * FROM $tbl_name WHERE connection_id = '$sid1' LIMIT $start1, $limit";
	$result = mysql_query($sql);
	
	
	if ($page11 == 0) $page11 = 1;					
	$prev1 = $page11 - 1;							
	$next1 = $page11 + 1;							
	$lastpage11 = ceil($total_page1s/$limit);		
	$lpm1 = $lastpage11 - 1;						
	
	
	$pagination = "";
	if($lastpage11 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px; text-align:center; \">";
		
		if ($page11 > 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$prev1\"> << </a>";
		else
			$pagination.= "<span class=\"disabled\"> << </span>";	
		
		
		if ($lastpage11 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage11; $counter++)
			{
				if ($counter == $page11)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage11 > 5 + ($adjacents * 2))	
		{
			
			if($page11 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			elseif($lastpage11 - ($adjacents * 2) > $page11 && $page11 > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page11 - $adjacents; $counter <= $page11 + $adjacents; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			else
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage11 - (2 + ($adjacents * 2)); $counter <= $lastpage11; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($page11 < $counter - 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$next1\"> >> </a>";
		else
			$pagination.= "<span class=\"disabled\"> >> </span>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
?>

	<?php
	echo "<div style='height:300px; '>";
	echo '
    <table id="customers" style="width:970px;">
        <thead><tr>
           <th>No siri Borang</th>
			<th>Nama Syarikat</th>
			<th>Tarikh</th>
            <th style="text-align:center">View Detail</th>
            <th style="text-align:center">Update</th>
            <th><input type="checkbox" id="checkall" name="select_all" id="select_all" value=""/></th>     
         
        </tr>
        </thead>';
		if($total_page1s > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>' . $row['nosiriborang'] . '</td>'.
	       '<td>'  . $row['namasyarikat'] . '</td>'.
		   '<td>'  . $row['tarikh'] . '</td>'.
		   
		     '
		   
	       <td style="text-align:center;"> <input id="viewdetail" type="button" name="'.$row['nosiriborang'].'" onClick=    
               "viewrecord(this.name)"  value="View Detail"/>
            
            
            </td>
            <td style="text-align:center;"><input id="updatebutton" type="button" name="'.$row['nosiriborang'].'" onClick=    
               "update(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" name="checked_id[]" class="checkbox" value="'. $row['nosiriborang'].'"/></td>    
          </tr> ';
	
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		}
		echo ' </table>';
		echo "</div><br/><br/><br/>";
		?>
        <?php
}

 echo '</div>
</form>';  
?></td>
  </tr>
</table>

<table width="97%" height="50px" border="0" style="position:absolute; top:470px;">
  <tr>
    <td> <?=$pagination?></td>
  </tr>
</table>


              
   
               
        
 
 
 
        <script>
        function viewrecord(clicked_id)
              {
                   document.myformz.searchid.value = clicked_id;
                   document.forms["myformz"].submit();
                   document.getElementById("search321").click();
				   
               }
			   
		function update(clicked_id)
              {
                   document.myformx.searchid2.value = clicked_id;
                   document.forms["myformx"].submit();
                   document.getElementById("search2").click();
				   
               }
			   
			   
			   
			   
			   
			   
			   

  function delete_confirm(){
	var result = confirm("Are you sure to delete report?");
	if(result){
		return true;
	}else{
		return false;
	}
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
	
	$('.checkbox').on('click',function(){
		if($('.checkbox:checked').length == $('.checkbox').length){
			$('#select_all').prop('checked',true);
		}else{
			$('#select_all').prop('checked',false);
		}
	});
});


function closepopup(){
	parent.guestFromPop();
}

   $("#checkall").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
	

         </script>
         
         
         
          </body>
         </html>
         
         