<?php
session_start();
?>

<HTML>
<HEAD>
<TITLE>List BLOB Images</TITLE>
<link href="imageStyles.css" rel="stylesheet" type="text/css" />
</HEAD>
<BODY>

<?php
$id = $_SESSION["staffid"];
echo $id;

echo '<img height="50px" width="50px" src="openimage.php?show={$id}"  alt="haha" /><br/>';
?>

</BODY>
</HTML>