<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
$_SESSION['directory'] = "updaterecord.php";
$timeout = 15;
$logout_redirect_url = "sessiontimeout.php"; 

$timeout = $timeout * 60;

if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
    <link rel="stylesheet" href="css3.css">
    <link rel="stylesheet" href="css4.css">
    <link rel="stylesheet" type="text/css" media="print" href="print.css" />
    <script type = "text/javascript" 
         src = "jquery.js"></script>
        
      <script type = "text/javascript" 
         src = "jquery-ui.js"></script>
    
    
</head>

<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button" ><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; color:#FFF;">View Report</td>
  </tr>
</table>

</div>
<div id="o-wrapper" class="o-wrapper" >

 <div style="width:100%; height:60px; float:left">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content">
      <div class="dummy1"><h1></h1></div>
     
    <div class="o-container" style="width:80%; height:1300px; text-align:start;">
    
        <?php
	define('DB_HOST', 'localhost');
    define('DB_NAME', 'premises');
    define('DB_USER','root');
    define('DB_PASSWORD','');
    $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
    $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
   
    if(isset($_POST["search"])){
	
	


		 $sid =  $_POST['searchid'];
	     $_SESSION['sid'] = $sid;
	     $query = mysql_query("SELECT * FROM premisesdetail
		                       LEFT JOIN premisesowner 
							   ON premisesdetail.namasyarikat = premisesowner.premisesname
							   where premisesdetail.nosiriborang = '$sid'") or die(   mysql_error());
		 $row = mysql_fetch_array($query);
		
       

mysql_close($con);
	
	
	
	$searchid = $_POST['searchid'];
	$totala = $row['totala'];
$totalb = $row['totalb'];
$totalc = $row['totalc'];
$totald = $row['totald'];
$totale = $row['totale'];
$totalf = $row['totalf'];
$totalg = $row['totalg'];
$total = 100 - ($totala + $totalb + $totalc + $totald + $totale + $totalf + $totalg);
	
	

	?>
     <div id="aa" >
      <div id="bb">
        <table width="100%" border="0">
  <tr>
    <td>mark : </td>
    <td><input type="text" name="currentmark" id="currentmark" value="<?php echo $total ?>" readonly/></td>
  </tr>
  <tr>
    <td>grade : </td>
    <td><input type="text" name="currentgrade" id="currentgrade"  value="<?php echo $row['grade']; ?>" readonly/></td>
  </tr>
</table>
     </div>
       <div id="printweb" style="cursor:pointer;"></div>
       
   <input type="button" id="backbutton" style="float:right; margin-right:5px; top:50px; margin-top:70px; cursor:pointer;"  value="cancel"/>
   
   <script type="text/javascript">
            document.getElementById("backbutton").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
   </div>
      
            

   
<div id="flip" style=" width:45px; height:30px;cursor:pointer; background-image:url(up.jpg); background-size: contain; background-repeat:no-repeat;">
</div>
<div id="oppai">
  

    <ul class="pagination" style="position:absolute; right:0px; top:0px;">
        <li> <a style="cursor:pointer;" onclick="form1();">A</a></li>
        <li><a style="cursor:pointer" onclick="form2();">B</a></li>
        <li><a style="cursor:pointer" onclick="form3();">C</a></li>
        <li><a style="cursor:pointer" onclick="form4();">D</a></li>
        <li><a style="cursor:pointer" onclick="form5();">E</a></li>
        <li><a style="cursor:pointer" onclick="form6();">F</a></li>
        <li><a style="cursor:pointer" onclick="form7();">G</a></li>
 </ul>   
    
     <div id="pantsu">

   </div>
</div>

    
    
    

    
    

 











<form name="myform" method = "post" action = "" >
   <h1 style="text-align:center">Borang Pemeriksaan Dan Penggredan Premis Makanan</h1>
   
    <table width="90%" border="0">
  <tr>
    <td style="text-align:start;">Serial Number</td>
    <td><input id="boxx" name="nosiriborang"  readonly type="text" value="<?php echo $row['nosiriborang'] ?>"></td>
   
  </tr>
  <tr>
    <td style="text-align:start;">Owner Name</td>
    <td><input id="boxx" type="text" name="ownername" readonly value='<?php echo $row['namepelesen'] ?>' ></td>
    <td style="text-align:start;">Licence Reference No</td>
    <td><input id="boxx" type="text"name="refno" value="<?php echo $row['norujlesen'] ?>" readonly></td>
  </tr>
  <tr>
    <td style="text-align:start;">Company Name</td>
    <td><input id="boxx" type="text" name="companyname"  readonly value='<?php echo $row['premisesname'] ?>'></td>
    <td style="text-align:start;">Date</td>
    <td><input id="boxx" type="text" name="date"  value="<?php echo $row['tarikh'] ?>" readonly></td>
  </tr> 
 
  <tr>
    <td style="text-align:start;">Phone Number</td>
    <td><input id="boxx" type="text" name="phone" readonly value='<?php echo $row['notel'] ?>'>
   </td>
    <td style="text-align:start;">Time</td>
    <td style="text-align:start;"><input id="boxx" type="text" style="width: 100px;" value="<?php echo $row['masamula'] ?>" placeholder="Start" name="tstart"  readonly> <input type="text" placeholder="End" style="width: 100px;" name="tend" value="<?php echo $row['masatamat'] ?>" id="boxx" readonly></td>
  </tr>
  <tr>
 
    <td style="text-align:start;">Owner Licence No</td>
    <td><input type="text" id="boxx" name="ownerlicence"  readonly value='<?php echo $row['nokppelesen'] ?>'></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="text-align:start;">Address</td>
    <td><textarea  cols="25" id="boxx" rows="4" name="address" readonly><?php echo $row['address'] ?></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td style="text-align:start;">Pengendali</td>
    <td >Bil Pengendali&nbsp;&nbsp;&nbsp;<input type="text" style="width:50px; text-align:center;" id="boxx" name="bilpengendali"  readonly value='<?php echo $row['bilpengendali'] ?>'>
    </td> <?php
	
	$_SESSION["info1"] = $row['nosiriborang'];
	$_SESSION["info2"] = $row['namepelesen'];
	$_SESSION["info3"] = $row['norujlesen'];
	$_SESSION["info4"] = $row['premisesname'];
	$_SESSION["info5"] = $row['tarikh'];
	$_SESSION["info6"] = $row['notel'];
	$_SESSION["info7"] = $row['masamula'];
	$_SESSION["info8"] = $row['masatamat'];
	$_SESSION["info9"] = $row['nokppelesen'];
	$_SESSION["info10"] = $row['address'];
	$_SESSION["info11"] = $row['bilpengendali'];
	
	          date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i:s.u");
			  
			  $_SESSION["timeprint"] = $a;
	
	if($row['suntikanpelali'] == 0){
		$_SESSION["info12"] = "None";
	}
	else{
		$_SESSION["info12"] = "/";
	}
	
	if($row['kursuspengendali'] == 0){
		$_SESSION["info13"] = "None";
	}
	else{
		$_SESSION["info13"] = "/";
	}
	
	//textarea
	$_SESSION["ta1"] = $row['ta1'];
	$_SESSION["ta2"] = $row['ta2'];
	$_SESSION["ta3"] = $row['ta3'];
	$_SESSION["ta4"] = $row['ta4'];
	$_SESSION["ta5"] = $row['ta5'];
	$_SESSION["tb1"] = $row['tb1'];
	$_SESSION["tb2"] = $row['tb2'];
	$_SESSION["tb3"] = $row['tb3'];
	$_SESSION["tb4"] = $row['tb4'];
	$_SESSION["tc1"] = $row['tc1'];
	$_SESSION["tc2"] = $row['tc2'];
	$_SESSION["td1"] = $row['td1'];
	$_SESSION["td2"] = $row['td2'];
	$_SESSION["td3"] = $row['td3'];
	$_SESSION["te1"] = $row['te1'];
	$_SESSION["te2"] = $row['te2'];
	$_SESSION["te3"] = $row['te3'];
	$_SESSION["tf1"] = $row['tf1'];
	$_SESSION["tf2"] = $row['tf2'];
	$_SESSION["tf3"] = $row['tf3'];
	$_SESSION["tf4"] = $row['tf4'];
	$_SESSION["tg1"] = $row['tg1'];
	$_SESSION["tg2"] = $row['tg2'];
	$_SESSION["tg3"] = $row['tg3'];
	$_SESSION["tg4"] = $row['tg4'];
	$_SESSION["tg5"] = $row['tg5'];
	$_SESSION["tg6"] = $row['tg6'];
	$_SESSION["tg7"] = $row['tg7'];
	$_SESSION["tg8"] = $row['tg8'];
	
	//mark
	$_SESSION["totala"] = $row['totala'];
	$_SESSION["totalb"] = $row['totalb'];
	$_SESSION["totalc"] = $row['totalc'];
	$_SESSION["totald"] = $row['totald'];
	$_SESSION["totale"] = $row['totale'];
	$_SESSION["totalf"] = $row['totalf'];
	$_SESSION["totalg"] = $row['totalg'];
	
	//dropdown
	$_SESSION["a1"] = $row['a1'];
	$_SESSION["b1_1"] = $row['b1_1'];
	$_SESSION["c1_1"] = $row['c1_1'];
	$_SESSION["g1"] = $row['g1'];
	
	//checkbox
	$_SESSION["a2_1"] = $row['a2_1'];
	$_SESSION["a2_2"] = $row['a2_2'];
	$_SESSION["a2_3"] = $row['a2_3'];
	$_SESSION["a2_4"] = $row['a2_4'];
	$_SESSION["a3_1"] = $row['a3_1'];
	$_SESSION["a3_2"] = $row['a3_2'];
	$_SESSION["a3_3"] = $row['a3_3'];
	$_SESSION["a4_1"] = $row['a4_1'];
	$_SESSION["a4_2"] = $row['a4_2'];
	$_SESSION["a4_3"] = $row['a4_3'];
	$_SESSION["a5_1"] = $row['a5_1'];
	$_SESSION["a5_2"] = $row['a5_2'];
	$_SESSION["a6"] = $row['a6'];
	
	$_SESSION["b2_1"] = $row['b2_1'];
	$_SESSION["b2_2"] = $row['b2_2'];
	$_SESSION["b3_1"] = $row['b3_1'];
	$_SESSION["b3_2"] = $row['b3_2'];
	$_SESSION["b4_1"] = $row['b4_1'];
	$_SESSION["b4_2"] = $row['b4_2'];
	
	$_SESSION["c2_1"] = $row['c2_1'];
	$_SESSION["c2_2"] = $row['c2_2'];
	$_SESSION["c2_3"] = $row['c2_3'];
	$_SESSION["c2_4"] = $row['c2_4'];
	$_SESSION["c2_5"] = $row['c2_5'];
	$_SESSION["c2_6"] = $row['c2_6'];
	$_SESSION["c3"] = $row['c3'];
	
	$_SESSION["d1_1"] = $row['d1_1'];
	$_SESSION["d1_2"] = $row['d1_2'];
	$_SESSION["d2_1"] = $row['d2_1'];
	$_SESSION["d2_2"] = $row['d2_2'];
	$_SESSION["d3"] = $row['d3'];
	
	$_SESSION["e1_1"] = $row['e1_1'];
	$_SESSION["e1_2"] = $row['e1_2'];
	$_SESSION["e1_3"] = $row['e1_3'];
	$_SESSION["e1_4"] = $row['e1_4'];
	$_SESSION["e1_5"] = $row['e1_5'];
	$_SESSION["e1_6"] = $row['e1_6'];
	$_SESSION["e2_1"] = $row['e2_1'];
	$_SESSION["e2_2"] = $row['e2_2'];
	$_SESSION["e2_3"] = $row['e2_3'];
	$_SESSION["e3_1"] = $row['e3_1'];
	$_SESSION["e3_2"] = $row['e3_2'];
	$_SESSION["e3_3"] = $row['e3_3'];
	
	
	$_SESSION["f1_1"] = $row['f1_1'];
	$_SESSION["f1_2"] = $row['f1_2'];
	$_SESSION["f1_3"] = $row['f1_3'];
	$_SESSION["f1_4"] = $row['f1_4'];
	$_SESSION["f1_5"] = $row['f1_5'];
	$_SESSION["f2_1"] = $row['f2_1'];
	$_SESSION["f2_2"] = $row['f2_2'];
	$_SESSION["f3_1"] = $row['f3_1'];
	$_SESSION["f3_2"] = $row['f3_2'];
	$_SESSION["f4_1"] = $row['f4_1'];
	$_SESSION["f4_2"] = $row['f4_2'];
	
	$_SESSION["g2"] = $row['g2'];
	$_SESSION["g3"] = $row['g3'];
	$_SESSION["g4_1"] = $row['g4_1'];
	$_SESSION["g4_2"] = $row['g4_2'];
	$_SESSION["g4_3"] = $row['g4_3'];
	$_SESSION["g5"] = $row['g5'];
	$_SESSION["g6"] = $row['g6'];
	$_SESSION["g7"] = $row['g7'];
	$_SESSION["g8_1"] = $row['g8_1'];
	$_SESSION["g8_2"] = $row['g8_2'];
	$_SESSION["g8_3"] = $row['g8_3'];
	
	
	
	 
	?>
    <td>
        <input type="hidden" value="0" name="tibid">
        Suntikan pelalian ANTI Tibid<input value="1" type="checkbox" onclick="return false" name="tibid" <?php echo ($row['suntikanpelali']==1 ? 'checked' : '');?>>
        
        
    </td>
    <td>
        <input type="hidden" value="0" name="kursus">
        Kursus pengendali makanan<input value="1" type="checkbox"  name="kursus" onclick="return false" <?php echo ($row['kursuspengendali']==1 ? 'checked' : '');?>>
    </td>
  </tr>
</table>


<div class="page-break"></div>
<div id="frame1" style="display:block;">
  <table id="A" width="100%" border="1">
  <tr>
    <th id="showprint"  scope="col">Perkara</th>
    <th id="showprint"  scope="col">Komponen</th>
    <th id="showprint"  scope="col">Markah</th>
    <th id="showprint"  scope="col">Demerit</th>
    <th id="showprint"  scope="col">Catatan</th>
  </tr>
  <tr>
    <td>A Kawasan penyediaan makanan</td>
    <td>A1 Kawasan Suhu Penyimpanan Dan Penyediaan Makanan <br/>
        Peti sejuk <br/>
        &#9899; Suhu sejuk -18c hingga 0c</td>
    <td style="text-align:center">12</td>
   
    <td style="text-align:center">
    <?php
	echo $row['a1'];
	?></td>
    <td style="text-align:center">CCP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A2 Kawalan serangga perosak / LILATI yang efektif termasuk kawalan<br/>
        &#9899; lipas<br/>
        &#9899; lalat<br/>
        &#9899; tikus<br/>
        &#9899; lain lain haiwan<br/></td>
    <td style="text-align:center"><br/><br/>
        1<br/>
        1<br/>
        1<br/>
        1<br/></td>
    <td style="text-align:center"><br><br>
    
    
         <?php if( $row['a2_1'] == 1) 
		       {echo $row['a2_1']; } ?><br>
       <?php if( $row['a2_2'] == 1) 
		       {echo $row['a2_2']; } ?><br>
        <?php if( $row['a2_3'] == 1) 
		       {echo $row['a2_3']; } ?><br>
        <?php if( $row['a2_4'] == 1) 
		       {echo $row['a2_4']; } ?><br></td>
    <td><textarea  cols="25" rows="7 " id="boxx" name="ta1"readonly ><?php echo $row["ta1"];  ?></textarea>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A3 kebersihan peti sejuk<br/>
        &#9899; peti sejuk sentiasa bersih<br/>
        &#9899; susunan makanan dalam keadaan teratur<br/>
        &#9899; tiada pencemaran silang<br/></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        1</td>
    <td style="text-align:center"><br>
        <?php if( $row['a3_1'] == 1) 
		       {echo $row['a3_1']; } ?><br>
        <?php if( $row['a3_2'] == 1) 
		       {echo $row['a3_2']; } ?><br>
        <?php if( $row['a3_3'] == 1) 
		       {echo $row['a3_3']; } ?><br></td>
    <td><textarea cols="25" name="ta2" rows="5" id="boxx" readonly><?php echo $row["ta2"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A4 Kebersihan peralatan dan kemudahan memasak<br />
        &#9899; alas memotong dan kain pengelap dalam keadaan bersih<br />
        &#9899; dilarang mengunakan kertas bercetak yang bersentuhan dengan makanan<br />
        &#9899; peralatan kulinari sentiasa dalam keadaan baik dan bersih<br /></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        <br />
        1</td>
    <td style="text-align:center"><br>
        <?php if( $row['a4_1'] == 1) 
		       {echo $row['a4_1']; } ?><br>
        <?php if( $row['a4_2'] == 1) 
		       {echo $row['a4_2']; } ?><br><br>
        <?php if( $row['a4_3'] == 1) 
		       {echo $row['a4_3']; } ?><br></td>
    <td><textarea cols="25" rows="5" name="ta3" id="boxx" readonly><?php echo $row["ta1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A5 Sistem pelepasan asap dan haba<br/>
        &#9899; Berfungsi dengan baik serta tidak menimbulkan kacauganggu<br/>
        &#9899; kapasiti yang mencukupi dan efisyen<br/></td>
    <td style="text-align:center"><br />1<br />1</td>
    <td style="text-align:center"><br>
        <?php if( $row['a5_1'] == 1) 
		       {echo $row['a5_1']; } ?><br>
        <?php if( $row['a5_2'] == 1) 
		       {echo $row['a5_2']; } ?><br></td>
    <td><textarea cols="25" name="ta4" rows="5"id="boxx" readonly><?php echo $row["ta4"];  ?></textarea></td>
  </tr>
  
   <tr>
    <td>&nbsp;</td>
    <td>A6 Ruang kelegaan di antara peralatan dan dinding/lantai<br />
        &#9899; jarak minima yang sesuai untuk penyelenggaraan dan tiada kesesakan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
        <?php if( $row['a6'] == 1) 
		       {echo $row['a6']; } ?></td>
    <td><textarea cols="25" name="ta5" rows="5" id="boxx" readonly><?php echo $row["ta5"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">25</td>
    <td style="text-align:center"><?php echo $totala; ?></td>
    <td></td>
  </tr>
</table>

</div>

<div id="frame2" style="display:none;">
 <table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>B<br/>
        Kawasan penyajian makanan   
    </td>
    <td>B1. kawalan suhu dan tempat mempamerkan makanan yang sesuai <br/> 
        mengikut keadaan dan jenis makanan<br/>
        &#9899; suhu makanan panas >60c<br/>
        &#9899; suhu makanan dingin 1c hingga 4c<br/>
        &#9899; suhu makanan sejuk beku < - 18c</td>
    <td style="text-align:center">12</td>
    <td style="text-align:center">
    <?php
	echo $row["b1_1"];
	
	?>
    </td>
    <td><textarea cols="25" name="tb1" rows="5" id="boxx" readonly><?php echo $row["tb1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B2 peralatan kulinari yang digunakan untuk penyajian  makanan<br/>
        perlu sentiasa dalam keadaan.<br/>
        &#9899; bersih<br/>
        &#9899; tidak sumbing, retak or karat</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <?php if( $row['b2_1'] == 1) 
		       {echo $row['b2_1']; } ?><br/>
                  <?php if( $row['b2_2'] == 1) 
		       {echo $row['b2_2']; } ?></td>
    <td><textarea cols="25" name="tb2" rows="5" id="boxx" readonly><?php echo $row["tb2"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B3 KAIN PENGELAP ALAS DAN PERALATAN<BR/>
        perlu sentiasa dalam keadaan<br/>
        &#9899; Bersih<br/>
        &#9899; digunakan berasingan mengikut jenis kerja</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <?php if( $row['b3_1'] == 1) 
		       {echo $row['b3_1']; } ?><br/>
                   <?php if( $row['b3_2'] == 1) 
		       {echo $row['b3_2']; } ?></td>
    <td><textarea cols="25" name="tb3" rows="5" id="boxx" readonly><?php echo $row["tb3"];  ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td>B4 meja kerusi dan peralatan hendak lah<br/>
        sentiasa<br/>
        &#9899; Bersih<br/>
        &#9899; sempurna dan selamat
        </td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <?php if( $row['b4_1'] == 1) 
		       {echo $row['b4_1']; } ?><br/>
                  <?php if( $row['b4_2'] == 1) 
		       {echo $row['b4_2']; } ?></td>
    <td><textarea cols="25" name="tb4" rows="5" id="boxx" readonly><?php echo $row["tb4"];  ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">18</td>
    <td style="text-align:center"><?php echo $totalb; ?></td>
    <td></td>
  </tr>
</table>

</div>

<div id="frame3" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>C<br/>pengendali makanan</td>
    <td>C1 pemeriksa kesihatan ke atas semua pengendali makanan<br/>
         &#9899; menadapat suntikan pelalian anti tifoid<br/>
         &#9899; menghadiri kursus pengendali makanan</td>
    <td style="text-align:center">6</td>
    <td style="text-align:center">
    <?php
	echo $row["c1_1"];
	
	?>
    </td>
    <td>CPP</td>
  </tr>
  <div class="page-break"></div>
  <tr>
    <td>&nbsp;</td>
    <td>C2 tahap kebersihan diri yang baik<br/>
        &#9899; berpakaian bersih dan sesuai<br/>
        &#9899; memakai apron yang bersih dan berpenutup kepala<br/>
        &#9899; berkuku pendek bersih dan tidak memakai barang perhiasan diri<br/>
        &#9899; berkasut<br/>
        &#9899; tidak merokok<br/>
        &#9899; tidak melakukan apa apa perbuatan atau tindakan yang boleh <br/>
        menyebabkan pencemaran makanan </td>
    <td style="text-align:center">1<br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center"> 
         <?php if( $row['c2_1'] == 1) 
		       {echo $row['c2_1']; } ?><br/><?php if( $row['c2_2'] == 1) 
		       {echo $row['c2_2']; } ?><br/><?php if( $row['c2_3'] == 1) 
		       {echo $row['c2_3']; } ?><br/><?php if( $row['c2_4'] == 1) 
		       {echo $row['c2_4']; } ?><br/><?php if( $row['c2_5'] == 1) 
		       {echo $row['c2_5']; } ?><br/><?php if( $row['c2_6'] == 1) 
		       {echo $row['c2_6']; } ?></td>
    <td><textarea cols="25" name="tc1" id="boxx" rows="5" readonly><?php echo $row["tc1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C3 tiada masalah kesihatan yang berkaitan dengan pencemaran makanan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
         <?php if( $row['c3'] == 1) 
		       {echo $row['c3']; } ?></td>
    <td><textarea cols="25" name="tc2" id="boxx" rows="5" readonly><?php echo $row["tc2"];  ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">13</td>
    <td style="text-align:center"><?php echo $totalc; ?></td>
    <td></td>
  </tr>
</table>
</div>
<div id="frame4" style="display:none;">

<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>D<br/>sistem bekalan air</td>
    <td>D1 Sumber Bekalan air yg selamat<br/>
         &#9899; Terawat<br/>
         &#9899; berih dan mencukupi</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
              <?php if( $row['d1_1'] == 1) 
		       {echo $row['d1_1']; } ?><br/>
             <?php if( $row['d1_2'] == 1) 
		       {echo $row['d1_2']; } ?></td>
    <td><textarea cols="25" name="td1" id="boxx" rows="5" readonly><?php echo $row['td1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D2 pengunaan sumber bekalan air<br/>
        &#9899; diambil terus dari paip<br/>
        &#9899; dilarang penggunaan paip getah </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
           <?php if( $row['d2_1'] == 1) 
		       {echo $row['d2_1']; } ?><br/>
           <?php if( $row['d2_2'] == 1) 
		       {echo $row['d2_2']; } ?></td>
    <td><textarea cols="25" name="td2" id="boxx" rows="5" readonly><?php echo $row['td2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D3 Tiada kebocoran paip di premis</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
         <?php if( $row['d3'] == 1) 
		       {echo $row['d3']; } ?></td>
    <td><textarea cols="25"  name="td3" id="boxx" rows="2" readonly><?php echo $row['td3']; ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">5</td>
    <td style="text-align:center"><?php echo $totald; ?></td>
    <td></td>
  </tr>
</table>
</div>
<div id="frame5" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>E<br/>kemudahan sanitassi</td>
    <td>E1 keadaan kelengkapan kemudahan tandas<br/>
        &#9899; bersih dan bebas dari bau busuk<br/>
        &#9899; sempurna dan berfungsi dengan baik<br/>
        &#9899;kedudukan pintu tandas tidak boleh menghala terus ke kawasan <br/>
                penyediaan makanan<br/>
        &#9899; pengudaraan sempurna<br/>
        &#9899; bekalan air mencukupi<br/>
        &#9899; disediakan sabun dan tisu/alat pengering<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
              <?php if( $row['e1_1'] == 1) 
		       {echo $row['e1_1']; } ?><br/>
              <?php if( $row['e1_2'] == 1) 
		       {echo $row['e1_2']; } ?><br/>
              <?php if( $row['e1_3'] == 1) 
		       {echo $row['e1_3']; } ?><br/><br/>
              <?php if( $row['e1_4'] == 1) 
		       {echo $row['e1_4']; } ?><br/>
              <?php if( $row['e1_5'] == 1) 
		       {echo $row['e1_5']; } ?><br/>
             <?php if( $row['e1_6'] == 1) 
		       {echo $row['e1_6']; } ?></td>

    <td><textarea cols="25" name="te1" id="boxx" rows="2" readonly><?php echo $row['te1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E2 kemudahan mencukupi<br/>
        &#9899; sinki yang mencukupi<br>
        &#9899; perangkap sisa makanan, minyak dan lemak(fog) berfungsi dan<br/>
        diselengara dengan baik.<br/>
        &#9899; kapasiti perangkap fog yg tersusun</td>
    <td style="text-align:center"><br/>1<br/>1<br/><br/>1</td>
    <td style="text-align:center"><br/>
              <?php if( $row['e2_1'] == 1) 
		       {echo $row['e2_1']; } ?><br/>
              <?php if( $row['e2_2'] == 1) 
		       {echo $row['e2_2']; } ?><br/><br/>
             <?php if( $row['e2_3'] == 1) 
		       {echo $row['e2_3']; } ?></td>
    <td><textarea cols="25" name="te2" id="boxx" rows="2" readonly><?php echo $row['te2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E3 kemudahan tempat mencuci tangan<br/>
        &#9899; bersih<br/>
        &#9899; sempurna<br/>
        &#9899; kemudahan sabun cecair dan pengering tangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <?php if( $row['e3_1'] == 1) 
		       {echo $row['e3_1']; } ?><br/>
              <?php if( $row['e3_2'] == 1) 
		       {echo $row['e3_2']; } ?><br/>
            <?php if( $row['e3_3'] == 1) 
		       {echo $row['e3_3']; } ?></td>
    <td><textarea cols="25" name="te3" rows="2" id="boxx" readonly><?php echo $row['te3']; ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">12</td>
    <td style="text-align:center"><?php echo $totale; ?></td>
    <td></td>
  </tr>
</table>
</div>
<div id="frame6" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>F Struktur dan penyenggaraan premis</td>
    <td>F1 keadaan lantai dinding dan siling<br/>
       &#9899; tidak licin tahan lasak<br/>
       &#9899; mudah dibersihkan<br/>
       &#9899; kalis air<br/>
       &#9899; tidak menakung air / rata<br/>
       &#9899; bebas dari sesawang habuk kulat<br/>
    </td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
        <br/><?php if( $row['f1_1'] == 1) 
		       {echo $row['f1_1']; } ?><br/> <?php if( $row['f1_2'] == 1) 
		       {echo $row['f1_2']; } ?><br/> <?php if( $row['f1_3'] == 1) 
		       {echo $row['f1_3']; } ?><br/> <?php if( $row['f1_4'] == 1) 
		       {echo $row['f1_4']; } ?><br/> <?php if( $row['f1_5'] == 1) 
		       {echo $row['e1_5']; } ?></td>
    <td><textarea cols="25" name="tf1" id="boxx" rows="2" readonly><?php echo $row['tf1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F2 Sistem pengudaraan dan pencahayaan<br/>
        &#9899; mencukupi<br/>
        &#9899; berfungsi.</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <?php if( $row['f2_1'] == 1) 
		       {echo $row['f2_1']; } ?><br/>
              <?php if( $row['f2_2'] == 1) 
		       {echo $row['f2_2']; } ?></td>
    <td><textarea cols="25" name="tf2" id="boxx" rows="2" readonly><?php echo $row['tf2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F3 sistem perparitan yang sempurna<br/>
        &#9899; bersih<br/>
        &#9899; disenggara dengan baik<br/>
        </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
              <?php if( $row['f3_1'] == 1) 
		       {echo $row['f3_1']; } ?><br/>
             <?php if( $row['f3_2'] == 1) 
		       {echo $row['f3_2']; } ?></td>
    <td><textarea cols="25" name="tf3" id="boxx" rows="2" readonly><?php echo $row['tf3']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F4 sistem pengurusan air imbah yang sempurna<br/>
        &#9899; mengalir lancar<br/>
        &#9899; tiada sisa makanan</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center">
        <br/><?php if( $row['f4_1'] == 1) 
		       {echo $row['f4_1']; } ?>
        <br/><?php if( $row['f4_2'] == 1) 
		       {echo $row['f4_2']; } ?></td>
    <td><textarea cols="25" name="tf4" id="boxx" rows="2" readonly><?php echo $row['tf4']; ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">11</td>
    <td style="text-align:center"><?php echo $totalf; ?></td>
    <td></td>
  </tr>
</table>
</div>
<div id="frame7" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>G lain lain generik</td>
    <td>G1 Maklumbalas pelangan</td>
    <td style="text-align:center">5</td>
    <td style="text-align:center">
       <?php
	echo $row["g1"];
	
	?>
    </td>
    <td><textarea cols="25" name="tg1" id="boxx" rows="2" readonly><?php echo $row['tg1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G2 kemudahan tong sampah yang mencukupi berpenutup bersih<br/>
        dan berkarung</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
        <?php if( $row['g2'] == 1) 
		       {echo $row['g2']; } ?></td>
    <td><textarea cols="25" name="tg2" id="boxx" rows="2" readonly><?php echo $row['tg2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G3 bahan makanan dan bahan kimai hendaklah disimpan secara <br/>
        berasingan kedua duanya mestilah berlabel</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
         <?php if( $row['g3'] == 1) 
		       {echo $row['g3']; } ?></td>
    <td><textarea cols="25" name="tg3" id="boxx" rows="2" readonly><?php echo $row['tg3']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G4 penyediaan dan pengurusan stor yang baik(fifo kalis kulat)<br/>
        &#9899; susun atur dan ruang kelegaan<br/>
        &#9899; kebersihan<br/>
        &#9899; pengudaraan dan pencahayaan<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
        <br/> <?php if( $row['g4_1'] == 1) 
		       {echo $row['g4_1']; } ?>
        <br/> <?php if( $row['g4_2'] == 1) 
		       {echo $row['g4_2']; } ?>
        <br/> <?php if( $row['g4_3'] == 1) 
		       {echo $row['g4_3']; } ?></td>
    <td><textarea cols="25" name="tg4" id="boxx" rows="5" readonly><?php echo $row['tg4']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G5 amalan pengurusan sisa pepejal yang baik<br/>
        (pengasigan di punca</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
      <?php if( $row['g5'] == 1) 
		       {echo $row['g5']; } ?></td>
    <td><textarea cols="25" name="tg5" id="boxx" rows="3" readonly><?php echo $row['tg5']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G6 premis dan peralatan perlu disengara dengan baik dan<br/>
        jadual pembersihan mestilah di pantau secara berterusan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><?php if( $row['g6'] == 1) 
		       {echo $row['g6']; } ?></td>
    <td><textarea cols="25" name="tg6" id="boxx" rows="3" readonly><?php echo $row['tg6']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G7 Notis pemberitahuan kebersihan amalan<br/>
        keselamatan pendidikan kesihatan dan larangan<br/>
        merokok</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
      <?php if( $row['g7'] == 1) 
		       {echo $row['g7']; } ?></td>
    <td><textarea cols="25" name="tg7" id="boxx" rows="3" readonly><?php echo $row['tg7']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G8 kawalan dan keselamatan di premis makanan<br/>
        &#9899; alat pemadam api<br/>
        &#9899; peti pertolongan ccemas<br/>
        &#9899; ruang bebas dari sebarang halangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center;">
        <br/><?php if( $row['g8_1'] == 1) 
		       {echo $row['g8_1']; } ?><br/> <?php if( $row['g8_2'] == 1) 
		       {echo $row['g8_2']; } ?><br/><?php if( $row['g8_3'] == 1) 
		       {echo $row['g8_3']; } ?></td>
    <td><textarea cols="25" name="tg8" id="boxx" rows="5" readonly><?php echo $row['tg8']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
    <td style="text-align:center">16</td>
    <td style="text-align:center"><?php echo $totalg; ?></td>
    <td></td>
  </tr>
</table>



  </form>
  
     
 
 
    
  </div>  

 

  <?php
}
?>
</div>
    
    <div class="dummy2"> 

</div>
    
    </main>
    </div>
    
    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
             <button class="addrecord" id="addrecord2" type="button" onclick="" >Grading Management</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord2").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
            
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "searchform2.php";
            };
	        </script>
            
              <button class="reportbutton" id="myinfo" type="button" onclick="">my Info</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo2.php";
            };
	        </script>
            
            
       
            
             <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="Logout">
            </form>
             <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js2.js"></script>
<script>
  
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  </script>




</body>
</html>

<script>
  
  var form1 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f1.style.display = 'block';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form2 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f2.style.display = 'block';
	f1.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form3 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f3.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form4 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f4.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
  }
  
   var form5 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f5.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form6 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f6.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form7 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f7.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	window.scrollTo(0, 550);
  }
  
  
 
  
  
		 $(document).ready(function(){
    $("#flip").click(function(){
        $("#pantsu,#oppai").slideToggle("slow");
    });
});



 $(document).ready(function(){
    $("#flip").click(function(){
       $("#printweb,#backbutton").toggle('slide',{ direction: "right" },400);
    });
});

$(document).ready(function(){
    $("#printweb").click(function(){
        window.open("Untitled-19.php");
    });
});



    $(document).ready(function() {
            $("#flip").click(function(event){
              
			 var logo = $("#flip").css('background-image');
             var cleanup = /\"|\'|\)/g;
             
			 if(logo.split('/').pop().replace(cleanup, '') == "up.jpg"){
				$("#flip").css("background-image", "url(down.jpg)");  
			 }
			 else{
				$("#flip").css("background-image", "url(up.jpg)");   
			 }
            });
         });
		  
  

  
  
  
  
  
</script>



