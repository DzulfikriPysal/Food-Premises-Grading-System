

<?php
session_start();
if (isset($_SESSION['staffid'])) {
$_SESSION['directory'] = "addreport.php";
$timeout = 15;
$logout_redirect_url = "sessiontimeout.php"; 

$timeout = $timeout * 60; 
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}	
}
else{
	$checkid = "homepage.php"; 
	header("Location: $checkid");
}
?>
 <?php
			   if(isset($_POST['search321'])){
				  error_reporting(E_ALL ^ E_DEPRECATED);
				  define('DB_HOST1', 'localhost');
                  define('DB_NAME1', 'premises');
                  define('DB_USER1','root');
                  define('DB_PASSWORD1','');
                  $con=mysql_connect(DB_HOST1,DB_USER1,DB_PASSWORD1) or die("Failed to connect to MySQL: " . mysql_error());
                  $db=mysql_select_db(DB_NAME1,$con) or die("Failed to connect to MySQL: " . mysql_error());
				  
				   $sid =  $_POST['searchid'];
	               $_SESSION['sid'] = $sid;
	               $query = mysql_query("SELECT * FROM premisesdetail
		                       LEFT JOIN premisesowner 

							   ON premisesdetail.namasyarikat = premisesowner.premisesname
							   where premisesdetail.nosiriborang = '$sid'") or die(   mysql_error());
		           $row = mysql_fetch_array($query);
		
       

                   mysql_close($con);
				   
				   $_SESSION["info1"] = $row['nosiriborang'];
	$_SESSION["info2"] = $row['namepelesen'];
	$_SESSION["info3"] = $row['norujlesen'];
	$_SESSION["info4"] = $row['premisesname'];
	$_SESSION["info5"] = $row['tarikh'];
	$_SESSION["info6"] = $row['notel'];
	$_SESSION["info7"] = $row['masamula'];
	$_SESSION["info8"] = $row['masatamat'];
	$_SESSION["info9"] = $row['nokppelesen'];
	$_SESSION["info10"] = $row['address'];
	$_SESSION["info11"] = $row['bilpengendali'];
	$_SESSION["totalmark"] = 100 - ($row['totala'] + $row['totalb'] + $row['totalc'] + $row['totald'] + $row['totale'] + $row['totalf'] + $row['totalg']);
	$_SESSION["grade"] = $row['grade'];
	
	  date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i");
			  
			  $_SESSION["timeprint"] = $a;
	
	
	if($row['suntikanpelali'] == 0){
		$_SESSION["info12"] = "None";
	}
	else{
		$_SESSION["info12"] = "/";
	}
	
	if($row['kursuspengendali'] == 0){
		$_SESSION["info13"] = "None";
	}
	else{
		$_SESSION["info13"] = "/";
	}

	
	 
	 
	 //textarea
	$_SESSION["ta1"] = $row['ta1'];
	$_SESSION["ta2"] = $row['ta2'];
	$_SESSION["ta3"] = $row['ta3'];
	$_SESSION["ta4"] = $row['ta4'];
	$_SESSION["ta5"] = $row['ta5'];
	$_SESSION["tb1"] = $row['tb1'];
	$_SESSION["tb2"] = $row['tb2'];
	$_SESSION["tb3"] = $row['tb3'];
	$_SESSION["tb4"] = $row['tb4'];
	$_SESSION["tc1"] = $row['tc1'];
	$_SESSION["tc2"] = $row['tc2'];
	$_SESSION["td1"] = $row['td1'];
	$_SESSION["td2"] = $row['td2'];
	$_SESSION["td3"] = $row['td3'];
	$_SESSION["te1"] = $row['te1'];
	$_SESSION["te2"] = $row['te2'];
	$_SESSION["te3"] = $row['te3'];
	$_SESSION["tf1"] = $row['tf1'];
	$_SESSION["tf2"] = $row['tf2'];
	$_SESSION["tf3"] = $row['tf3'];
	$_SESSION["tf4"] = $row['tf4'];
	$_SESSION["tg1"] = $row['tg1'];
	$_SESSION["tg2"] = $row['tg2'];
	$_SESSION["tg3"] = $row['tg3'];
	$_SESSION["tg4"] = $row['tg4'];
	$_SESSION["tg5"] = $row['tg5'];
	$_SESSION["tg6"] = $row['tg6'];
	$_SESSION["tg7"] = $row['tg7'];
	$_SESSION["tg8"] = $row['tg8'];
	
	//mark
	$_SESSION["totala"] = $row['totala'];
	$_SESSION["totalb"] = $row['totalb'];
	$_SESSION["totalc"] = $row['totalc'];
	$_SESSION["totald"] = $row['totald'];
	$_SESSION["totale"] = $row['totale'];
	$_SESSION["totalf"] = $row['totalf'];
	$_SESSION["totalg"] = $row['totalg'];
	
	//dropdown
	$_SESSION["a1"] = $row['a1'];
	$_SESSION["b1_1"] = $row['b1_1'];
	$_SESSION["c1_1"] = $row['c1_1'];
	$_SESSION["g1"] = $row['g1'];
	
	//checkbox
	$_SESSION["a2_1"] = $row['a2_1'];
	$_SESSION["a2_2"] = $row['a2_2'];
	$_SESSION["a2_3"] = $row['a2_3'];
	$_SESSION["a2_4"] = $row['a2_4'];
	$_SESSION["a3_1"] = $row['a3_1'];
	$_SESSION["a3_2"] = $row['a3_2'];
	$_SESSION["a3_3"] = $row['a3_3'];
	$_SESSION["a4_1"] = $row['a4_1'];
	$_SESSION["a4_2"] = $row['a4_2'];
	$_SESSION["a4_3"] = $row['a4_3'];
	$_SESSION["a5_1"] = $row['a5_1'];
	$_SESSION["a5_2"] = $row['a5_2'];
	$_SESSION["a6"] = $row['a6'];
	
	$_SESSION["b2_1"] = $row['b2_1'];
	$_SESSION["b2_2"] = $row['b2_2'];
	$_SESSION["b3_1"] = $row['b3_1'];
	$_SESSION["b3_2"] = $row['b3_2'];

	$_SESSION["b4_1"] = $row['b4_1'];
	$_SESSION["b4_2"] = $row['b4_2'];
	
	$_SESSION["c2_1"] = $row['c2_1'];
	$_SESSION["c2_2"] = $row['c2_2'];
	$_SESSION["c2_3"] = $row['c2_3'];
	$_SESSION["c2_4"] = $row['c2_4'];
	$_SESSION["c2_5"] = $row['c2_5'];
	$_SESSION["c2_6"] = $row['c2_6'];
	$_SESSION["c3"] = $row['c3'];
	
	$_SESSION["d1_1"] = $row['d1_1'];
	$_SESSION["d1_2"] = $row['d1_2'];
	$_SESSION["d2_1"] = $row['d2_1'];
	$_SESSION["d2_2"] = $row['d2_2'];
	$_SESSION["d3"] = $row['d3'];
	
	$_SESSION["e1_1"] = $row['e1_1'];
	$_SESSION["e1_2"] = $row['e1_2'];
	$_SESSION["e1_3"] = $row['e1_3'];
	$_SESSION["e1_4"] = $row['e1_4'];
	$_SESSION["e1_5"] = $row['e1_5'];
	$_SESSION["e1_6"] = $row['e1_6'];
	$_SESSION["e2_1"] = $row['e2_1'];
	$_SESSION["e2_2"] = $row['e2_2'];
	$_SESSION["e2_3"] = $row['e2_3'];
	$_SESSION["e3_1"] = $row['e3_1'];
	$_SESSION["e3_2"] = $row['e3_2'];
	$_SESSION["e3_3"] = $row['e3_3'];
	
	
	$_SESSION["f1_1"] = $row['f1_1'];
	$_SESSION["f1_2"] = $row['f1_2'];
	$_SESSION["f1_3"] = $row['f1_3'];
	$_SESSION["f1_4"] = $row['f1_4'];
	$_SESSION["f1_5"] = $row['f1_5'];
	$_SESSION["f2_1"] = $row['f2_1'];
	$_SESSION["f2_2"] = $row['f2_2'];
	$_SESSION["f3_1"] = $row['f3_1'];
	$_SESSION["f3_2"] = $row['f3_2'];
	$_SESSION["f4_1"] = $row['f4_1'];
	$_SESSION["f4_2"] = $row['f4_2'];
	
	$_SESSION["g2"] = $row['g2'];
	$_SESSION["g3"] = $row['g3'];
	$_SESSION["g4_1"] = $row['g4_1'];
	$_SESSION["g4_2"] = $row['g4_2'];
	$_SESSION["g4_3"] = $row['g4_3'];
	$_SESSION["g5"] = $row['g5'];
	$_SESSION["g6"] = $row['g6'];
	$_SESSION["g7"] = $row['g7'];
	$_SESSION["g8_1"] = $row['g8_1'];
	$_SESSION["g8_2"] = $row['g8_2'];
	$_SESSION["g8_3"] = $row['g8_3'];
	
	
	
	echo "<script> window.open('Untitled-19.php');</script>";
   
			   }
			   
			   
			   ?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu"/>
  <script type = "text/javascript" 
         src = "jquery.js"></script>
  <style>
  a {
    color: black;
    padding: 4px 4px;
    text-decoration: none;
    border-radius: 4px;
}


#tab {
  border: 0px #fff solid;
  font-size: .9em;
  box-shadow: 0 0px 0px rgba(0,0,0,.25);
  width: 100%;
  border-collapse: collapse;
  border-radius: 0px;
  
 
}

#tab th {
  text-align: left;
}
  
#tab thead {
  font-weight: bold;
  color: #fff;
  background: #039BE5;
}
  
 #tab td,#tab th {
  padding: .2em .5em;
  vertical-align: middle;
}
  
#tab td {
  border-bottom: 0px solid rgba(0,0,0,.1);
  background: #fff;
  height:45px;
}

#tab a {
  color: #ff
  ;
}
  
  #tab table,#tab thead,#tab tbody,#tab th,#tab td,#tab tr {
    display: block;
  }
  
 #tab th {
    text-align: right;
	height:45px;
  }
  
  #tab {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 5px rgba(0,0,0,.2);
  }
  
 #tab thead {
    float: left;
    white-space: nowrap;
  }
  
 #tab tbody {
	 width:400px;
    position: relative;
    white-space: nowrap;
  }
  
 #tab tr {
    display: inline-block;
    vertical-align: top;
	 
  }
  
 
</style>
</head>
<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button" ><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; color:#FFF;">Grading management</td>
  </tr>
</table>


</div>
<div id="o-wrapper" class="o-wrapper" style="height:400px; " >

 <div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content" style="height:400px;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">
    
    
    <table width="100%" border="0" style="text-align:left;">
  <tr>
    <td><form  method = "post" action = "<?php $_PHP_SELF ?>">
                  <input name = "viewalldata" type = "submit" id="viewbutton"  value = "Refresh" style="background-color:#ffc107; border:none" >
                  
                  
                  
                  <input name = "sbox" type = "text"  size="40" onKeyPress="return submitenter(this,event)"  id = "namanyay-search-box" placeholder="Search"  >
                  
                  <select name="sdown" id="namanyay-search-box"  >
                  <option  value="premisesname" title="Name of the premise"> By Premise name</option>
                  <option value="namepelesen" title="Premise owner name"> premise owner</option>
                  <option value="nokppelesen" title="Premise owner IC"> By IC no</option>
                  <option value="createby" title="Inspector Name"> By Inspector</option>
                  
                  
                  </select>
                 
                  <input name = "sdata" type = "submit" id="sdata" value = "Search" style="background-color:#ffc107; border:none" >
                   
                  
                  
               </form></td>
    <td style="text-align:right;">
    <form  name="bulk_action_form" action="action2.php" method="post" onSubmit="return delete_confirm();"/>
     <input type="button" id="c-button--slide-top" title="Add new premise" class="ph-button ph-btn-red" value="&nbsp;&nbsp;Add&nbsp;&nbsp">
     <input  id="c-button--slide-top2" class="c-button2"  type = "hidden"value = "view">
     <input  id="c-button--slide-top3" class="c-button3"  type = "hidden"value = "update">
     <input  id="c-button--slide-top4" class="c-button4"  type = "hidden"value = "shop">
    
     <input id="deletebutton" type="submit" title="Delete Premise" class="ph-button ph-btn-red" name="bulk_delete_submit" value="Delete"/>
        </td>
  </tr>
</table>

    
<table width="100%" border="0">
  <tr>
    <td> <?php
		
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

?>

<?php
 if(isset($_POST['viewalldata'])){
		$_SESSION["check2"] = 0; 
		$_SESSION["page"] = 0;
		$_GET['page'] = 0;
	 }
	 
if(isset($_POST['sdata'])){
	$_SESSION["check2"] = 1;
	$_SESSION["searchrow3"] = $_POST['sbox'];
	$_SESSION["page"] = 0;
	$_GET['page'] = 0;
	$_SESSION["sdown3"] = $_POST['sdown'];
	?>
    
    <?php
}


if($_SESSION["check2"] == 1){
  $value =	$_SESSION["searchrow3"];
  $sdown =	$_SESSION["sdown3"];
  
  $tbl_name="premisesowner";		
	
	$adjacents = 5;
	if( $value == ""){
		$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE premisesname LIKE '%$value%' OR namepelesen LIKE '%$value%'";
	}
	else{
		$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE ".$sdown." LIKE '%$value%' ";
	}
	
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages['num'];
	
	
	$targetpage1 = "addreport.php"; 	
	$limit = 10; 	
	if(isset($_GET['page']) ) {
         
			   $_SESSION["page"] = $_GET['page'];
		  
   }else {
          $_SESSION["page"] = $_SESSION["page"];
   }
  
	if($_SESSION["page"]) 
		$start1 = ($_SESSION["page"] - 1) * $limit; 			
	else
		$start1 = 0;	
	
	if( $value == ""){
		$sql = "SELECT * FROM $tbl_name WHERE premisesname LIKE '%$value%' OR namepelesen LIKE '%$value%' LIMIT $start1, $limit";
		
	}
	else{
		$sql = "SELECT * FROM $tbl_name WHERE ".$sdown." LIKE '%$value%'  LIMIT $start1, $limit";
		
	}
	$result = mysql_query($sql);

	
	
	if ($_SESSION["page"] == 0) $_SESSION["page"] = 1;					
	$prev1 = $_SESSION["page"] - 1;							
	$next1 = $_SESSION["page"] + 1;							
	$lastpage1 = ceil($total_pages/$limit);		
	$lpm1 = $lastpage1 - 1;						
	
	
	$pagination = "";
	if($lastpage1 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px;\">";
		
		if ($_SESSION["page"] > 1) 
			$pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
		else
			$pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";	
		
		
		if ($lastpage1 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage1; $counter++)
			{
				if ($counter == $_SESSION["page"])
				$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
				else
					$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";		
							
			}
		}
		elseif($lastpage1 > 5 + ($adjacents * 2))	
		{
			
			if($page1 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page1)
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";	
						
									
				}
				$pagination.= "...";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";		
			}
			
			elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
			{
				$pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
				{
				if ($counter == $page1)
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";		
			}
			
			else
			{
				$pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
				{
					if ($counter == $page1)
						$pagination.= "<a class='next' onClick='return false;'style='background-color:#999;cursor:default;' href=\"$targetpage1?page=$counter\">$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($_SESSION["page"] < $counter - 1) 
			$pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
		else
			$pagination.= "<a class='next' href=\"$targetpage1?page=$next1\" onClick='return false' style='cursor:default'> >> </a>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
?>

	<?php
	echo "<div style='height:450px;'>";
	echo '
    <table id="customers">
        <thead><tr>
		    <th>Owner Name</th>
			<th>Owner Liccence</th>
			<th>Company Phone</th>
			<th style="text-align:center">View Grade Report</th>
            <th style="text-align:center">View Premise Detail</th>
            <th style="text-align:center">Update Premise</th>
           
            <th><input id="checkall" type="checkbox" name="select_all" title="Click to tick / untick all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
		if($total_pages > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>'  . $row['namepelesen']  . '</td>'.
	    '<td>'  . $row['nokppelesen'] . '</td>'.
	   '<td>'  . $row['notel'] . '</td>
        <td style="text-align:center;"> <input id="viewdetail" title="Premise grading report" type="button" name="'. $row['id']. '" onClick=    
               "viewshop(this.name)" value="View Grade"/> </td>
          <td style="text-align:center;"> <input id="viewdetail" title="Premise detail" type="button" name="'. $row['id']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            <td style="text-align:center;"><input id="updatebutton" title="Update premise detail" type="button" name="'.$row['id'].'" onClick=    
               "reply_click(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" title="click then press delete button to delete premise" name="checked_id[]" class="checkbox" value="'. $row['id'].'"/></td>    
        </tr> ';
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		}
		echo ' </table>';
		echo "</div><br/><br/>";
	?>
	<?php	
}
else if($_SESSION["check2"] == 0){

    

	$tbl_name="premisesowner";		
	
	$adjacents = 5;
	
	$query = "SELECT COUNT(*) as num FROM $tbl_name ";
	$total_pages = mysql_fetch_array(mysql_query($query));
	$total_pages = $total_pages['num'];
	
	
	
	$targetpage1 = "addreport.php"; 	
	$limit = 10; 	
	if(isset($_GET['page']) ) {
          $page1 = $_GET['page'];
   }else {
          $page1 = 0;
   }
	if($page1) 
		$start1 = ($page1 - 1) * $limit; 			
	else
		$start1 = 0;								
	
	
	$sql = "SELECT * FROM $tbl_name  LIMIT $start1, $limit";
	$result = mysql_query($sql);
	
	
	if ($page1 == 0) $page1 = 1;					
	$prev1 = $page1 - 1;							
	$next1 = $page1 + 1;							
	$lastpage1 = ceil($total_pages/$limit);		
	$lpm1 = $lastpage1 - 1;						
	
	
	$pagination = "";
	if($lastpage1 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px;\">";
		
		if ($page1 > 1) 
			$pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
		else
			$pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";	
		
		
		if ($lastpage1 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage1; $counter++)
			{
				if ($counter == $page1)
					$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999; cursor:default;'>$counter</a>";
				else
					$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage1 > 5 + ($adjacents * 2))	
		{
			
			if($page1 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page1)
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";		
			}
			
			elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
			{
				$pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
				{
					if ($counter == $page1)
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";		
			}
			
			else
			{
				$pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
				$pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
				{
					if ($counter == $page1)
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
					else
						$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($page1 < $counter - 1) 
			$pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
		else
			$pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='cursor:default;'> >></a>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
?>

	<?php
	echo "<div style='height:450px;'>";
	echo '
    <table id="customers">
        <thead><tr>
            <th>Owner Name</th>
			<th>Owner Liccence</th>
			<th>Company Phone</th>
			<th style="text-align:center">View Grade Report</th>
            <th style="text-align:center">View Premise Detail</th>
            <th style="text-align:center">Update Premise</th>
            <th style="height:40px;"><input id="checkall" type="checkbox" title="Click to tick / untick all" name="select_all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
		if($total_pages > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>'  . $row['namepelesen']  . '</td>'.
	    '<td>'  . $row['nokppelesen'] . '</td>'.
	   '<td>'  . $row['notel'] . '</td>
        <td style="text-align:center;"> <input id="viewdetail" title="Premise grading report" type="button" name="'. $row['id']. '" onClick=    
               "viewshop(this.name)" value="View Grade"/> </td>
          <td style="text-align:center;"> <input id="viewdetail" title="premise detail" type="button" name="'. $row['id']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            <td style="text-align:center;"><input id="updatebutton" title="update premise detail" type="button" name="'.$row['id'].'" onClick=    
               "reply_click(this.name)"  value="Update"/></td>
            <td align="center">
            <input id="checkbox1" type="checkbox" title="click then press delete button to delete premise"  name="checked_id[]" class="checkbox" value="'. $row['id'].'"/></td>    
        </tr> ';
	
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		}
		echo ' </table>';
		echo "</div><br/><br/>";
		?>
        <?php
}
?></td>
  </tr>
</table>

<table width="100%" height="100px" border="0">
  <tr>
    <td style="padding-left:45%; padding-right:45%"><?=$pagination?></td>
  </tr>
</table>

    
               
      
   

    </div><!-- /o-container -->
    
       
</form>    



<div class="dummy2"> 


</div>
   
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "searchform2.php";
            };
	        </script>
            
            
            
            <button class="viewrecord" id="myinfo" type="button" onclick="">MY INFO</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo2.php";
            };
	        </script>
       
            
             <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="logout">
            </form>
            
            
           <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->



<div id="c-menu--slide-top" class="c-menu1 c-menu--slide-top" style="height:500px;">
  <div class="dummyx" style="color:#FFF;"> ADD
</div>
<div class="dummyxz" style="width:100px;"> 
   <form method = "post" action = "<?php $_PHP_SELF ?>" >
   <br/>
   
   <table id="tab"  style="margin-left:50px; margin-right:20px;">
    <thead>
    <tr>
        <th>Premise Name : </th>
        <th>Owner Name : </th>
       <th>Owner Licence : </th>
        <th>Owner Phone : </th>
       <th>Licence Reference No : </th>
       <th>Address : </th>
        

    </tr>
    </thead>
    
    <tbody>
    <tr>
     <td><input name = "premisename" type = "text" 
                           id = "textbox" required required minlength="10"  ></td>
        
        <td><input name = "ownername" type = "text" 
                           id = "textbox" required required minlength="10"  ></td>
        <td><input name = "ownerlicence" onkeypress='return isNumberKey(event)' type = "text" 
                           id = "textbox" required minlength="10" ></td>
        <td><input name = "phone"  type="text" onkeypress='return isNumberKey(event)'  id = "textbox" required minlength="10" maxlength="20" ></td>
       <td><input name = "refno" type="text" onkeypress='return isNumberKey(event)' id = "textbox" required minlength="10" maxlength="20"></td>
       <td><textarea name="address" required  minlength="10"  ></textarea></td>
                           
        
    </tr>
    </tbody>
</table>
<br/>
<table width="100%" border="0" style="margin-left:150px;" >
  <tr>
    <td><button name = "add" type = "submit" id = "click" 
                          style="background-color:#ffc107; color:#FFF; border:none"
                          > Add</button></td>
    <td>  <button id="click" class="c-menu__close" 
                         style="background-color:#ffc107; color:#FFF; border:none" 
                          >Cancel</button></td>
  </tr>
</table>

                                    
                         
  
               </form>
               
                
                         
               <?php
 error_reporting(E_ALL ^ E_DEPRECATED);

# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connect = "localhost";
$database_connect = "premises";
$username_connect = "root";
$password_connect = "";
$connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);
         
		 if(isset($_POST["add"])){
			 
		       $premisename = $_POST['premisename'];
			   $address  = $_POST['address'];
               $ownername = $_POST['ownername'];
               $ownerlicence = $_POST['ownerlicence'];
			   $phone = $_POST['phone'];
               $refno = $_POST['refno'];  
           
			
date_default_timezone_set("Asia/Singapore");
$t = microtime(true);
$micro = sprintf("%06d",($t - floor($t)) * 1000000);
$d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

$a =  $d->format("Y-m-d H:i:s.u");
  
 $adminname = $_SESSION["staffid"];

    
   $sql = 'INSERT INTO premisesowner '.
      '(premisesname,address,namepelesen,nokppelesen,notel,norujlesen,datecreate,createby) '.
      "VALUES ('$premisename','$address', '$ownername','$ownerlicence','$phone','$refno','$a','$adminname')";
      
   mysql_select_db('premises');
   $retval = mysql_query( $sql, $connect );
   mysqli_close($connect);
   $_SESSION['success_msg'] = "Successfully add new premises";
		 }
		 
		 function refresh(){
			 
			$page = $_SERVER['PHP_SELF'];
            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
			 
		 }
		 
		 if(isset($_POST['add']))
          {
	      refresh();
          }


?>
   
  
</div>
 
</div><!-- /c-menu slide-top -->


<div id="c-menu--slide-top3" class="c-menu3 c-menu--slide-top3">
<div class="dummyx" style="color:#FFF;"> UPDATE</div>
<div class="dummyxz">
<iframe  name="smallframe2" width="500" height="400" style=" border:none"></iframe>
                <form name="myform3"  target="smallframe2" method = "post" action = "search2.php">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "search" type = "hidden" id="search"
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>

                          <button id="click" class="c-menu__close" style="background-color:#ffc107; color:#FFF; border:none; position:absolute; top:371px; left: 375px;">Cancel</button>
         
</div>
   
</div><!-- /c-menu slide-top -->


<div id="c-menu--slide-top2" class="c-menu2 c-menu--slide-top2">
<div class="dummyx" style="color:#FFF;"> View</div>
<div class="dummyxz">

<iframe src="viewform2.php" name="smallframe1" width="100%" height="360px" style="border:none"></iframe>
                <form name="myform2"  target="smallframe1" method = "post" action = "viewform2.php">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "search" type = "hidden" id="search"
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>

                          <button id="click" class="c-menu__close" style="background-color:#ffc107; color:#FFF; border:none; position:absolute; top:343px; left: 350px;">Cancel</button>
         
</div>
   
</div><!-- /c-menu slide-top -->


<div id="c-menu--slide-top4" class="c-menu4 c-menu--slide-top4">
<div class="dummyx" style="color:#FFF;"> Shop</div>
<div class="dummyxz">




<iframe name="smallframe3" width="100%" height="550px" frameborder="0" style="position:absolute; top:0px; left:0px;" ></iframe>


                <form name="myform4"  target="smallframe3" method = "post" action = "searchshop.php">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "search" type = "hidden" id="search" 
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>
               
               
               
                <table width="55%" border="0" style=" position:fixed; padding-right:5px; margin-top:5px; left:0px;top:30px;">
  <tr>
    <td>            
    <form  method = "post" target="smallframe3" action = "searchshop.php">
                  <input name = "viewalldata" type = "submit" id="viewbutton"  value = "Refresh"  >
                  <input name = "sbox" type = "text"  size="40" onKeyPress="return submitenter(this,event)"  id = "namanyay-search-box" placeholder="Search"   >
                    <select name="sdown" id="namanyay-search-box" >
                  <option value="grade" title="By grade A/B/C and F for fail"> By grade</option>
                  <option value="month" title="By number 1 - 12 to represent month"> By month</option>
                  <option value="year" title="By number"> By year</option>
                  <option value="createby" title="The Inspector name"> By Inspector</option>
                  </select>
                  <input name = "sdata" type = "submit" id="sdata" value = "Search"  >
               </form>
         
         </td>
        
  </tr>
</table>
               

<form name="myform5"   method = "post" action = "grading.php">
                  <input name = "searchid" type = "hidden"  id = "textbox" required  style=" margin-left:5px; margin-right:5px; ">
                    
                           <input name = "record1" type = "submit" id="viewbutton3" class="record1"
                              value = "Add Grading"  style=" display:none; margin-left:0px; margin-right:0px; " ></form>
   
    
    
                            
                      <button id="viewbutton1" style="display:none;"  class="c-menu__close"  >Cancel</button>      
               
 

                          
         
</div>
   
</div><!-- /c-menu slide-top -->






<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  
    var slideTop = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-top',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideTopBtn = document.querySelector('#c-button--slide-top');
  
  slideTopBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideTop.open();
  });
  
  
  
   var slideTop3 = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-top3',
    menuOpenerClass: '.c-button3',
    maskId: '#c-mask'
  });

  var slideTopBtn3 = document.querySelector('#c-button--slide-top3');
  
  slideTopBtn3.addEventListener('click', function(e) {
    e.preventDefault;
    slideTop3.open();
  });
  
  
  
  
   var slideTop2 = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-top2',
    menuOpenerClass: '.c-button2',
    maskId: '#c-mask'
  });

  var slideTopBtn2 = document.querySelector('#c-button--slide-top2');
  
  slideTopBtn2.addEventListener('click', function(e) {
    e.preventDefault;
    slideTop2.open();
  });
  
  
  
  
     var slideTop4 = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-top4',
    menuOpenerClass: '.c-button4',
    maskId: '#c-mask'
  });

  var slideTopBtn4 = document.querySelector('#c-button--slide-top4');
  
  slideTopBtn4.addEventListener('click', function(e) {
    e.preventDefault;
    slideTop4.open();
  });
  
  
  
  
  
   function ouch()
{
	
    window.location=window.location;
	
	
   
}


  
   function myFunction() {
    document.getElementById("c-button--slide-top3").click();
}
  
  


function reply_click(clicked_id)
{
	 document.getElementById("c-button--slide-top3").click();
  // alert(clicked_id);
  // document.getElementById("yoho").innerHTML = clicked_id;
  document.myform3.searchid.value = clicked_id;
  document.forms["myform3"].submit();
  document.getElementById("search").click();
  
}


function view(clicked_id)
{
	 document.getElementById("c-button--slide-top2").click();
  // alert(clicked_id);
  // document.getElementById("yoho").innerHTML = clicked_id;
  document.myform2.searchid.value = clicked_id;
  document.forms["myform2"].submit();
  document.getElementById("search").click();
  
}



  function delete_confirm(){
	var result = confirm("Are you sure to delete users?");
	if(result){
		return true;
	}else{
		return false;
	}
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
	
	$('.checkbox').on('click',function(){
		if($('.checkbox:checked').length == $('.checkbox').length){
			$('#select_all').prop('checked',true);
		}else{
			$('#select_all').prop('checked',false);
		}
	});
});



function viewshop(clicked_id)
{
	 document.getElementById("c-button--slide-top4").click();
  // alert(clicked_id);
  // document.getElementById("yoho").innerHTML = clicked_id;
  document.myform4.searchid.value = clicked_id;
  document.myform5.searchid.value = clicked_id;
  document.forms["myform4"].submit();
  document.getElementById("search").click();
  
}



 function submitenter(myfield,e) { 
    var keycode; 
	if (window.event) keycode = window.event.keyCode; 
	else if (e) keycode = e.which; else return true; 
	if (keycode == 13) { 
	document.getElementById("sdata").click(); return false; 
	} 
	  else return true; }
	  
	  function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }




 function guestFromPop() {
  document.getElementById("viewbutton1").click();
}

 function addgrading() {

  document.getElementById("viewbutton3").click();
}



$("#checkall").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});

</script>
 <script>
         $(function() {
            $( document ).tooltip();
         });
      </script>
		
      <style>
         label {
            display: inline-block;
            width: 15em;
         }
      </style>

</body>
</html>
