
<?php
session_start();
if (isset($_SESSION['hehe'])) {
	
	print '<script type="text/javascript">';
    print 'alert("Session time out!")';
    print '</script>'; 
	session_destroy(); 
}
else if(isset($_SESSION['directory'])){
	$logout_redirect_url = $_SESSION['directory'];
	header("Location: $logout_redirect_url");
}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  
<style type="text/css">
 input{
 border:1px solid olive;
 border-radius:5px;
 }
 h1{
  color:darkgreen;
  font-size:22px;
  text-align:center;
 }
 </style>

</head>
<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table width="1000px" border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px;color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px;  "></td>
  </tr>
</table>


</div>

<div id="o-wrapper" class="o-wrapper">
<div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
  
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>

  <main class="o-content">
  <div class="dummy1"><h1></h1></div>
    <div class="o-container">
    
    
<h1>Please enter your registered email:<h1>
<form action='#' method='post'>
<table cellspacing='5' align='center'>
<tr><td>email :</td><td><input type='text' name='email'/></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='Reset Password'/></td></tr>
</table>
</form>
<?php
if(isset($_POST['submit']))
{ 
 error_reporting(E_ALL ^ E_DEPRECATED);
 define('DB_HOST', 'localhost');
 define('DB_NAME', 'premises');
 define('DB_USER','root');
 define('DB_PASSWORD','');
 $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
 mysql_select_db('premises') or die(mysql_error());
 $email=$_POST['email'];
 $q=mysql_query("select * from user where email='".$email."' ") or die(mysql_error());
 $p=mysql_affected_rows();
 if($p!=0) 
 {
  $res=mysql_fetch_array($q);
  $to=$res['email'];
  $id = $res['staffid'];
  
  
  /*START generate random string for password reset----------------------------------------*/
  function random_str($length = 10,$keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
  {
	  $newpassword = '';
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $newpassword .= $keyspace[rand(0, $max)];
    }
    return $newpassword;
  }
  /*END generate string for password reset-----------------------------------------*/
  
  $newpass=random_str();
  $subject='Remind password';
  $message='New password : '.$newpass; 
  $headers='From:dzulpangsit@gmail.com';
  $m = mail($to,$subject,$message,$headers);
  
   /*START generate hash for random password and update it into the database-------------*/
   $pass1 = $newpass;
   $pass1 = hash("sha512", $pass1);
   $sql = "UPDATE user ". "SET Password  = '$pass1'". 
   "WHERE email = '$email'" ;
   /*END generate hash for random password and update it into the database-------------*/
   
    mysql_select_db('premises');
   $retval = mysql_query( $sql, $con );
   mysql_close($con);
  
  if($m)
  {
    echo'Your new password has been sent to your email.';
  }
  else
  {
   echo'Email not sent, password failed to reset.';
  }

 }
 else
 {
  echo'Please provide valid email address.';
 }
}
?>
    </div><!-- /o-container -->
  </main><!-- /o-content -->

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <div class="top" style="background-image:url(A.PNG)">
           </div>
           
            <div class="mid" style="top:165px;">
            
            <div class="login-screen">
			<div class="app-title">
				<h1 style="color:#FFF">Login</h1>
			</div>

			<div class="login-form">
           
             <form class="loginform" method="POST" action="connectivity.php" > 
                 <div class="control-group">
				      <input id="login-field" id="login-name" type="text" name="user" size="25" required="required" placeholder="Staff ID">
				</div>
                     <input id="login-field" id="login-name" type="password" name="pass" size="25" required="required" minlength="10" maxlength="20" placeholder="Password">
				<div class="control-group">
				
				</div>
              
                 <input id="btnlogin" type="submit" name="submit" value="Log-In">
				<a class="login-link" href="resetpassword.php" style="color:#FFF">Lost your password?</a>
          </form>
         
      
          </div>
          </div>
          
          
          
           <button id="c-menu__close" class="c-menu__close">&larr; Close Menu</button>
           </div>
  
  <div class="dummy2">  
    
    </div>
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  

  
  
  
  

</script>

</body>
</html>
