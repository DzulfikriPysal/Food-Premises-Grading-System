<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
$_SESSION['directory'] = "viewreport.php";
$timeout = 15;
$logout_redirect_url = "sessiontimeout.php"; 

$timeout = $timeout * 60;

if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
    <link rel="stylesheet" href="css3.css">
    <link rel="stylesheet" href="css4.css">
    <link rel="stylesheet" type="text/css" media="print" href="print.css" />
    <script type = "text/javascript" 
         src = "jquery.js"></script>
        
      <script type = "text/javascript" 
         src = "jquery-ui.js"></script>
    
    
</head>

<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button" ><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; color:#FFF;">Update Report</td>
  </tr>
</table>

</div>

<div id="o-wrapper" class="o-wrapper" >

 <div style="width:100%; height:60px; float:left">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content">
      <div class="dummy1"><h1></h1></div>
     
    <div class="o-container" style=" height:1300px; text-align:start;">
    
     <div id="aa">
  
            <form name="myform" method = "post" action = "saveupdate.php" >
            
              <?php
	define('DB_HOST', 'localhost');
    define('DB_NAME', 'premises');
    define('DB_USER','root');
    define('DB_PASSWORD','');
    $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
    $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
   
    if(isset($_POST["search2"])){
	
	


		 $sid =  $_POST['searchid2'];
	     $_SESSION['sid'] = $sid;
	     $query = mysql_query("SELECT * FROM premisesdetail
		                       LEFT JOIN premisesowner 
							   ON premisesdetail.namasyarikat = premisesowner.premisesname
							   where premisesdetail.nosiriborang = '$sid'") or die(   mysql_error());
		 $row = mysql_fetch_array($query);
		
       

mysql_close($con);
	
	
	
	$searchid = $_POST['searchid2'];
	
	

	?>
            
            <?php
			$totala = $row['totala'];
            $totalb = $row['totalb'];
            $totalc = $row['totalc'];
            $totald = $row['totald'];
            $totale = $row['totale'];
            $totalf = $row['totalf'];
            $totalg = $row['totalg'];
            $total = 100 - ($totala + $totalb + $totalc + $totald + $totale + $totalf + $totalg);
			?>
                <table width="100%" border="0">
  <tr>
    <td>mark : </td>
    <td><input type="text" name="currentmark" id="currentmark" value="<?php echo intval($total); ?>" readonly/>
   </td>
  </tr>
  <tr>
    <td>grade : </td>
    <td><input type="text" name="currentgrade" id="currentgrade" value="<?php echo $row['grade']; ?>" readonly/></td>
  </tr>
</table>

        
   
   <input type="submit"  name="add" style="float:right; margin-right:5px; cursor:pointer;"   value="&nbsp;&nbsp;Save&nbsp;&nbsp;" id="sdata" >
    <input type="button" id="backbutton" value="cancel"/>
   
   <script type="text/javascript">
            document.getElementById("backbutton").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
   
   </div>
   
   
 
<div id="flip" style=" width:45px; height:30px;cursor:pointer; background-image:url(up.jpg); background-size: contain; background-repeat:no-repeat;">
</div>
<div id="oppai">
  

    <ul class="pagination" style="position:absolute; right:0px; top:0px;">
        <li> <a style="cursor:pointer;" onclick="form1();">A</a></li>
        <li><a style="cursor:pointer" onclick="form2();">B</a></li>
        <li><a style="cursor:pointer" onclick="form3();">C</a></li>
        <li><a style="cursor:pointer" onclick="form4();">D</a></li>
        <li><a style="cursor:pointer" onclick="form5();">E</a></li>
        <li><a style="cursor:pointer" onclick="form6();">F</a></li>
        <li><a style="cursor:pointer" onclick="form7();">G</a></li>
 </ul>   
    
     <div id="pantsu">

   </div>
</div>
  
    

    
    

 
   <h1 style="text-align:center">Borang Pemeriksaan Dan Penggredan Premis Makanan</h1>
   
    <table width="90%" border="0">
  <tr>
    <td style="text-align:start;">Serial Number</td>
    <td><input id="boxx" name="nosiriborang"  readonly type="text" value="<?php echo $row['nosiriborang'] ?>"></td>
   
  </tr>
  <tr>
    <td style="text-align:start;">Owner Name</td>
    <td><input id="boxx" type="text" name="ownername" readonly value='<?php echo $row['namepelesen'] ?>' ></td>
    <td style="text-align:start;">Licence Reference No</td>
    <td><input id="boxx" type="text"name="refno" value="<?php echo $row['norujlesen'] ?>" readonly></td>
  </tr>
  <tr>
    <td style="text-align:start;">Company Name</td>
    <td><input id="boxx" type="text" name="companyname"  readonly value='<?php echo $row['premisesname'] ?>'></td>
    <td style="text-align:start;">Date</td>
    <td><input id="boxx" type="text" name="date"  value="<?php echo $row['tarikh'] ?>" readonly></td>
  </tr> 
 
  <tr>
    <td style="text-align:start;">Phone Number</td>
    <td><input id="boxx" type="text" name="phone" readonly value='<?php echo $row['notel'] ?>'>
   </td>
    <td style="text-align:start;">Time</td>
    <td style="text-align:start;"><input id="boxx" type="text" style="width: 100px;" value="<?php echo $row['masamula'] ?>" placeholder="Start" name="tstart"  readonly> <input type="text" placeholder="End" style="width: 100px;" name="tend" value="<?php echo $row['masatamat'] ?>" id="boxx" readonly></td>
  </tr>
  <tr>
 
    <td style="text-align:start;">Owner Licence No</td>
    <td><input type="text" id="boxx" name="ownerlicence"  readonly value='<?php echo $row['nokppelesen'] ?>'></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="text-align:start;">Address</td>
    <td><textarea  cols="25" id="boxx" rows="4" name="address" readonly><?php echo $row['address'] ?></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
     <td style="text-align:start;">Pengendali</td>
    <td >
         
         <select name="bilpengendali" id="boxx" style="width:50px">
           <option <?php if ($row['bilpengendali'] == 0) echo ' selected="selected"'; ?>>0</option>
           <option <?php if ($row['bilpengendali'] == 1) echo ' selected="selected"'; ?>>1</option>
           <option <?php if ($row['bilpengendali'] == 2) echo ' selected="selected"'; ?>>2</option>
           <option <?php if ($row['bilpengendali'] == 3) echo ' selected="selected"'; ?>>3</option>
        </select>
    </td>
	
	
	<?php
	
	$_SESSION["info1"] = $row['nosiriborang'];
	$_SESSION["info2"] = $row['namepelesen'];
	$_SESSION["info3"] = $row['norujlesen'];
	$_SESSION["info4"] = $row['premisesname'];
	$_SESSION["info5"] = $row['tarikh'];
	$_SESSION["info6"] = $row['notel'];
	$_SESSION["info7"] = $row['masamula'];
	$_SESSION["info8"] = $row['masatamat'];
	$_SESSION["info9"] = $row['nokppelesen'];
	$_SESSION["info10"] = $row['address'];
	 
	?>
    <td><input type="hidden" value="0" name="tibid" id="tibid">
        <input type="hidden" value="0" name="tibid" id="tibid">
        Suntikan pelalian anti tifoid<input value="1" type="checkbox" id="tibid"  name="tibid" <?php echo ($row['suntikanpelali']==1 ? 'checked' : '');?>>
        
        
    </td>
    <td><input type="hidden" value="0" name="kursus" id="kursus">
        <input type="hidden" value="0" name="kursus">
        Kursus pengendali makanan<input value="1" type="checkbox" id="kursus"  name="kursus"  <?php echo ($row['kursuspengendali']==1 ? 'checked' : '');?>>
    </td>
  </tr>
</table>



<div class="page-break"></div>
<div id="frame1" style="display:block;">
  <table id="A" width="100%" border="1">
  <tr>
    <th id="showprint"  scope="col">Perkara</th>
    <th id="showprint"  scope="col">Komponen</th>
    <th id="showprint"  scope="col">Markah</th>
    <th id="showprint"  scope="col">Demerit</th>
    <th id="showprint"  scope="col">Catatan</th>
  </tr>
  <tr>
    <td>A Kawasan penyediaan makanan</td>
    <td>A1 Kawasan Suhu Penyimpanan Dan Penyediaan Makanan <br/>
        Peti sejuk <br/>
        &#9899; Suhu sejuk -18c hingga 0c</td>
    <td style="text-align:center">12</td>
   
    <td style="text-align:center">
   <select name="a1" id="a1" onChange="marks1();">
           <option <?php if ($row['a1'] == 0) echo ' selected="selected"'; ?>>0</option>
           <option <?php if ($row['a1'] == 1) echo ' selected="selected"'; ?>>1</option>
           <option <?php if ($row['a1'] == 2) echo ' selected="selected"'; ?>>2</option>
           <option <?php if ($row['a1'] == 3) echo ' selected="selected"'; ?>>3</option>
           <option <?php if ($row['a1'] == 4) echo ' selected="selected"'; ?>>4</option>
           <option <?php if ($row['a1'] == 5) echo ' selected="selected"'; ?>>5</option>
           <option <?php if ($row['a1'] == 6) echo ' selected="selected"'; ?>>6</option>
           <option <?php if ($row['a1'] == 7) echo ' selected="selected"'; ?>>7</option>
           <option <?php if ($row['a1'] == 8) echo ' selected="selected"'; ?>>8</option>
           <option <?php if ($row['a1'] == 9) echo ' selected="selected"'; ?>>9</option>
           <option <?php if ($row['a1'] == 10) echo ' selected="selected"'; ?>>10</option>
           <option <?php if ($row['a1'] == 11) echo ' selected="selected"'; ?>>11</option>
           <option <?php if ($row['a1'] == 12) echo ' selected="selected"'; ?>>12</option>
        </select>
        <input type="hidden" value="<?php echo intval($row['a1']); ?>" id="hiddena1"/></td>
    <td style="text-align:center">CCP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A2 Kawalan serangga perosak / LILATI yang efektif termasuk kawalan<br/>
        &#9899; lipas<br/>
        &#9899; lalat<br/>
        &#9899; tikus<br/>
        &#9899; lain lain haiwan<br/></td>
    <td style="text-align:center"><br/><br/>
        1<br/>
        1<br/>
        1<br/>
        1<br/></td>
    <td style="text-align:center"><br><br>
    
        <input type="hidden" value="0" name="a2_1" id="a2_1">
        <input type="hidden" value="0" name="a2_2" id="a2_2">
        <input type="hidden" value="0" name="a2_3" id="a2_3">
        <input type="hidden" value="0" name="a2_4" id="a2_4">  
        <input type="checkbox" name="a2_1" value="1"  <?php echo ($row['a2_1']==1 ? 'checked' : '');?>><br>
        <input type="checkbox"  value="1" name="a2_2"  <?php echo ($row['a2_2']==1 ? 'checked' : '');?>><br>
        <input type="checkbox"  value="1" name="a2_3"  <?php echo ($row['a2_3']==1 ? 'checked' : '');?>><br>
        <input type="checkbox"  value="1" name="a2_4"  <?php echo ($row['a2_4']==1 ? 'checked' : '');?>><br></td>
    <td><textarea  cols="25" rows="7" name="ta1"><?php echo $row["ta1"];  ?></textarea>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A3 kebersihan peti sejuk<br/>
        &#9899; peti sejuk sentiasa bersih<br/>
        &#9899; susunan makanan dalam keadaan teratur<br/>
        &#9899; tiada pencemaran silang<br/></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        1</td>
    <td style="text-align:center"><br>
    <input type="hidden" value="0" name="a3_1" id="a3_1">
    <input type="hidden" value="0" name="a3_2" id="a3_2">
    <input type="hidden" value="0" name="a3_3" id="a3_3">
        <input type="checkbox" name="a3_1" value="1" <?php echo ($row['a3_1']==1 ? 'checked' : '');?>><br>
        <input type="checkbox" name="a3_2" value="1" <?php echo ($row['a3_2']==1 ? 'checked' : '');?>><br>
        <input type="checkbox" name="a3_3" value="1" <?php echo ($row['a3_3']==1 ? 'checked' : '');?>><br></td>
    <td><textarea cols="25" name="ta2" rows="5" ><?php echo $row["ta2"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A4 Kebersihan peralatan dan kemudahan memasak<br />
        &#9899; alas memotong dan kain pengelap dalam keadaan bersih<br />
        &#9899; dilarang mengunakan kertas bercetak yang bersentuhan dengan makanan<br />
        &#9899; peralatan kulinari sentiasa dalam keadaan baik dan bersih<br /></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        <br />
        1</td>
    <td style="text-align:center"><br>
    <input type="hidden" value="0" name="a4_1" id="a4_1">
    <input type="hidden" value="0" name="a4_2" id="a4_2">
    <input type="hidden" value="0" name="a4_3" id="a4_3">
        <input name="a4_1" type="checkbox" value="1" <?php echo ($row['a4_1']==1 ? 'checked' : '');?>><br>
        <input type="checkbox" value="1" name="a4_2" <?php echo ($row['a4_2']==1 ? 'checked' : '');?>><br><br>
        <input type="checkbox" value="1" name="a4_3" <?php echo ($row['a4_3']==1 ? 'checked' : '');?>><br></td>
    <td><textarea cols="25" rows="5" name="ta3" ><?php echo $row["ta1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A5 Sistem pelepasan asap dan haba<br/>
        &#9899; Berfungsi dengan baik serta tidak menimbulkan kacauganggu<br/>
        &#9899; kapasiti yang mencukupi dan efisyen<br/></td>
    <td style="text-align:center"><br />1<br />1</td>
    <td style="text-align:center"><br>
    <input type="hidden" value="0" name="a5_1" id="a5_1">
    <input type="hidden" value="0" name="a5_2" id="a5_2">
        <input type="checkbox" name="a5_1" value="1" <?php echo ($row['a5_1']==1 ? 'checked' : '');?>><br>
        <input type="checkbox"name="a5_2" value="1" <?php echo ($row['a5_2']==1 ? 'checked' : '');?>><br></td>
    <td><textarea cols="25" name="ta4" rows="5" ><?php echo $row["ta4"];  ?></textarea></td>
  </tr>
  
   <tr>
    <td>&nbsp;</td>
    <td>A6 Ruang kelegaan di antara peralatan dan dinding/lantai<br />
        &#9899; jarak minima yang sesuai untuk penyelenggaraan dan tiada kesesakan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="a6_1" id="a6_1">
        <input type="checkbox" name="a6_1" value="1" <?php echo ($row['a6']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="ta5" rows="5" ><?php echo $row["ta5"];  ?></textarea></td>
  </tr>
</table>

</div>

<div id="frame2" style="display:none;">
 <table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>B<br/>
        Kawasan penyajian makanan   
    </td>
    <td>B1. kawalan suhu dan tempat mempamerkan makanan yang sesuai <br/> 
        mengikut keadaan dan jenis makanan<br/>
        &#9899; suhu makanan panas >60c<br/>
        &#9899; suhu makanan dingin 1c hingga 4c<br/>
        &#9899; suhu makanan sejuk beku < - 18c</td>
    <td style="text-align:center">12</td>
    <td style="text-align:center">
   <select name="b1" id="b1" onChange="marks2();">
           <option <?php if ($row['b1_1'] == 0) echo ' selected="selected"'; ?>>0</option>
           <option <?php if ($row['b1_1'] == 1) echo ' selected="selected"'; ?>>1</option>
           <option <?php if ($row['b1_1'] == 2) echo ' selected="selected"'; ?>>2</option>
           <option <?php if ($row['b1_1'] == 3) echo ' selected="selected"'; ?>>3</option>
           <option <?php if ($row['b1_1'] == 4) echo ' selected="selected"'; ?>>4</option>
           <option <?php if ($row['b1_1'] == 5) echo ' selected="selected"'; ?>>5</option>
           <option <?php if ($row['b1_1'] == 6) echo ' selected="selected"'; ?>>6</option>
           <option <?php if ($row['b1_1'] == 7) echo ' selected="selected"'; ?>>7</option>
           <option <?php if ($row['b1_1'] == 8) echo ' selected="selected"'; ?>>8</option>
           <option <?php if ($row['b1_1'] == 9) echo ' selected="selected"'; ?>>9</option>
           <option <?php if ($row['b1_1'] == 10) echo ' selected="selected"'; ?>>10</option>
           <option <?php if ($row['b1_1'] == 11) echo ' selected="selected"'; ?>>11</option>
           <option <?php if ($row['b1_1'] == 12) echo ' selected="selected"'; ?>>12</option>
        </select>
        <input type="hidden" value="<?php echo intval($row['b1_1']); ?>" id="hiddenb1"/>
    </td>
    <td><textarea cols="25" name="tb1" rows="5"><?php echo $row["tb1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B2 peralatan kulinari yang digunakan untuk penyajian  makanan<br/>
        perlu sentiasa dalam keadaan.<br/>
        &#9899; bersih<br/>
        &#9899; tidak sumbing, retak or karat</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
    <input type="hidden" value="0" name="b2_1" id="b2_1">
    <input type="hidden" value="0" name="b2_2" id="b2_2">
                  <input type="checkbox" name="b2_1" value="1" <?php echo ($row['b2_1']==1 ? 'checked' : '');?>><br/>
                  <input type="checkbox" name="b2_2" value="1" <?php echo ($row['b2_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tb2" rows="5" ><?php echo $row["tb2"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B3 KAIN PENGELAP ALAS DAN PERALATAN<BR/>
        perlu sentiasa dalam keadaan<br/>
        &#9899; Bersih<br/>
        &#9899; digunakan berasingan mengikut jenis kerja</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
    <input type="hidden" value="0" name="b3_1" id="b3_1">
    <input type="hidden" value="0" name="b3_2" id="b3_2">
                  <input type="checkbox" name="b3_1" value="1" <?php echo ($row['b3_1']==1 ? 'checked' : '');?>><br/>
                  <input type="checkbox" name="b3_2" value="1" <?php echo ($row['b3_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tb3" rows="5"><?php echo $row["tb3"];  ?></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td>B4 meja kerusi dan peralatan hendak lah<br/>
        sentiasa<br/>
        &#9899; Bersih<br/>
        &#9899; sempurna dan selamat
        </td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
    <input type="hidden" value="0" name="b4_1" id="b4_1">
    <input type="hidden" value="0" name="b4_2" id="b4_2">
                  <input type="checkbox" name="b4_1" value="1" <?php echo ($row['b4_1']==1 ? 'checked' : '');?>><br/>
                  <input type="checkbox" name="b4_2" value="1" <?php echo ($row['b4_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tb4" rows="5"><?php echo $row["tb4"];  ?></textarea></td>
  </tr>
</table>

</div>

<div id="frame3" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>C<br/>pengendali makanan</td>
    <td>C1 pemeriksa kesihatan ke atas semua pengendali makanan<br/>
         &#9899; menadapat suntikan pelalian anti tifoid<br/>
         &#9899; menghadiri kursus pengendali makanan</td>
    <td style="text-align:center">6</td>
    <td style="text-align:center">
    <select name="c1" id="c1" onChange="marks3();">
           <option <?php if ($row['c1_1'] == 0) echo ' selected="selected"'; ?>>0</option>
           <option <?php if ($row['c1_1'] == 1) echo ' selected="selected"'; ?>>1</option>
           <option <?php if ($row['c1_1'] == 2) echo ' selected="selected"'; ?>>2</option>
           <option <?php if ($row['c1_1'] == 3) echo ' selected="selected"'; ?>>3</option>
           <option <?php if ($row['c1_1'] == 4) echo ' selected="selected"'; ?>>4</option>
           <option <?php if ($row['c1_1'] == 5) echo ' selected="selected"'; ?>>5</option>
           <option <?php if ($row['c1_1'] == 6) echo ' selected="selected"'; ?>>6</option>
        </select>
        <input type="hidden" value="<?php echo intval($row['c1_1']); ?>"id="hiddenc1"/>
    </td>
    <td>CPP</td>
  </tr>
  <div class="page-break"></div>
  <tr>
    <td>&nbsp;</td>
    <td>C2 tahap kebersihan diri yang baik<br/>
        &#9899; berpakaian bersih dan sesuai<br/>
        &#9899; memakai apron yang bersih dan berpenutup kepala<br/>
        &#9899; berkuku pendek bersih dan tidak memakai barang perhiasan diri<br/>
        &#9899; berkasut<br/>
        &#9899; tidak merokok<br/>
        &#9899; tidak melakukan apa apa perbuatan atau tindakan yang boleh <br/>
        menyebabkan pencemaran makanan </td>
    <td style="text-align:center">1<br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center"> 
    <input type="hidden" value="0" name="c2_1" id="c2_1">
    <input type="hidden" value="0" name="c2_2" id="c2_2">
    <input type="hidden" value="0" name="c2_3" id="c2_3">
    <input type="hidden" value="0" name="c2_4" id="c2_4">
    <input type="hidden" value="0" name="c2_5" id="c2_5">
    <input type="hidden" value="0" name="c2_6" id="c2_6">
         <input type="checkbox" name="c2_1" value="1"  <?php echo ($row['c2_1']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="c2_2" value="1"  <?php echo ($row['c2_2']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="c2_3" value="1" <?php echo ($row['c2_3']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="c2_4" value="1"  <?php echo ($row['c2_4']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="c2_5" value="1"  <?php echo ($row['c2_5']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="c2_6" value="1"  <?php echo ($row['c2_6']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tc1" rows="5" ><?php echo $row["tc1"];  ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C3 tiada masalah kesihatan yang berkaitan dengan pencemaran makanan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="c3_1" id="c3_1">
        <input type="checkbox" name="c3_1" value="1" <?php echo ($row['c3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tc2" rows="5" ><?php echo $row["tc2"];  ?></textarea></td>
  </tr>
</table>
</div>
<div id="frame4" style="display:none;">

<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>D<br/>sistem bekalan air</td>
    <td>D1 Sumber Bekalan air yg selamat<br/>
         &#9899; Terawat<br/>
         &#9899; berih dan mencukupi</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="d1_1" id="d1_1">
    <input type="hidden" value="0" name="d1_2" id="d1_2">
             <input type="checkbox" name="d1_1" value="1"  <?php echo ($row['a2_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="d1_2" value="1"  <?php echo ($row['a2_1']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="td1" rows="5" ><?php echo $row['td1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D2 pengunaan sumber bekalan air<br/>
        &#9899; diambil terus dari paip<br/>
        &#9899; dilarang penggunaan paip getah </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="d2_1" id="d2_1">
    <input type="hidden" value="0" name="d2_2" id="d2_2">
             <input type="checkbox" name="d2_1" value="1"  <?php echo ($row['d2_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="d2_2" value="1"  <?php echo ($row['d2_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="td2" rows="5" ><?php echo $row['td2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D3 Tiada kebocoran paip di premis</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="d3_1" id="d3_1">
        <input type="checkbox" name="d3_1" value="1"  <?php echo ($row['d3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25"  name="td3" rows="2" ><?php echo $row['td3']; ?></textarea></td>
  </tr>
</table>
</div>
<div id="frame5" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>E<br/>kemudahan sanitassi</td>
    <td>E1 keadaan kelengkapan kemudahan tandas<br/>
        &#9899; bersih dan bebas dari bau busuk<br/>
        &#9899; sempurna dan berfungsi dengan baik<br/>
        &#9899;kedudukan pintu tandas tidak boleh menghala terus ke kawasan <br/>
                penyediaan makanan<br/>
        &#9899; pengudaraan sempurna<br/>
        &#9899; bekalan air mencukupi<br/>
        &#9899; disediakan sabun dan tisu/alat pengering<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="e1_1" id="e1_1">
    <input type="hidden" value="0" name="e1_2" id="e1_2">
    <input type="hidden" value="0" name="e1_3" id="e1_3">
    <input type="hidden" value="0" name="e1_4" id="e1_4">
    <input type="hidden" value="0" name="e1_5" id="e1_5">
    <input type="hidden" value="0" name="e1_6" id="e1_6">
    
             <input type="checkbox" name="e1_1" value="1"  <?php echo ($row['e1_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e1_2" value="1"  <?php echo ($row['e1_2']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e1_3" value="1"  <?php echo ($row['e1_3']==1 ? 'checked' : '');?>><br/><br/>
             <input type="checkbox" name="e1_4" value="1"  <?php echo ($row['e1_4']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e1_5" value="1"  <?php echo ($row['e1_5']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e1_6" value="1"  <?php echo ($row['e1_6']==1 ? 'checked' : '');?>></td>

    <td><textarea cols="25" name="te1" rows="2" ><?php echo $row['te1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E2 kemudahan mencukupi<br/>
        &#9899; sinki yang mencukupi<br>
        &#9899; perangkap sisa makanan, minyak dan lemak(fog) berfungsi dan<br/>
        diselengara dengan baik.<br/>
        &#9899; kapasiti perangkap fog yg tersusun</td>
    <td style="text-align:center"><br/>1<br/>1<br/><br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="e2_1" id="e2_1">
    <input type="hidden" value="0" name="e2_2" id="e2_2">
    <input type="hidden" value="0" name="e2_3" id="e2_3">
    
             <input type="checkbox" name="e2_1" value="1"  <?php echo ($row['e2_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e2_2" value="1"  <?php echo ($row['e2_2']==1 ? 'checked' : '');?>><br/><br/>
             <input type="checkbox" name="e2_3" value="1"  <?php echo ($row['e2_3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="te2" rows="2" ><?php echo $row['te2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E3 kemudahan tempat mencuci tangan<br/>
        &#9899; bersih<br/>
        &#9899; sempurna<br/>
        &#9899; kemudahan sabun cecair dan pengering tangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="e3_1" id="e3_1">
    <input type="hidden" value="0" name="e3_2" id="e3_2">
    <input type="hidden" value="0" name="e3_3" id="e3_3">
    
             <input type="checkbox" name="e3_1" value="1"  <?php echo ($row['e3_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e3_2" value="1"  <?php echo ($row['e3_2']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="e3_3" value="1"  <?php echo ($row['e3_3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="te3" rows="2" ><?php echo $row['te3']; ?></textarea></td>
  </tr>
</table>
</div>
<div id="frame6" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>F Struktur dan penyenggaraan premis</td>
    <td>F1 keadaan lantai dinding dan siling<br/>
       &#9899; tidak licin tahan lasak<br/>
       &#9899; mudah dibersihkan<br/>
       &#9899; kalis air<br/>
       &#9899; tidak menakung air / rata<br/>
       &#9899; bebas dari sesawang habuk kulat<br/>
    </td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="f1_1" id="f1_1">
    <input type="hidden" value="0" name="f1_2" id="f1_2">
    <input type="hidden" value="0" name="f1_3" id="f1_3">
    <input type="hidden" value="0" name="f1_4" id="f1_4">
    <input type="hidden" value="0" name="f1_5" id="f1_5">
    
        <br/><input type="checkbox" name="f1_1" value="1"  <?php echo ($row['f1_1']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="f1_2" value="1"  <?php echo ($row['f1_2']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="f1_3" value="1"  <?php echo ($row['f1_3']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="f1_4" value="1"  <?php echo ($row['f1_4']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="f1_5" value="1"  <?php echo ($row['f1_5']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tf1" rows="2" ><?php echo $row['tf1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F2 Sistem pengudaraan dan pencahayaan<br/>
        &#9899; mencukupi<br/>
        &#9899; berfungsi.</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="f2_1" id="f2_1">
    <input type="hidden" value="0" name="f2_2" id="f2_2">
    
             <input type="checkbox" name="f2_1" value="1"  <?php echo ($row['f2_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="f2_2" value="1"  <?php echo ($row['f2_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tf2" rows="2" ><?php echo $row['tf2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F3 sistem perparitan yang sempurna<br/>
        &#9899; bersih<br/>
        &#9899; disenggara dengan baik<br/>
        </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
    <input type="hidden" value="0" name="f3_1" id="f3_1">
    <input type="hidden" value="0" name="f3_2" id="f3_2">
    
             <input type="checkbox" name="f3_1" value="1"  <?php echo ($row['f3_1']==1 ? 'checked' : '');?>><br/>
             <input type="checkbox" name="f3_2" value="1"  <?php echo ($row['f3_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tf3" rows="2" ><?php echo $row['tf3']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F4 sistem pengurusan air imbah yang sempurna<br/>
        &#9899; mengalir lancar<br/>
        &#9899; tiada sisa makanan</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="f4_1" id="f4_1">
    <input type="hidden" value="0" name="f4_2" id="f4_2">
        <br/><input type="checkbox" name="f4_1" value="1"  <?php echo ($row['f4_1']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="f4_2" value="1"  <?php echo ($row['f4_2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tf4" rows="2" ><?php echo $row['tf4']; ?></textarea></td>
  </tr>
</table>
</div>
<div id="frame7" style="display:none;">
<table id="A" width="100%" border="1">
  <tr>
    <th id="notprint" scope="col">Perkara</th>
    <th id="notprint" scope="col">komponen</th>
    <th id="notprint" scope="col">markah</th>
    <th id="notprint" scope="col">demerit</th>
    <th id="notprint" scope="col">catatan</th>
  </tr>
  <tr>
    <td>G lain lain generik</td>
    <td>G1 Maklumbalas pelangan</td>
    <td style="text-align:center">5</td>
    <td style="text-align:center">
      <select name="g1" id="g1" onChange="marks4();">
           <option <?php if ($row['g1'] == 0) echo ' selected="selected"'; ?>>0</option>
           <option <?php if ($row['g1'] == 1) echo ' selected="selected"'; ?>>1</option>
           <option <?php if ($row['g1'] == 2) echo ' selected="selected"'; ?>>2</option>
           <option <?php if ($row['g1'] == 3) echo ' selected="selected"'; ?>>3</option>
           <option <?php if ($row['g1'] == 4) echo ' selected="selected"'; ?>>4</option>
           <option <?php if ($row['g1'] == 5) echo ' selected="selected"'; ?>>5</option>
        </select>
        <input type="hidden" value="<?php echo intval($row['g1']); ?>" id="hiddeng1"/>
    </td>
    <td><textarea cols="25" name="tg1" rows="2" ><?php echo $row['tg1']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G2 kemudahan tong sampah yang mencukupi berpenutup bersih<br/>
        dan berkarung</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g2" id="g2">
        <input type="checkbox" name="g2" value="1"  <?php echo ($row['g2']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg2" rows="2" ><?php echo $row['tg2']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G3 bahan makanan dan bahan kimai hendaklah disimpan secara <br/>
        berasingan kedua duanya mestilah berlabel</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g3" id="g3">
        <input type="checkbox" name="g3" value="1"  <?php echo ($row['g3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg3" rows="2" ><?php echo $row['tg3']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G4 penyediaan dan pengurusan stor yang baik(fifo kalis kulat)<br/>
        &#9899; susun atur dan ruang kelegaan<br/>
        &#9899; kebersihan<br/>
        &#9899; pengudaraan dan pencahayaan<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g4_1" id="g4_1">
    <input type="hidden" value="0" name="g4_2" id="g4_2">
    <input type="hidden" value="0" name="g4_3" id="g4_3">
        <br/><input type="checkbox" name="g4_1" value="1"  <?php echo ($row['g4_1']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="g4_2" value="1"  <?php echo ($row['g4_2']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="g4_3" value="1"  <?php echo ($row['g4_3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg4" rows="5" ><?php echo $row['tg4']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G5 amalan pengurusan sisa pepejal yang baik<br/>
        (pengasigan di punca</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g5" id="g5">
     <input type="checkbox" name="g5" value="1"  <?php echo ($row['g5']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg5" rows="3" ><?php echo $row['tg5']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G6 premis dan peralatan perlu disengara dengan baik dan<br/>
        jadual pembersihan mestilah di pantau secara berterusan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g6" id="g6">
        <input type="checkbox" name="g6" value="1" <?php echo ($row['g6']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg6" rows="3" ><?php echo $row['tg6']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G7 Notis pemberitahuan kebersihan amalan<br/>
        keselamatan pendidikan kesihatan dan larangan<br/>
        merokok</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
    <input type="hidden" value="0" name="g7" id="g7">
     <input type="checkbox" name="g7" value="1"  <?php echo ($row['g7']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg7" rows="3" ><?php echo $row['tg7']; ?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G8 kawalan dan keselamatan di premis makanan<br/>
        &#9899; alat pemadam api<br/>
        &#9899; peti pertolongan ccemas<br/>
        &#9899; ruang bebas dari sebarang halangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center;">
    <input type="hidden" value="0" name="g8_1" id="g8_1">
    <input type="hidden" value="0" name="g8_2" id="g8_2">
    <input type="hidden" value="0" name="g8_3" id="g8_3">
    
        <br/><input type="checkbox" name="g8_1" value="1"  <?php echo ($row['g8_1']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="g8_2" value="1"  <?php echo ($row['g8_2']==1 ? 'checked' : '');?>><br/><input type="checkbox" name="g8_3" value="1" style="position:relative;" <?php echo ($row['g8_3']==1 ? 'checked' : '');?>></td>
    <td><textarea cols="25" name="tg8" rows="5" ><?php echo $row['tg8']; ?></textarea></td>
  </tr>
</table>

 
</div>

  </form>
  

  <?php
}
?>

    
    <div class="dummy2"> 

</div>
    
    </main>
    </div>
    
    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
            
            
             <button class="addrecord" id="addrecord1" type="button" onclick="" >Grading Management</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord1").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
            
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "searchform2.php";
            };
	        </script>
            
             <button class="reportbutton" id="myinfo" type="button" onclick="">my Info</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo2.php";
            };
	        </script>
            
            
       
            
              <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="Logout">
            </form>
            
             <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js2.js"></script>
<script>
  
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  </script>




</body>
</html>

<script>  
  var form1 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f1.style.display = 'block';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form2 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f2.style.display = 'block';
	f1.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form3 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f3.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form4 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f4.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
  }
  
   var form5 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f5.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f6.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form6 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f6.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f7.style.display = 'none';
	window.scrollTo(0, 550);
	
  }
  
   var form7 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f7.style.display = 'block';
	f1.style.display = 'none';
	f2.style.display = 'none';
	f3.style.display = 'none';
	f4.style.display = 'none';
	f5.style.display = 'none';
	f6.style.display = 'none';
	window.scrollTo(0, 550);
  }
  
  
 
  
  
		 $(document).ready(function(){
    $("#flip").click(function(){
        $("#pantsu,#oppai").slideToggle("slow");
    });
});



 $(document).ready(function(){
    $("#flip").click(function(){
       $("#aa").toggle('slide',{ direction: "right" },400);
    });
});

$(document).ready(function(){
    $("#printweb").click(function(){
        window.open("Untitled-19.php");
    });
});



    $(document).ready(function() {
            $("#flip").click(function(event){
              
			 var logo = $("#flip").css('background-image');
             var cleanup = /\"|\'|\)/g;
             
			 if(logo.split('/').pop().replace(cleanup, '') == "up.jpg"){
				$("#flip").css("background-image", "url(down.jpg)");  
			 }
			 else{
				$("#flip").css("background-image", "url(up.jpg)");   
			 }
            });
         });
		  
		  
		  
		   
  $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
			 var id = this.id;
			 var f1 = document.getElementById('currentmark').value;
			
			if(id == "tibid" || id == "kursus"){
            
			}
			else{
			if($(this).prop("checked") == true){
				f1 = f1 - 1;
                $('#currentmark').val(f1);   
            }
            else if($(this).prop("checked") == false){
				 f1 = parseInt(f1) + 1;
                 $('#currentmark').val(f1);  
            }	
			}
			currentgrade();
        });
    });
	
function marks1(){
	var f1 = document.getElementById('a1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddena1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddena1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddena1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddena1').val(f1);
		
	}
	
	currentgrade();
	
	}
	
	function marks2(){
	var f1 = document.getElementById('b1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddenb1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddenb1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenb1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenb1').val(f1);
		
	}
	currentgrade();
	
	}
  
  function marks3(){
	var f1 = document.getElementById('c1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddenc1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddenc1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenc1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenc1').val(f1);
		
	}
	currentgrade();
	
	}
  
  function marks4(){
	var f1 = document.getElementById('g1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddeng1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddeng1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddeng1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddeng1').val(f1);
		
	}
	currentgrade();
	
	}
	
	function currentgrade(){
		var f1 = document.getElementById('currentgrade').value;
		var f2 = document.getElementById('hiddena1').value;
		var f3 = document.getElementById('hiddenb1').value;
		var f4 = document.getElementById('hiddenc1').value;
		var f5 = document.getElementById('hiddeng1').value;
		var f6 = document.getElementById('currentmark').value;
		
		if(f6 >= 86 && f6 <= 100){
			if(f2 != 0 || f3 != 0 || f3 != 0){
				$('#currentgrade').val("B");
			}
			else{
				$('#currentgrade').val("A");
			}
			
			
		}
		else if(f6 >= 71 && f6 <= 85){
			$('#currentgrade').val("B");
		}
		else if(f6 >= 51 && f6 <= 70){
			$('#currentgrade').val("C");
		}
		else{
			$('#currentgrade').val("FAIL");
		}
		
		
		
		
		
	}

	
  
  

  
  
  
  
  
</script>



