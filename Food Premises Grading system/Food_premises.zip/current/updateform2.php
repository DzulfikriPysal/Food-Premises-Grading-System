<?php
error_reporting(E_ALL ^ E_DEPRECATED);
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  </head>
  
   <style>
  body {
  padding:1em;
  background: #fff;
  height:200px
  
}

table {
  border: px #fff solid;
  font-size: .9em;
  box-shadow: 0 0px 0px rgba(0,0,0,.25);
  width: 100%;
  border-collapse: collapse;
  border-radius: 0px;
 
}

th {
  text-align: left;
}
  
thead {
  font-weight: bold;
  color: #fff;
  background: #039BE5;
}
  
 td, th {
  padding: .2em .5em;
  vertical-align: middle;
}
  
 td {
  border-bottom: 0px solid rgba(0,0,0,.1);
  background: #fff;
  height:45px;
}

a {
  color: #ff
  ;
}
  
 
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
  th {
    text-align: right;
	height:45px;
  }
  
  table {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 5px rgba(0,0,0,.2);
  }
  
  thead {
    float: left;
    white-space: nowrap;
  }
  
  tbody {
    
    position: relative;
    white-space: nowrap;
  }
  
  tr {
    display: inline-block;
    vertical-align: top;
  }
  
  
  
</style>
 


<body>
<form method = "post" action = "<?php $_PHP_SELF ?>" >
                  <table>
                  <thead> 
                  <tr>
                  <th>Premise Name</th>   
                  <th>Onwer Name</th>  
                  <th>Owner Licence</th> 
                  <th>Phone Number</th>
                  <th>Licence Reference No</th> 
                  <th>Address</th>   
                  
                  </tr>
                  </thead>
                  
                  <tbody>
                  <tr>
                        
                        <td>
                           <?php
		 echo "<input name=\"premisesname\" type=\"text\" id=\"textbox\" required size=\"30\" value=\"" . $_SESSION['update7'] . "\">";
						   ?>
                           </td>
                     
                        
                        <td><?php
						   
		 echo "<input name=\"refno\" onkeypress=\"return isNumberKey(event)\" type=\"text\" id=\"textbox\" size=\"30\" value=\"" . $_SESSION["update4"] . "\">";
						   ?>
                          
                           </td>
                    
                        <td>
                           <?php
						   
		 echo "<input name=\"ownername\" type=\"text\" id=\"textbox\" required size=\"30\" value=\"" . $_SESSION['update'] . "\">";
						   ?>
                           </td>
                    
                       
                        <td>
                          <?php
						   
		 echo "<input name=\"ownerlicence\" type=\"text\" 
		onkeypress=\"return isNumberKey(event)\"
		 
		 type=\"number\" id=\"textbox\" required minlength=\"10\" maxlength=\"20\"  
		 value=\"" . $_SESSION["update2"] . "\">";
						   ?>
                           </td>
                  

                        <td>
                             <?php
		 echo "<input name=\"phone\" type=\"text\"
		 
		 onkeypress=\"return isNumberKey(event)\"
		 
		 type=\"number\" id=\"textbox\" required minlength=\"10\" maxlength=\"20\"  value=\"" . $_SESSION["update3"] . "\">";
						   ?>
                       </td>
                           
                   
                      
                        <td>
                         <?php
						   
		 echo "<textarea name=\"address\" id=\"textbox\" required size=\"30\">".$_SESSION['update8'] ."</textarea>";
						   ?>
                          
                           </td>
                    
                       
                    </tr>
                    </tbody>
                    
                  </table>
                  <input name = "add" type = "submit" id = "click"   style=" position:absolute; top:341px; left: 254px; background-color:#ffc107; color:#FFF; border:none" 
                              value = "Update" >
               </form>
               
               
               
                <?php
 error_reporting(E_ALL ^ E_DEPRECATED);

# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connect = "localhost";
$database_connect = "premises";
$username_connect = "root";
$password_connect = "";
$connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);
         
		 if(isset($_POST["add"])){
			  $idDelete = $_SESSION["update7"];
			 
              $name1 = $_POST['ownername'];
              $id1 = $_POST['ownerlicence'];
              $phone1 = $_POST['phone'];  
			  $norujlesen = $_POST['refno'];  
			  $premisesname = $_POST['premisesname'];  
			  $address = $_POST['address'];  
			  
			 
			  $datecreate = $_SESSION['update5'];
			  $createby = $_SESSION['update6'];
			  
			  
			  
			  
			  $_SESSION["update"] = $name1;
			  $_SESSION["update2"] = $id1;
			  $_SESSION["update3"] = $phone1;
			  $_SESSION["update4"] = $norujlesen;
			  $_SESSION["update7"] = $premisesname;
			  $_SESSION["update8"] = $address;
			 
			  
              $sql = "DELETE FROM premisesowner WHERE premisesname='$idDelete'";  
   
              mysql_select_db('premises');
              $retval = mysql_query( $sql, $connect );

    
   $sql = 'INSERT INTO premisesowner '.
      '(premisesname,address,namepelesen,nokppelesen,notel,norujlesen,datecreate,createby) '.
      "VALUES ('$premisesname','$address', '$name1','$id1','$phone1','$norujlesen','$datecreate','$createby')";
	  
   mysql_select_db('premises');
   $retval = mysql_query( $sql, $connect );

   
		 }
		
		 
		    
   
     function refresh(){
			 
			$page = $_SERVER['PHP_SELF'];
            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
			 
		 }
		 
		 if(isset($_POST['add']))
          {
	      refresh();
          }
  
		
	
mysql_close($connect);
?>

<script>
 function submitenter(myfield,e) { 
    var keycode; 
	if (window.event) keycode = window.event.keyCode; 
	else if (e) keycode = e.which; else return true; 
	if (keycode == 13) { 
	document.getElementById("sdata").click(); return false; 
	} 
	  else return true; }
	  
	  function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }



</script>
   
</body>
</html>