<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
    <link rel="stylesheet" href="css3.css">
    
  <style>
  body {
  padding:1em;
  background: #fff;
  height:300px
  
}

table {
  border: px #fff solid;
  font-size: .9em;
  box-shadow: 0 0px 0px rgba(0,0,0,.25);
  width: 100%;
  border-collapse: collapse;
  border-radius: 0px;
 
}

th {
  text-align: left;
}
  
thead {
  font-weight: bold;
  color: #fff;
  background: #43a047;
}
  
 td, th {
  padding: 1em .5em;
  vertical-align: middle;
}
  
 td {
  border-bottom: 0px solid rgba(0,0,0,.1);
  background: #fff;
}

a {
  color: #ff;
}
  
 @media all and (max-width: 768px) {
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
  th {
    text-align: right;
  }
  
  table {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 5px rgba(0,0,0,.2);
  }
  
  thead {
    float: left;
    white-space: nowrap;
  }
  
  tbody {
    
    position: relative;
    white-space: nowrap;
  }
  
  tr {
    display: inline-block;
    vertical-align: top;
  }
  
  
  }
</style>
    
</head>


</html>

<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

		 if(isset($_POST["search"])){
			 
              $id1 = $_POST['searchid'];
          
			 
			
			$query = mysql_query("SELECT * FROM premisesowner where id = '$_POST[searchid]' ") or die(     
			    mysql_error());
	        $row = mysql_fetch_array($query);
			
			 $_SESSION['update']  = $row['namepelesen'];
		     $_SESSION['update2'] = $row['nokppelesen'];
			 $_SESSION['update3'] = $row['notel'];
		     $_SESSION['update4'] = $row['norujlesen'];
			 $_SESSION['update5'] = $row['datecreate'];
			 $_SESSION['update6'] = $row['createby'];
			 
			 
	        if(!empty($row['premisesname']) )
	        {
				
				
	echo '<table> <thead> <tr>';
     echo '   <th>Owner Name :</th>';
     echo '   <th>Owner Licence :</th>';
       echo ' <th>Phone Number :</th>';
       echo ' <th>Licence Reference No :</th>';
       echo ' <th>Date Created :</th>';
      echo '  <th>Created By :</th>';

   echo ' </tr> </thead> <tbody> <tr>';
      echo '  <td>'. $row['namepelesen'] .'</td>';
   echo ' </tr> </tbody><tbody> <tr>';
    echo '    <td>'. $row['nokppelesen'] .'</td>';
   echo ' </tr></tbody> <tbody><tr>';
      echo '  <td>'. $row['notel'] .'</td>';
   echo ' </tr> </tbody> <tbody><tr>';
       echo ' <td>'. $row['norujlesen'] .'</td>';
   echo ' </tr></tbody><tbody> <tr>';
    echo '<td>'. $row['datecreate'];
	          
	echo '</td>';
   echo ' </tr></tbody> <tbody><tr>';
    echo '    <td>'. $row['createby'] .'</td>';
   echo ' </tr> </tbody></table>';
				
		      
			   
			}else{
				
				 echo "ID didnt exist";
				
			}

		 }
		 mysql_close($con);

?>