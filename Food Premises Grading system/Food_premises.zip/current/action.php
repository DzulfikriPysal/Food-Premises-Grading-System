<?php
session_start();
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'premises';
$conn = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);

if(!$conn){
    die("Database connection failed: " . mysqli_connect_error());
}
if(isset($_POST['checked_id'])){
if(isset($_POST['bulk_delete_submit'])){
    $idArr = $_POST['checked_id'];
    foreach($idArr as $id){
        mysqli_query($conn,"DELETE FROM user WHERE staffid ='$id'");
    }
    $_SESSION['success_msg'] = "User Successfully deleted";
    header("Location:usermodule.php");
}
}
else{

 $_SESSION['success_msg'] = "No user selected";
    header("Location:usermodule.php");

}
?>