<?php
session_start();
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'premises';
$conn = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);

if(!$conn){
    die("Database connection failed: " . mysqli_connect_error());
}

if(isset($_POST['bulk_delete_submit'])){
    $idArr = $_POST['checked_id'];
    foreach($idArr as $id){
        mysqli_query($conn,"DELETE FROM premisesdetail WHERE nosiriborang='$id'");
    }
    $_SESSION['success_msg'] = "Successfully deleted";
    header("Location:searchshop.php");
}









?>