<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());


		 if(isset($_POST["search"])){
			 
              $id1 = $_POST['searchid'];
			$query = mysql_query("SELECT * FROM premisesowner where id = '$_POST[searchid]' ") or die(   mysql_error());
	        $row = mysql_fetch_array($query);
			
			 $_SESSION['update']  = $row['namepelesen'];
		     $_SESSION['update2'] = $row['nokppelesen'];
			 $_SESSION['update3'] = $row['notel'];
		     $_SESSION['update4'] = $row['norujlesen'];
			 $_SESSION['update5'] = $row['datecreate'];
			 $_SESSION['update6'] = $row['createby'];
			 $_SESSION['update7'] = $row['premisesname'];
			 $_SESSION['update8'] = $row['address'];
			 
			 $_SESSION['success_msg'] = "Successfully Update premises";
	        if(!empty($row['premisesname']) )
	        {
				header("Location: updateform2.php");
			}else{
				 echo "ID didnt exist";
				}

    
    

  
		 }
		 
		 
		 mysql_close($con);

?>