<?php
session_start();
$id = $_SESSION["staffid"];
?>
<?php
header('Content-type: image/jpg');
error_reporting(E_ALL ^ E_DEPRECATED);
  
  $link = mysql_connect("localhost", "root", "");
  mysql_select_db("premises");
  $sql = "SELECT data FROM user WHERE staffid = '$id'";
  $result = mysql_query("$sql");
  $row = mysql_fetch_assoc($result);
  mysql_close($link);
  
    echo $row['data'] . "<br /><br /><br /><br /><br /><br /><br /><br /><br />";
	
	
?>