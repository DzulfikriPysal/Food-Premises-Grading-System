<?php
session_start();
 $type = $_SESSION["type"];
 $value = $_SESSION["value"];
 
 
include('database.php');
$database = new Database();
if($type == "viewall"){
$result = $database->runQuery("SELECT nosiriborang,tarikh,namasyarikat,nokppelesen,alamatpremis,grade,createby FROM premisesdetail ");
$header = $database->runQuery("SELECT UCASE(`COLUMN_NAME`) 
FROM `INFORMATION_SCHEMA`.`COLUMNS` 
WHERE `TABLE_SCHEMA`='premises' 
AND `TABLE_NAME`='premisesdetail'
and `COLUMN_NAME` in ('nosiriborang','tarikh','namasyarikat','nokppelesen','alamatpremis','grade','createby')");
}
else{
$result = $database->runQuery("SELECT nosiriborang,tarikh,namasyarikat,nokppelesen,alamatpremis,grade,createby FROM premisesdetail WHERE ".$type." LIKE '%$value%' ");
$header = $database->runQuery("SELECT UCASE(`COLUMN_NAME`) 
FROM `INFORMATION_SCHEMA`.`COLUMNS` 
WHERE `TABLE_SCHEMA`='premises' 
AND `TABLE_NAME`='premisesdetail'
and `COLUMN_NAME` in ('nosiriborang','tarikh','namasyarikat','nokppelesen','alamatpremis','grade','createby')");
}


require('fpdf/fpdf.php');

class PDF extends FPDF
{

function Footer()
{
    $this->SetY(-15);
    $this->SetFont('Arial','I',8);
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
	
	 date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i");
			  
			  $this->SetX(-50);
	$this->Cell(0,10,'Print by '.$_SESSION["staffid"] ." at " .$a,0,0,'C');
			  
			  
	
}

var $widths;
var $aligns;

function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,'C');
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h-5);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}



}


$col1 = "";
$col2 = "";
$col3 = "";
$col4 = "";
$col5 = "";
$col6 = "";
$col7 = "";
$totala = 0;
$totalb = 0;
$totalc = 0;
$totalf = 0;
 
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->SetWidths(array(24,24,45,29,32,12,24));

    if($type == "grade"){
		if($value == "F" || $value == "f"){
			$pdf->MultiCell(190,20,"Summary Report Of Premiss That Fail",0,'C',false);
		}
		else{
			$pdf->MultiCell(190,20,"Summary Report By Grade ".$value,0,'C',false);
		}
		
	}
	else if($type == "Month"){
		$pdf->MultiCell(190,20,"Summary Report By Month ".$value,0,'C',false);
	}
	
	else if($type == "Year"){
		$pdf->MultiCell(190,20,"Summary Report By Year ".$value,0,'C',false);
	}
	else if($type == "nokppelesen"){
		$pdf->MultiCell(190,20,"Summary Report By Owner IC ".$value,0,'C',false);
	}
	else{
		$pdf->MultiCell(190,20,"Summary Report of Food Premise Grading ",0,'C',false);
	}


	    $pdf->SetFillColor(0,0,255);
        $pdf->SetTextColor(255);
        $pdf->SetDrawColor(0,0,0);
        $pdf->SetLineWidth(.3);
	    $pdf->SetFont('Arial','B',10);
		$pdf->Cell(24,12,"Serial No.",1,0,'C',true);
		$pdf->Cell(24,12,"Date",1,0,'C',true);
		$pdf->Cell(45,12,"Premise Name",1,0,'C',true);
		$pdf->Cell(29,12,"Owner Licence",1,0,'C',true);
		$pdf->Cell(32,12,"Address",1,0,'C',true);
		$pdf->Cell(12,12,"Grade",1,0,'C',true);
		$pdf->Cell(24,12,"Check By",1,0,'C',true);
	
	
	$pdf->SetFillColor(224,235,255);
    $pdf->SetTextColor(0);
    $pdf->SetFont('Arial','B',9);
	
	$i = 0;
	
foreach($result as $row) {
$i++;
$k = 0;
	$pdf->SetFont('Arial','B',9);
	$pdf->Ln();
	foreach($row as $column){
		if($k == 0){
			$col1 = $column;
			$k++;
		}
		else if($k == 1){
			$col2 = $column;
			$k++;
		}
		else if($k == 2){
			$col3 = $column;
			$k++;
		}
		else if($k == 3){
			$col4 = $column;
			$k++;
		}
		else if($k == 4){
			$col5 = $column;
			$k++;
		}
		else if($k == 5){
			$col6 = $column;
			if($col6 == "A"){
				$totala++;
			}
			else if($col6 == "B"){
				$totalb++;
			}
			else if($col6 == "B"){
				$totalc++;
			}
			else{
				$totalf++;
			}
			$k++;
		}
		else if($k == 6){
			$col7 = $column;
			$pdf->Row(array($col1,$col2,$col3,$col4,$col5,$col6,$col7));
			$k++;
		}
		
	}
		
}
if($type == "grade"){
	
	$pdf->Ln();
	$pdf->MultiCell(190,20,"",0,'L',false);
	
	    $pdf->SetFillColor(0,0,255);
        $pdf->SetTextColor(255);
        $pdf->SetDrawColor(0,0,0);
        $pdf->SetLineWidth(.3);
		
	    $pdf->Cell(40,12,"Grade",1,0,'C',true);
		$pdf->Cell(40,12,"Total",1,0,'C',true);
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		$pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('Arial','B',9);
		$pdf->Cell(40,12,$value,1,0,'C');
		$pdf->Cell(40,12,$i,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');

		$pdf->Ln();
		
}
else{
	
		$pdf->Ln();
	    $pdf->SetFillColor(0,0,255);
        $pdf->SetTextColor(255);
        $pdf->SetDrawColor(0,0,0);
        $pdf->SetLineWidth(.3);
	    $pdf->MultiCell(190,20,"",0,'L',false);
	    $pdf->SetFont('Arial','B',9);
		
		$pdf->Cell(40,12,"Grade",1,0,'C',true);
		$pdf->Cell(40,12,"Total",1,0,'C',true);
		$pdf->Cell(20,12,"",0,0,'L');
		

		
		$pdf->Cell(40,12,"Number Of Premise",1,0,'C',true);
		
		$pdf->SetFillColor(224,235,255);
        $pdf->SetTextColor(0);
        $pdf->SetFont('Arial','B',9);
		
		$pdf->Cell(40,12,$i,1,0,'C',false);
		$pdf->Cell(10,12,"",0,0,'L');
		
		
		
		$pdf->Ln();
		$pdf->Cell(40,12,"A",1,0,'C');
		$pdf->Cell(40,12,$totala,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		$pdf->Cell(40,12,"B",1,0,'C');
		$pdf->Cell(40,12,$totalb,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		$pdf->Cell(40,12,"C",1,0,'C');
		$pdf->Cell(40,12,$totalc,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		$pdf->Cell(40,12,"Fail",1,0,'C');
		$pdf->Cell(40,12,$totalf,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		$pdf->Cell(40,12,"Total",1,0,'C');
		$pdf->Cell(40,12,$i,1,0,'C');
		$pdf->Cell(110,12,"",0,0,'L');
		$pdf->Ln();
		
	
}
$pdf->Output();
?>