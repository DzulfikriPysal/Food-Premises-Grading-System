<?php
    session_start();
    $_SESSION['service'] = $_POST['service'];
	echo $_SESSION['service'];
?>