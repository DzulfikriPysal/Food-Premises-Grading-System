
		          <?php
				  session_start();
           error_reporting(E_ALL ^ E_DEPRECATED);
           define('DB_HOST', 'localhost');
           define('DB_NAME', 'premises');
           define('DB_USER','root');
           define('DB_PASSWORD','');

           $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
           $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
            
            if(! $con ) {
               die('Could not connect: ' . mysql_error());
            }
            
              date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i:s.u");
			  
			  $id = $_SESSION["staffid"];
              
               $sql = "UPDATE user ". "SET lastseen = '$a', activity = '0' ". 
               "WHERE staffid = '$id'" ;
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $con );
			   
			   mysql_close($con);
			   session_destroy(); 
			   session_start();
			   $_SESSION['hehe'] = "wee";
			   header("Location: homepage.php");
				 
				 
?>
      