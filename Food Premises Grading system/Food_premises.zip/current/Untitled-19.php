<?php
session_start();
?>

<?php

require('aaaa/fpdf.php');
$haha = "haha";

class PDF extends FPDF
{
	protected $col = 0;
	protected $y0;
function Header()
{
    global $title;

    // Arial bold 15
	
	
	
	
    $this->Ln(10);
}


function SetCol($col)
{
    // Set position at a given column
    $this->col = $col;
    $x = 10+$col*65;
    $this->SetLeftMargin($x);
    $this->SetX($x);
}

function AcceptPageBreak()
{
    // Method accepting or not automatic page break
    if($this->col<2)
    {
        // Go to next column
        $this->SetCol($this->col+1);
        // Set ordinate to top
        $this->SetY($this->y0);
        // Keep on page
        return false;
    }
    else
    {
        // Go back to first column
        $this->SetCol(0);
        // Page break
        return true;
    }
}

function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Text color in gray
    $this->SetTextColor(128);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
	$this->SetX(-50);
	$this->Cell(0,10,'Print by '.$_SESSION["staffid"] ." at " .$_SESSION["timeprint"],0,0,'C');
	
}

function page1Title($num, $label)
{
   
}


function page4Body($totalg ,$total,$grade)
{
	$this->SetFont('Arial','B',9);
	$this->Cell(20,10,'Perkara',1,0,'C');
	$this->Cell(95,10,'Komponen',1,0,'C');
	$this->Cell(25,10,'Markah',1,0,'C');
	$this->Cell(25,10,'Demerit',1,0,'C');
	$this->Cell(25,10,'Catatan',1,1,'C');
	
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,10,'',1,'L',false);
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,5,"",0,'L',false);
	
	
	 $this->SetY(30);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan\n\n",1,'R',false);
	
	
	$this->SetY(30);
   $this->SetX(125);
   $this->MultiCell(25,5,"16\n\n",1,'C',false);
   
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,$totalg,0,'C',false);
   
   $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   $this->SetFont('Arial','B',12);
   $this->SetY(40);
   $this->SetX(10);
   $this->MultiCell(190,10,"\n",1,'C',false);
   $this->SetY(40);
   $this->SetX(10);
   $this->MultiCell(25,10,"Grade : " . $grade,0,'L',false);
   
   $this->SetY(50);
   $this->SetX(10);
   $this->MultiCell(190,10,"\n",1,'C',false);
   $this->SetY(50);
   $this->SetX(10);
   $this->MultiCell(190,10,"Marks : " . $total,0,'L',false);
   
}


function page3Body($totale,$totalf,$te2,$te3,$tf1,$tf2,$tf3,$tf4,$tg1,$tg2,$tg3,$tg4,$tg5,$tg6,$tg7,$tg8,$g1,$g2,$g3,$g4_1,$g4_2,$g4_3,$g5,$g6,$g7,$g8_1,$g8_2,$g8_3,$f1_1,$f1_2,$f1_3,$f1_4,$f1_5,$f2_1,$f2_2,$f3_1,$f3_2,$f4_1,$f4_2,$e2_1,$e2_2,$e2_3,$e3_1,$e3_2,$e3_3)
{
	$this->SetFont('Arial','B',9);
	$this->Cell(20,10,'Perkara',1,0,'C');
	$this->Cell(95,10,'Komponen',1,0,'C');
	$this->Cell(25,10,'Markah',1,0,'C');
	$this->Cell(25,10,'Demerit',1,0,'C');
	$this->Cell(25,10,'Catatan',1,1,'C');
	
	
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,55,'',1,'L',false);
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,5,"",0,'L',false);
	
	
	
	
	
	
	$this->SetY(30);
	$this->SetX(30);
	$this->MultiCell(95,5,"E2. Kemudahan mencukupi\n     -Sinki yang mencukupi\n     -Perangkap sisa makanan, minyak dan lemak(FOG) 
	   berfungsi dan diselenggara dengan baik.\n     -Kapasiti perangkap(FOG) yang bersesuaian",1,'L',false);
	
	$this->SetY(30);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n\n1\n",1,'C',false);
   
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$e2_1."\n".$e2_2."\n\n".$e2_3."\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,$te2,0,'L',false);
   
   
   $this->SetY(55);
	$this->SetX(30);
	$this->MultiCell(95,5,"E3. Kemudahan tempat mencuci tangan*\n     -Bersih\n     -Sempurna\n     -Kemudahan sabun cecair dan pengering tangan*.",1,'L',false);
	
	$this->SetY(55);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1\n",1,'C',false);
   
   $this->SetY(55);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$e3_1."\n".$e3_2."\n".$e3_3."\n",1,'C',false);
   $this->SetY(55);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(55);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n",1,'C',false);
   $this->SetY(55);
   $this->SetX(175);
   $this->MultiCell(25,5,$te3,0,'L',false);
   
    $this->SetY(75);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan\n\n",1,'R',false);
	
	
	$this->SetY(75);
   $this->SetX(125);
   $this->MultiCell(25,5,"12\n\n",1,'C',false);
   
   $this->SetY(75);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(75);
   $this->SetX(150);
   $this->MultiCell(25,5,$totale,0,'C',false);
   
    $this->SetY(75);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(75);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
   $this->SetY(85);
	$this->SetX(10);
	$this->MultiCell(20,85,'',1,'L',false);
	$this->SetY(85);
	$this->SetX(10);
	$this->MultiCell(20,5,"F. \nStruktur dan penyenggaraan premis",0,'L',false);
	
	
	
	 $this->SetY(85);
	$this->SetX(30);
	$this->MultiCell(95,5,"F1 Keadaan lantai, dinding dan siling\n     -Tidak licin / tahan lasak\n     -Mudah dibersihkan\n     -Kalis air\n     -Tidak menakung air / rata \n     -Bebas dari sesawang, habuk, kulat\nF2. Sistem pengudaraan dan ppencahayaan.\n     -Bersih\n     -Berfungsi*.\nF3.Sistem perparitan yang sempurna\n     -Bersih\n     -Disenggara dengan baik*.(Tiada kerosakan)\nF4.Sistem pengurusan air limbah yang sempurna*.\n     -Mengalir lancar\n     -Tiada sisa makanan.",1,'L',false);
	
	$this->SetY(85);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1\n1\n1\n\n1\n1\n\n1\n1\n\n1\n1",1,'C',false);
   
   $this->SetY(85);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$f1_1."\n".$f1_2."\n".$f1_3."\n".$f1_4."\n".$f1_5."\n\n".$f2_1."\n".$f2_2."\n\n".$f3_1."\n".$f3_2."\n\n".$f4_1."\n".$f4_2."\n",1,'C',false);
   $this->SetY(85);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(85);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",1,'C',false);
   $this->SetY(85);
   $this->SetX(175);
   $this->MultiCell(25,5,"-".$tf1."\n-".$tf2."\n-".$tf3."\n-".$tf4,0,'L',false);
   
   
    $this->SetY(160);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan\n\n",1,'R',false);
	
	
	$this->SetY(160);
   $this->SetX(125);
   $this->MultiCell(25,5,"11\n\n",1,'C',false);
   
   $this->SetY(160);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(160);
   $this->SetX(150);
   $this->MultiCell(25,5,$totalf,0,'C',false);
   
    $this->SetY(160);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(160);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
   
   $this->SetY(170);
	$this->SetX(10);
	$this->MultiCell(20,100,'',1,'L',false);
	$this->SetY(170);
	$this->SetX(10);
	$this->MultiCell(20,5,"G. Lain-lain\n(Generik)",0,'L',false);
   
   
   
   
   
	 $this->SetY(170);
	$this->SetX(30);
	$this->MultiCell(95,5,"G1. Maklum balas pelanggan",1,'L',false);
	
	$this->SetY(170);
   $this->SetX(125);
   $this->MultiCell(25,5,"5\n",1,'C',false);
   
   $this->SetY(170);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n",1,'C',false);
   $this->SetY(170);
   $this->SetX(150);
   $this->MultiCell(25,5,$g1,0,'C',false);
   
    $this->SetY(170);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n",1,'C',false);
   $this->SetY(170);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg1,0,'L',false);
   
    $this->SetY(175);
	$this->SetX(30);
	$this->MultiCell(95,5,"G2. Kemudahan tong sampah yang mencukupi, berpenutup, bersih, dan berkarung.",1,'L',false);
	
	$this->SetY(175);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(175);
   $this->SetX(150);
   $this->MultiCell(25,5,$g2."\n\n",1,'C',false);
   $this->SetY(175);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(175);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(175);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg2,0,'L',false);
   
   
   
   $this->SetY(185);
	$this->SetX(30);
	$this->MultiCell(95,5,"G3 Bahan makanan dan bahan kimia hendaklah disimpan secara berasingan. Kedua-duanya mestilah berlabel.",1,'L',false);
	
	$this->SetY(185);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(185);
   $this->SetX(150);
   $this->MultiCell(25,5,$g3."\n\n",1,'C',false);
   $this->SetY(185);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(185);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(185);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg3,0,'L',false);
	
	
	
	$this->SetY(195);
	$this->SetX(30);
	$this->MultiCell(95,5,"G4. Penyediaan dan pengurusan stor yang baik(FIFO, kalis lilati)\n     -Susun atur dan ruang kelegaan\n     -Kebersihan\n     -Pengudaraan dan pencahayaan",1,'L',false);
	
	$this->SetY(195);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n\n1\n1\n1\n",1,'C',false);
   
   $this->SetY(195);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n".$g4_1."\n".$g4_2."\n".$g4_3."\n",1,'C',false);
   $this->SetY(195);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(195);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n",1,'C',false);
   $this->SetY(195);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg4,0,'L',false);
   
   
   $this->SetY(220);
	$this->SetX(30);
	$this->MultiCell(95,5,"G5. Amalan pengurusan sisa pepejal yang baik\n     (pengasingan di punca).",1,'L',false);
	
	$this->SetY(220);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(220);
   $this->SetX(150);
   $this->MultiCell(25,5,$g5."\n\n",1,'C',false);
   $this->SetY(220);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(220);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(220);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg5,0,'L',false);
   
   
    
   $this->SetY(230);
	$this->SetX(30);
	$this->MultiCell(95,5,"G6.Premis dan peralatan perlu disenggara dengan baik dan jadual pembersihan mestilah dipantau secara berterusan",1,'L',false);
	
	$this->SetY(230);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(230);
   $this->SetX(150);
   $this->MultiCell(25,5,$g6."\n\n",1,'C',false);
   $this->SetY(230);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(230);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(230);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg6,0,'L',false);
   
    
   $this->SetY(240);
	$this->SetX(30);
	$this->MultiCell(95,5,"G7.Notis pemberitahuan kebersihan, amalan keselamatan, pendidikan kesihatan dan larangan merokok*.",1,'L',false);
	
	$this->SetY(240);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(240);
   $this->SetX(150);
   $this->MultiCell(25,5,$g7."\n\n",1,'C',false);
   $this->SetY(240);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(240);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(240);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg7,0,'L',false);
   
    
   $this->SetY(250);
	$this->SetX(30);
	$this->MultiCell(95,5,"G8. Kawalan dan keselamatan di premis makanan\n     -Alat pemadam api\n     -Peti pertolongan cemas\n     -Ruang tangga bebas dari sebarang halangan.",1,'L',false);
	
	$this->SetY(250);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1\n",1,'C',false);
   
   $this->SetY(250);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$g8_1."\n".$g8_2."\n".$g8_3."\n",1,'C',false);
   $this->SetY(250);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(250);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n",1,'C',false);
   $this->SetY(250);
   $this->SetX(175);
   $this->MultiCell(25,5,$tg8,0,'L',false);
   
   
   
   
   
        
	
	
	
	
}

function page2Body($tb1,$tb2,$tb3,$tb4,$tc1,$tc2,$td1,$td2,$td3,$te1,$totalb,$totalc,$totald,$b1,$c1,$e1_1,$e1_2,$e1_3,$e1_4,$e1_5,$e1_6,$d1_1,$d1_2,$d2_1,$d2_2,$d3,$c2_1,$c2_2,$c2_3,$c2_4,$c2_5,$c2_6,$c3,$b2_1,$b2_2,$b3_1,$b3_2,$b4_1,$b4_2)
{
	$this->SetFont('Arial','B',9);
	$this->Cell(20,10,'Perkara',1,0,'C');
	$this->Cell(95,10,'Komponen',1,0,'C');
	$this->Cell(25,10,'Markah',1,0,'C');
	$this->Cell(25,10,'Demerit',1,0,'C');
	$this->Cell(25,10,'Catatan',1,1,'C');
	
	
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,85,'',1,'L',false);
	$this->SetY(30);
	$this->SetX(10);
	$this->MultiCell(20,5,"B.\nKawasan Penyajian Makanan",0,'L',false);
	
	$this->SetY(30);
	$this->SetX(30);
	$this->MultiCell(95,5,"B1. Kawalan suhu dan tempat mempamerkan makanan yang sesuai mengikut keadaan dan jenis makanan.\n     -Suhu makanan panas: >60C.\n     -Suhu makanan dingin: 1C hingga 4C.\n     -Suhu makanan sejuk beku: <-18C",1,'L',false);
	
	$this->SetY(30);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n\n12\n\n\n",1,'C',false);
   
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n\n\n\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n".$b1,0,'C',false);
   
    $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\nCPP\n\n\n",1,'C',false);
   $this->SetY(30);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
   $this->SetY(55);
	$this->SetX(30);
	$this->MultiCell(95,5,"B2. Peralatan kulinari yang digunakan untuk penyajian makanan perlu sentiasa dalam keadaan;*\n     -Bersih\n     -Tidak sumbing, retak atau karat",1,'L',false);
	
	
   $this->SetY(55);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n\n1\n1\n",1,'C',false);
   
   $this->SetY(55);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n".$b2_1."\n".$b2_2."\n",1,'C',false);
   $this->SetY(55);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(55);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n",1,'C',false);
   $this->SetY(55);
   $this->SetX(175);
   $this->MultiCell(25,5,$tb1,0,'L',false);
   
   
   
   
    $this->SetY(75);
	$this->SetX(30);
	$this->MultiCell(95,5,"B3, Kain pengelap, alas dan peralatan memotong mestilah;*\n     -Bersih\n     -Digunakan berasingan mengikut jenis kerja.",1,'L',false);
	
   $this->SetY(75);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n",1,'C',false);
   
   $this->SetY(75);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$b3_1."\n".$b3_2."\n",1,'C',false);
   $this->SetY(75);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(75);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n",1,'C',false);
   $this->SetY(75);
   $this->SetX(175);
   $this->MultiCell(25,5,$tb2,0,'L',false);
   
   
     $this->SetY(90);
	$this->SetX(30);
	$this->MultiCell(95,5,"B4. Meja, kerusi dan peralatan hendaklah sentiasa;\n     -Bersih\n     -Sempurna dan selamat",1,'L',false);
   
   
   
    $this->SetY(90);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n",1,'C',false);
   
   $this->SetY(90);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$b4_1."\n".$b4_2."\n",1,'C',false);
   $this->SetY(90);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(90);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n",1,'C',false);
   $this->SetY(90);
   $this->SetX(175);
   $this->MultiCell(25,5,$tb3,0,'L',false);
   
   
   
    $this->SetY(105);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan\n\n",1,'R',false);
	
	
	$this->SetY(105);
   $this->SetX(125);
   $this->MultiCell(25,5,"18\n\n",1,'C',false);
   
   $this->SetY(105);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(105);
   $this->SetX(150);
   $this->MultiCell(25,5,$totalb,0,'C',false);
   
    $this->SetY(105);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(105);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
   
   $this->SetY(115);
   $this->SetX(10);
   $this->MultiCell(20,76,"",1,'L',false);
   $this->SetY(115);
   $this->SetX(10);
   $this->MultiCell(20,5,"C. Pengendali Makanan",0,'L',false);
   
   
   $this->SetY(115);
   $this->SetX(30);
   $this->MultiCell(95,5,"C1. Pemeriksa kesihatan ke atas semua pengendali makanan\n     -mendapat suntikan pelalian anti tifoid\n     -Menghadiri kursus pengendali makanan",1,'L',false);
   
   
   $this->SetY(115);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n6\n\n",1,'C',false);
   
   $this->SetY(115);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n\n",1,'C',false);
   $this->SetY(115);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$c1,0,'C',false);
   
    $this->SetY(115);
   $this->SetX(175);
   $this->MultiCell(25,5,"CPP\n\n\n",1,'C',false);
   $this->SetY(115);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   $this->SetY(130);
   $this->SetX(30);
   $this->MultiCell(95,5,"C2. Tahap kebersihan diri yang baik;\n     -Berpakaiaan bersih dan bersesuaian\n     -memakai apron yang bersih dan berpenutup kepala\n     -Berkuku pendek, bersih, dan tidak memakai barang
     perhiasan diri\n     -Berkasut\n     -Tidak merokok\n     -Tidak melakukan apa-apa perlakuan atau tindakan yang 
	    boleh menyebabkan pencemaran makanan",1,'L',false);
   
   
   $this->SetY(130);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1\n\n1\n1\n1\n\n",1,'C',false);
   
   $this->SetY(130);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$c2_1."\n".$c2_2."\n".$c2_3."\n\n".$c2_4."\n".$c2_5."\n".$c2_6."\n\n",1,'C',false);
   $this->SetY(130);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(130);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n\n\n\n",1,'C',false);
   $this->SetY(130);
   $this->SetX(175);
   $this->MultiCell(25,5,$tc1,0,'L',false);
   
   
   
   $this->SetY(175);
   $this->SetX(30);
   $this->MultiCell(95,5,"C3. Tiada masalah kesihatan yang berkaitan dengan pencemaran makanan",1,'L',false);
   
   
   $this->SetY(175);
   $this->SetX(125);
   $this->MultiCell(25,5,"1\n\n",1,'C',false);
   
   $this->SetY(175);
   $this->SetX(150);
   $this->MultiCell(25,5,$c3."\n\n",1,'C',false);
   $this->SetY(175);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(175);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n",1,'C',false);
   $this->SetY(175);
   $this->SetX(175);
   $this->MultiCell(25,5,$tc2,0,'L',false);
   
   
   
    $this->SetY(185);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan",0,'R',false);
	$this->SetY(185);
	$this->SetX(30);
	$this->MultiCell(95,3,"\n\n",1,'R',false);
	
	$this->SetY(185);
   $this->SetX(125);
   $this->MultiCell(25,5,"13",0,'C',false);
   $this->SetY(185);
   $this->SetX(125);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   
   $this->SetY(185);
   $this->SetX(150);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   $this->SetY(185);
   $this->SetX(150);
   $this->MultiCell(25,5,$totalc,0,'C',false);
   
    $this->SetY(185);
   $this->SetX(175);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   $this->SetY(185);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
  
   
   $this->SetY(191);
   $this->SetX(10);
   $this->MultiCell(20,41,"",1,'L',false);
   $this->SetY(191);
   $this->SetX(10);
   $this->MultiCell(20,5,"D. Sistem Bekalan Air",0,'L',false);
   
   
    $this->SetY(191);
	$this->SetX(30);
	$this->MultiCell(95,5,"D1. Sumber bekalan air yang selamat\n     -Terawat\n     -Bersih dan mencukupi\nD2. Pengunaan sumber bekalan air\n     -Diambil terus dari paip\n     -Dilarang penggunaan paip getah\nD3.Tiada kebocoran paip di premis",1,'L',false);
	
	$this->SetY(191);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n\n1\n1\n1",1,'C',false);
   
   $this->SetY(191);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$d1_1."\n".$d1_2."\n\n".$d2_1."\n".$d2_2."\n".$d3."\n",1,'C',false);
   $this->SetY(191);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(191);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n\n",1,'C',false);
   $this->SetY(191);
   $this->SetX(175);
   $this->MultiCell(25,5,"-".$td1."\n-".$td2."\n-".$td3,0,'L',false);
   
    $this->SetY(226);
	$this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan\n\n",0,'R',false);
	$this->SetY(226);
	$this->SetX(30);
	$this->MultiCell(95,3,"\n\n",1,'R',false);
	
	$this->SetY(226);
   $this->SetX(125);
   $this->MultiCell(25,5,"5",0,'C',false);
   $this->SetY(226);
   $this->SetX(125);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   
   $this->SetY(226);
   $this->SetX(150);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   $this->SetY(226);
   $this->SetX(150);
   $this->MultiCell(25,5,$totald,0,'C',false);
   
    $this->SetY(226);
   $this->SetX(175);
   $this->MultiCell(25,3,"\n\n",1,'C',false);
   $this->SetY(226);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
   
    $this->SetY(232);
   $this->SetX(10);
   $this->MultiCell(20,40,"",1,'L',false);
   $this->SetY(232);
   $this->SetX(10);
   $this->MultiCell(20,5,"E. Kemudahan Sanitasi",0,'L',false);
   
   
    $this->SetY(232);
	$this->SetX(30);
	$this->MultiCell(95,5,"E1. Keadaan kelengkapan kemudahan tandas\n     -Bersih dan bebas dari bau busuk\n     -Sempurna dan berfungsi dengan baik\n     -Kedudukan pintu tandas tidak boleh menghala terus ke kawasan penyediaan makanan\n     -Pengudaraan sempurna\n     -Bekalan air mencukupi\n     -Disediakan sabun dan tisu / alat pengering",1,'L',false);
	
	
	$this->SetY(232);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1\n\n1\n1\n1",1,'C',false);
   
   $this->SetY(232);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$e1_1."\n".$e1_2."\n".$e1_3."\n\n".$e1_4."\n".$e1_5."\n".$e1_6."\n",1,'C',false);
   $this->SetY(232);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(232);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n\n\n",1,'C',false);
   $this->SetY(232);
   $this->SetX(175);
   $this->MultiCell(25,5,$te1,0,'L',false);
			
}



//part 1
function page1Body($info1, $info2, $info3, $info4, $info5, $info6, $info7, $info8, $info9, $info10, $ta1, $ta2, $ta3, $ta4, $ta5,$totala,$a1,$a2_1,$a2_2,$a2_3,$a2_4,$a3_1,$a3_2,$a3_3,$a4_1,$a4_2,$a4_3,$a5_1,$a5_2,$a6,$info11,$info12,$info13)
{
	$haha123 = "";
	
	$this->Image('yuhu.png',10,8,33);
	$this->SetFont('Arial','B',12);
	$this->SetY(8);
	$this->SetX(-58);
    $this->Cell(155,5,'Series No. :',0,1);
	$this->SetY(8);
   $this->SetX(-33);
   $this->MultiCell(30,5,$info1,0,'L',false);
    
    
	$this->SetY(10);
	$this->SetX((90)/2);
    $this->Cell(155,5,'DEWAN BANDARAYA KOTA KINABALU',0,1);
	$this->SetFont('Arial','I',9);
	$this->SetX((90)/2);
	$this->Cell(155,5,'No.1,Jalan Bandaran, 88675 Kota Kinabalu,Sabah,Malaysia',0,1);
	
	
	
	$this->SetFont('Arial','I',9);
	$this->SetX((90)/2);
	$this->Cell(155,5,'Tel: 088-521800 Faks: 088-21975',0,1);
	
	$this->SetFont('Arial','I',9);
	$this->SetX((90)/2);
	$this->Cell(155,5,'088-244000 (Tingkatan 7, Center Point, Kota Kinabalu) Faks:088-246501',0,1);
	
	$this->SetFont('Arial','I',9);
	$this->SetX((90)/2);
	$this->Cell(155,5,'Laman Web: http//www.dbkk.sabah.gov.my',0,1);
	
	 $this->SetFont('Arial','',12);
    $this->Cell(0,6,"BORANG PEMERIKSAAN DAN PENGGREDAN PREMIS MAKANAN",0,1,'C');
    $this->Ln(4);
    
	
   $this->SetFont('Arial','B',9);
   $this->Cell(95,10,'Nama Pelesen   : '.$info2,0,0,'L');
   $this->Cell(95,10,'No K/P Pelesen : '.$info9,0,1,'L');
   $this->Cell(95,10,'Nama Syarikat  : '.$info4,0,0,'L');
   $this->Cell(95,10,'Nama Tel  : '.$info6,0,1,'L');
   
   $this->SetY(65);
   $this->SetX(10);
   $this->MultiCell(60,10,'Alamat Premis : ',0,'L',false);
   
   $this->SetY(65);
   $this->SetX(40);
   $this->MultiCell(60,10,$info10,0,'L',false);
   $this->MultiCell(60,10,"",0,'L',false);
   
   
   $this->SetY(65);
   $this->SetX(105);
   $this->Cell(95,10,'No Ruj Lesen : '.$info3,0,1);
    $this->Cell(35,10,'',0,0,'L');
   $this->Cell(60,10,'',0,0,'L');
   $this->Cell(95,10,'Tarikh :'.$info5,0,1);
    $this->Cell(35,10,'',0,0,'L');
   $this->Cell(60,10,'',0,0,'L');
   $this->Cell(95,10,'Masa : '.$info7 ." - ".$info8,0,1);
   
   
   
   $this->Cell(60,10,'Pengendali : Bil.Pengendali   '.$info11,0,0,'L');
   $this->Cell(70,10,' Suntikan Pelalian Anti-Tifoid  '.$info12,0,0,'L');
   $this->Cell(60,10,'  Kursus Pengendali Makanan   '.$info13.'',0,1,'L');
   
	$this->Cell(20,10,'Perkara',1,0,'C');
	$this->Cell(95,10,'Komponen',1,0,'C');
	$this->Cell(25,10,'Markah',1,0,'C');
	$this->Cell(25,10,'Demerit',1,0,'C');
	$this->Cell(25,10,'Catatan',1,1,'C');
	
	
	$this->MultiCell(20,5,"A. \nKawasan Penyediaan Makanan",0,'L',false);
	$this->SetY(115);
   $this->SetX(10);
	$this->MultiCell(20,140,"",1,'L',false);
	
	
	$this->SetY(115);
   $this->SetX(30);
	$this->MultiCell(95,5,"A1. Kawalan suhu dalam penyimpanan dan penyediaan makanan. \n      Peti sejuk:\n      -Suhu sejuk beku:-18C hingga 0C.\n      -Suhu dingin(chiller): 1C hingga 4C.",1,'L',false);
	
	
	
   $this->SetY(115);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n\n12\n\n\n",1,'C',false);
   
   $this->SetY(115);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n".$a1."\n\n\n",1,'C',false);
   $this->SetY(115);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'C',false);
   
    $this->SetY(115);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\nCPP\n\n\n",1,'C',false);
	
	

$this->SetY(140);
   $this->SetX(30);
	$this->MultiCell(95,5,"A2. Kawalan serangga perosak / LILATI yang efektif termasuk kawalan \n      -Lipas.\n      -Lalat\n      -Tikus\n      -Lain-lain haiwan.",1,'L',false);
	
	
	$this->SetY(140);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n\n1\n1\n1\n1\n",1,'C',false);
   
   $this->SetY(140);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n\n".$a2_1."\n".$a2_2."\n".$a2_3."\n".$a2_4."\n",1,'C',false);
   $this->SetY(140);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(140);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n",1,'C',false);
   $this->SetY(140);
   $this->SetX(175);
   $this->MultiCell(25,5,$ta1,0,'L',false);
	
	$this->SetY(170);
   $this->SetX(30);
	$this->MultiCell(95,5,"A3. Kebersihan peti sejuk\n      -Peti sejuk sentiasa bersih\n      -Susunan makanan dalam keadaan teratur\n      -Tiada pencemaran silang.",1,'L',false);
	
	$this->SetY(170);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n1",1,'C',false);
   
   $this->SetY(170);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$a3_1."\n".$a3_2."\n".$a3_3."\n",1,'C',false);
   $this->SetY(170);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(170);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n",1,'C',false);
   $this->SetY(170);
   $this->SetX(175);
   $this->MultiCell(25,5,$ta2,0,'L',false);
   
   
   $this->SetY(190);
   $this->SetX(30);
	$this->MultiCell(95,5,"A4. Kebersihan peralatan dan kemudahan memasak.\n      -Alas pemotong dan kain pengelap dalam keadaan bersih\n      -Dilarang menggunakan kertas bercetak yang          
	      bersentuhan dengan makanan\n      -Peralatan kulinari sentiasa dalam keadaan baik dan       
		     bersih.",1,'L',false);
			 
   $this->SetY(190);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n1\n\n1\n\n",1,'C',false);
   
   $this->SetY(190);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$a4_1."\n".$a4_2."\n\n".$a4_3."\n\n",1,'C',false);
   $this->SetY(190);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(190);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n\n\n",1,'C',false);
   $this->SetY(190);
   $this->SetX(175);
   $this->MultiCell(25,5,$ta3,0,'L',false);
   
   
    $this->SetY(220);
   $this->SetX(30);
	$this->MultiCell(95,5,"A5. Sistem pelepasanasap dan haba\n      -Berfungsi dengan baik serta tidak menimbulkan 
	     kacauganggu\n      -Kapasiti yang mencukupi dan efisyen.",1,'L',false);
	
	$this->SetY(220);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n\n1\n",1,'C',false);
   
   $this->SetY(220);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$a5_1."\n\n".$a5_2."\n",1,'C',false);
   $this->SetY(220);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(220);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n\n",1,'C',false);
   $this->SetY(220);
   $this->SetX(175);
   $this->MultiCell(25,5,$ta4,0,'L',false);
   
   
    $this->SetY(240);
   $this->SetX(30);
	$this->MultiCell(95,5,"A6 Ruang kelegaan di antara peralatan dan dinding/lantai*.\n      -Jarak minima yang sesuai untuk penyelenggaraan dan 
	     tiada kesesakan.",1,'L',false);
		 
	$this->SetY(240);
   $this->SetX(125);
   $this->MultiCell(25,5,"\n1\n\n",1,'C',false);
   
   $this->SetY(240);
   $this->SetX(150);
   $this->MultiCell(25,5,"\n".$a6."\n\n",1,'C',false);
   $this->SetY(240);
   $this->SetX(150);
   $this->MultiCell(25,5,"",0,'L',false);
   
    $this->SetY(240);
   $this->SetX(175);
   $this->MultiCell(25,5,"\n\n\n",1,'C',false);
   $this->SetY(240);
   $this->SetX(175);
   $this->MultiCell(25,5,$ta5,0,'L',false);
   
   $this->SetY(255);
   $this->SetX(10);
   $this->MultiCell(20,3,"\n\n\n",1,'C',false);
   
    $this->SetY(258);
   $this->SetX(30);
	$this->MultiCell(95,5,"Keseluruhan",0,'R',false);
	$this->SetY(255);
   $this->SetX(30);
	$this->MultiCell(95,3,"\n\n\n",1,'C',false);
		 
	$this->SetY(255);
   $this->SetX(125);
   $this->MultiCell(25,3,"\n25\n\n",1,'C',false);
   
   $this->SetY(255);
   $this->SetX(150);
   $this->MultiCell(25,3,"\n\n\n",1,'C',false);
   $this->SetY(258);
   $this->SetX(150);
   $this->MultiCell(25,3,$totala,0,'C',false);
   
    $this->SetY(255);
   $this->SetX(175);
   $this->MultiCell(25,3,"\n\n\n",1,'C',false);
   $this->SetY(255);
   $this->SetX(175);
   $this->MultiCell(25,5,"",0,'L',false);
   
   
    
   
   
   
   
}

function page1($num, $title, $info1, $info2, $info3, $info4, $info5, $info6, $info7, $info8, $info9, $info10, $ta1, $ta2, $ta3, $ta4, $ta5,$totala,$a1,$a2_1,$a2_2,$a2_3,$a2_4,$a3_1,$a3_2,$a3_3,$a4_1,$a4_2,$a4_3,$a5_1,$a5_2,$a6,$info11,$info12,$info13)
{
    $this->AddPage();
    $this->page1Body($info1, $info2, $info3, $info4, $info5, $info6, $info7, $info8, $info9, $info10, $ta1, $ta2, $ta3, $ta4, $ta5,$totala,$a1,$a2_1,$a2_2,$a2_3,$a2_4,$a3_1,$a3_2,$a3_3,$a4_1,$a4_2,$a4_3,$a5_1,$a5_2,$a6,$info11,$info12,$info13);
}

function page2($num, $tb1,$tb2,$tb3,$tb4,$tc1,$tc2,$td1,$td2,$td3,$te1,$totalb,$totalc,$totald,$b1,$c1,$e1_1,$e1_2,$e1_3,$e1_4,$e1_5,$e1_6,$d1_1,$d1_2,$d2_1,$d2_2,$d3,$c2_1,$c2_2,$c2_3,$c2_4,$c2_5,$c2_6,$c3,$b2_1,$b2_2,$b3_1,$b3_2,$b4_1,$b4_2)
{
	
	
    $this->AddPage();
    $this->page2Body($tb1,$tb2,$tb3,$tb4,$tc1,$tc2,$td1,$td2,$td3,$te1,$totalb,$totalc,$totald,$b1,$c1,$e1_1,$e1_2,$e1_3,$e1_4,$e1_5,$e1_6,$d1_1,$d1_2,$d2_1,$d2_2,$d3,$c2_1,$c2_2,$c2_3,$c2_4,$c2_5,$c2_6,$c3,$b2_1,$b2_2,$b3_1,$b3_2,$b4_1,$b4_2);
}

function page3($num, $totale,$totalf,$te2,$te3,$tf1,$tf2,$tf3,$tf4,$tg1,$tg2,$tg3,$tg4,$tg5,$tg6,$tg7,$tg8,$g1,$g2,$g3,$g4_1,$g4_2,$g4_3,$g5,$g6,$g7,$g8_1,$g8_2,$g8_3,$f1_1,$f1_2,$f1_3,$f1_4,$f1_5,$f2_1,$f2_2,$f3_1,$f3_2,$f4_1,$f4_2,$e2_1,$e2_2,$e2_3,$e3_1,$e3_2,$e3_3)
{
	
	
    $this->AddPage();
    $this->page3Body($totale,$totalf,$te2,$te3,$tf1,$tf2,$tf3,$tf4,$tg1,$tg2,$tg3,$tg4,$tg5,$tg6,$tg7,$tg8,$g1,$g2,$g3,$g4_1,$g4_2,$g4_3,$g5,$g6,$g7,$g8_1,$g8_2,$g8_3,$f1_1,$f1_2,$f1_3,$f1_4,$f1_5,$f2_1,$f2_2,$f3_1,$f3_2,$f4_1,$f4_2,$e2_1,$e2_2,$e2_3,$e3_1,$e3_2,$e3_3);
}

function page4($num, $totalg,$total,$grade)
{
	
	
    $this->AddPage();
    $this->page4Body($totalg,$total,$grade);
}
}

$pdf = new PDF();
$title = 'Food Premises Grading';
$pdf->SetTitle($title);
$pdf->SetAuthor('opapis');


$pdf->page1(1,'',$_SESSION["info1"],$_SESSION["info2"],$_SESSION["info3"],$_SESSION["info4"],$_SESSION["info5"],$_SESSION["info6"],$_SESSION["info7"],$_SESSION["info8"],$_SESSION["info9"],$_SESSION["info10"],$_SESSION["ta1"],$_SESSION["ta2"],$_SESSION["ta3"],$_SESSION["ta4"],$_SESSION["ta5"],$_SESSION["totala"],$_SESSION["a1"],$_SESSION["a2_1"],$_SESSION["a2_2"],$_SESSION["a2_3"],$_SESSION["a2_4"],$_SESSION["a3_1"],$_SESSION["a3_2"],$_SESSION["a3_3"],$_SESSION["a4_1"],$_SESSION["a4_2"],$_SESSION["a4_3"],$_SESSION["a5_1"],$_SESSION["a5_2"],$_SESSION["a6"],$_SESSION["info11"],$_SESSION["info12"],$_SESSION["info13"]);

$pdf->page2(2,$_SESSION["tb1"],$_SESSION["tb2"],$_SESSION["tb3"],$_SESSION["tb4"],$_SESSION["tc1"],$_SESSION["tc2"],$_SESSION["td1"],$_SESSION["td2"],$_SESSION["td3"],$_SESSION["te1"],$_SESSION["totalb"],$_SESSION["totalc"],$_SESSION["totald"],$_SESSION["b1_1"],$_SESSION["c1_1"],$_SESSION["e1_1"],$_SESSION["e1_2"],$_SESSION["e1_3"],$_SESSION["e1_4"],$_SESSION["e1_5"],$_SESSION["e1_6"],$_SESSION["d1_1"],$_SESSION["d1_2"],$_SESSION["d2_1"],$_SESSION["d2_2"],$_SESSION["d3"],$_SESSION["c2_1"],$_SESSION["c2_2"],$_SESSION["c2_3"],$_SESSION["c2_4"],$_SESSION["c2_5"],$_SESSION["c2_5"],$_SESSION["c3"],$_SESSION["b2_1"],$_SESSION["b2_2"],$_SESSION["b3_1"],$_SESSION["b3_2"],$_SESSION["b4_1"],$_SESSION["b4_2"]);


$pdf->page3(3,$_SESSION["totale"],$_SESSION["totalf"],$_SESSION["te2"],$_SESSION["te3"],$_SESSION["tf1"],$_SESSION["tf2"],$_SESSION["tf3"],$_SESSION["tf4"],$_SESSION["tg1"],$_SESSION["tg2"],$_SESSION["tg3"],$_SESSION["tg4"],$_SESSION["tg5"],$_SESSION["tg6"],$_SESSION["tg7"],$_SESSION["tg8"],$_SESSION["g1"],$_SESSION["g2"],$_SESSION["g3"],$_SESSION["g4_1"],$_SESSION["g4_2"],$_SESSION["g4_3"],$_SESSION["g5"],$_SESSION["g6"],$_SESSION["g7"],$_SESSION["g8_1"],$_SESSION["g8_2"],$_SESSION["g8_3"],$_SESSION["f1_1"],$_SESSION["f1_2"],$_SESSION["f1_3"],$_SESSION["f1_4"],$_SESSION["f1_5"],$_SESSION["f2_1"],$_SESSION["f2_2"],$_SESSION["f3_1"],$_SESSION["f3_2"],$_SESSION["f4_1"],$_SESSION["f4_2"],$_SESSION["e2_1"],$_SESSION["e2_2"],$_SESSION["e2_3"],$_SESSION["e3_1"],$_SESSION["e3_2"],$_SESSION["e3_3"]);

$pdf->page4(4,$_SESSION["totalg"],$_SESSION["totalmark"],$_SESSION["grade"]);
$pdf->Output();
?>


