<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
    <link rel="stylesheet" href="css3.css">
    
  <style>
  body {
  padding:1em;
  background: #fff;
  height:300px
  
}

table {
  border: px #fff solid;
  font-size: .9em;
  box-shadow: 0 0px 0px rgba(0,0,0,.25);
  width: 100%;
  border-collapse: collapse;
  border-radius: 0px;
 
}

th {
  text-align: left;
}
  
thead {
  font-weight: bold;
  color: #fff;
  background: #43A047;
}
  
 td, th {
  padding: .5em .5em;
  vertical-align: middle;
}
  
 td {
  border-bottom: 0px solid rgba(0,0,0,.1);
  background: #fff;
}

a {
  color: #ff;
}
  
 @media all and (max-width: 768px) {
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
  th {
    text-align: right;
  }
  
  table {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 5px rgba(0,0,0,.2);
  }
  
  thead {
    float: left;
    white-space: nowrap;
  }
  
  tbody {
    
    position: relative;
    white-space: nowrap;
  }
  
  tr {
    display: inline-block;
    vertical-align: top;
  }
  
  
  }
</style>
    
</head>


</html>




<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

		 if(isset($_POST["search"])){
			 
              $id1 = $_POST['searchid'];
          
			 
			
			$query = mysql_query("SELECT * FROM user where staffid = '$_POST[searchid]' ") or die(   mysql_error());
	        $row = mysql_fetch_array($query);
			
			 $_SESSION['update']  = $row['staffid'];
		     $_SESSION['update2'] = $row['staffname'];
			 $_SESSION['update3'] = $row['Password'];
		     $_SESSION['update4'] = $row['phonenumber'];
			 $_SESSION['update5'] = $row['datecreated'];
			 $_SESSION['update6'] = $row['mode'];
			 $_SESSION['update7'] = $row['adminnamecreate'];
			 $_SESSION['update8'] = $row['email'];
			 $_SESSION['update9'] = $row['address'];
			 $_SESSION['update10'] = $row['editby'];
			 
			 
	        if(!empty($row['staffid']) )
	        {
				
				
	echo '<table> <thead> <tr>';
     echo '   <th>Staff ID :</th>';
     echo '   <th>Staff Name :</th>';
       echo ' <th>Phone Number :</th>';
	   echo ' <th>Email :</th>';
	   echo ' <th>Address :</th>';
       echo ' <th>Date Created :</th>';
       echo ' <th>Role :</th>';
      echo '  <th>Created By :</th>';
	  echo '  <th>Last update by :</th>';

   echo ' </tr> </thead> <tbody> <tr>';
      echo '  <td>'. $row['staffid'] .'</td>';
   echo ' </tr> </tbody><tbody> <tr>';
    echo '    <td>'. $row['staffname'] .'</td>';
   echo ' </tr></tbody> <tbody><tr>';
      echo '  <td>'. $row['phonenumber'] .'</td>';
	  echo ' </tr></tbody> <tbody><tr>';
      echo '  <td>'. $row['email'] .'</td>';
	  echo ' </tr></tbody> <tbody><tr>';
      echo '  <td>'. $row['address'] .'</td>';
   echo ' </tr> </tbody> <tbody><tr>';
       echo ' <td>'. $row['datecreated'] .'</td>';
	   echo ' <td>'. $row['editby'] .'</td>';
   echo ' </tr></tbody><tbody> <tr>';
    echo '<td>';
	if($row['mode'] == 1){
					echo "Admin <br/>";
					
				          }
	else{
					echo "user <br/>";
				           }
	echo '</td>';
   echo ' </tr></tbody> <tbody><tr>';
    echo '    <td>'. $row['adminnamecreate'] .'</td>';
   echo ' </tr> </tbody></table>';
				
		      
			   
			}else{
				
				 echo "ID didnt exist";
				
			}

    
    

  
		 }
		 
		 
		 mysql_close($con);

?>