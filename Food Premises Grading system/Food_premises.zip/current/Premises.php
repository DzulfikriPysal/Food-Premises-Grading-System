<?php
session_start();
if (isset($_SESSION['hehe'])) {
	
	print '<script type="text/javascript">';
    print 'alert("Session time out!")';
    print '</script>'; 
	session_destroy(); 
}
else if(isset($_SESSION['directory'])){
	$logout_redirect_url = $_SESSION['directory'];
	header("Location: $logout_redirect_url");
}

 if(empty($_SESSION['check2'])){
      $_SESSION['check2'] = 0;

  }
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu"/>
  <script type = "text/javascript" 
         src = "jquery.js"></script>
</head>
<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px;color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px;  "></td>
  </tr>
</table>


</div>

<div id="o-wrapper" class="o-wrapper">
<div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
  
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>

  <main class="o-content" style="height:400px;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">

      <table width="100%" border="0" style="text-align:left;">
  <tr>
    <td><form  method = "post" action = "<?php $_PHP_SELF ?>">
                  <input name = "viewalldata" type = "submit" id="viewbutton"  value = "Refresh" style="background-color:#ffc107; border:none" >
                  <input  id="c-button--slide-top2" class="c-button2"  type = "hidden"value = "view">
                  
                  
                  <input name = "sbox" type = "text"  size="40" onKeyPress="return submitenter(this,event)"  id = "namanyay-search-box" placeholder="Search"  >
                  
                 
                  
                   <select name="sdown" id="namanyay-search-box" >
                  <option value="premisesname" title="Premise Name"> Premise Name</option>
                  <option value="namepelesen" title="Premise Name"> Owner Name</option>
                  <option value="nokppelesen" title="Premise Name"> Owner IC</option>
                  </select>
                
                  
                 
                  <input name = "sdata" type = "submit" id="sdata" value = "Search" style="background-color:#ffc107; border:none" >
                   
                  
                  
               </form></td>
    
  </tr>
  <form name="myform3"  method = "post" action = "recipegallery.php">
                  <input name = "searchrecipe" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "searchrec" type = "hidden" id="searchrec"
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>
</table>

<table width="100%" border="0">
  <tr>
    <td> <?php
    
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

?>

<?php
 

 if(isset($_POST['viewalldata'])){
    $_SESSION["check2"] = 0; 
    $_SESSION["page"] = 0;
    $_GET['page'] = 0;
   }
   
if(isset($_POST['sdata'])){
  $_SESSION["check2"] = 1;
  $_SESSION["searchrow3"] = $_POST['sbox'];
  $_SESSION["page"] = 0;
  $_GET['page'] = 0;
  $_SESSION["sdown3"] = $_POST['sdown'];
  ?>
    
    <?php
}


if($_SESSION["check2"] == 1){
  $value =  $_SESSION["searchrow3"];
  $sdown =  $_SESSION["sdown3"];
  
  $tbl_name="premisesowner";    
  
  $adjacents = 5;
  if( $value == ""){
    $query = "SELECT COUNT(*) as num FROM $tbl_name WHERE premisesname LIKE '%$value%' OR namepelesen LIKE '%$value%'";
  }
  else{
    $query = "SELECT COUNT(*) as num FROM $tbl_name WHERE ".$sdown." LIKE '%$value%' ";
  }
  
  $total_pages = mysql_fetch_array(mysql_query($query));
  $total_pages = $total_pages['num'];
  
  
  $targetpage1 = "addreport.php";   
  $limit = 10;  
  if(isset($_GET['page']) ) {
         
         $_SESSION["page"] = $_GET['page'];
      
   }else {
          $_SESSION["page"] = $_SESSION["page"];
   }
  
  if($_SESSION["page"]) 
    $start1 = ($_SESSION["page"] - 1) * $limit;       
  else
    $start1 = 0;  
  
  if( $value == ""){
    $sql = "SELECT * FROM $tbl_name WHERE premisesname LIKE '%$value%' OR namepelesen LIKE '%$value%' LIMIT $start1, $limit";
    
  }
  else{
    $sql = "SELECT * FROM $tbl_name WHERE ".$sdown." LIKE '%$value%'  LIMIT $start1, $limit";
    
  }
  $result = mysql_query($sql);

  
  
  if ($_SESSION["page"] == 0) $_SESSION["page"] = 1;          
  $prev1 = $_SESSION["page"] - 1;             
  $next1 = $_SESSION["page"] + 1;             
  $lastpage1 = ceil($total_pages/$limit);   
  $lpm1 = $lastpage1 - 1;           
  
  
  $pagination = "";
  if($lastpage1 > 1)
  { 
    $pagination.= "<div class=\"pagination\" style=\"height:50px;\">";
    
    if ($_SESSION["page"] > 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";  
    
    
    if ($lastpage1 < 7 + ($adjacents * 2))  
    { 
      for ($counter = 1; $counter <= $lastpage1; $counter++)
      {
        if ($counter == $_SESSION["page"])
        $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
        else
          $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";   
              
      }
    }
    elseif($lastpage1 > 5 + ($adjacents * 2)) 
    {
      
      if($page1 < 1 + ($adjacents * 2))   
      {
        for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>"; 
            
                  
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
        {
        if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      else
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' onClick='return false;'style='background-color:#999;cursor:default;' href=\"$targetpage1?page=$counter\">$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
      }
    }
    
    
    if ($_SESSION["page"] < $counter - 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\" onClick='return false' style='cursor:default'> >> </a>";
    $pagination.= "</div>\n";   
  }
  mysql_close($con);
?>

  <?php
  echo "<div style='height:450px;'>";
  echo '
    <table id="customers">
        <thead><tr>
        <th>Owner Name</th>
      <th>Owner Liccence</th>
      <th>Company Phone</th>
      <th style="text-align:center">View Grade Report</th>
            <th style="text-align:center">View Premise Detail</th>
            <th style="text-align:center">Update Premise</th>
           
            <th><input id="checkall" type="checkbox" name="select_all" title="Click to tick / untick all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
    if($total_pages > 0){
    while($row = mysql_fetch_array($result))
    {     
      echo '<tr> <td>'  . $row['namepelesen']  . '</td>'.
      '<td>'  . $row['nokppelesen'] . '</td>'.
     '<td>'  . $row['notel'] . '</td>
        <td style="text-align:center;"> <input id="viewdetail" title="Premise grading report" type="button" name="'. $row['id']. '" onClick=    
               "viewshop(this.name)" value="View Grade"/> </td>
          <td style="text-align:center;"> <input id="viewdetail" title="Premise detail" type="button" name="'. $row['id']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            <td style="text-align:center;"><input id="updatebutton" title="Update premise detail" type="button" name="'.$row['id'].'" onClick=    
               "reply_click(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" title="click then press delete button to delete premise" name="checked_id[]" class="checkbox" value="'. $row['id'].'"/></td>    
        </tr> ';
    }
    }else{
    echo ' <tr><td colspan="5">No records found.</td></tr> '; 
    }
    echo ' </table>';
    echo "</div><br/><br/>";
  ?>
  <?php 
}
else if($_SESSION["check2"] == 0){

    

  $tbl_name="premisesowner";    
  
  $adjacents = 5;
  
  $query = "SELECT COUNT(*) as num FROM $tbl_name ";
  $total_pages = mysql_fetch_array(mysql_query($query));
  $total_pages = $total_pages['num'];
  
  
  
  $targetpage1 = "addreport.php";   
  $limit = 10;  
  if(isset($_GET['page']) ) {
          $page1 = $_GET['page'];
   }else {
          $page1 = 0;
   }
  if($page1) 
    $start1 = ($page1 - 1) * $limit;      
  else
    $start1 = 0;                
  
  
  $sql = "SELECT * FROM $tbl_name  LIMIT $start1, $limit";
  $result = mysql_query($sql);
  
  
  if ($page1 == 0) $page1 = 1;          
  $prev1 = $page1 - 1;              
  $next1 = $page1 + 1;              
  $lastpage1 = ceil($total_pages/$limit);   
  $lpm1 = $lastpage1 - 1;           
  
  
  $pagination = "";
  if($lastpage1 > 1)
  { 
    $pagination.= "<div class=\"pagination\" style=\"height:50px;\">";
    
    if ($page1 > 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\"> << </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$prev1\" onClick='return false;' style='cursor:default;''> << </a>";  
    
    
    if ($lastpage1 < 7 + ($adjacents * 2))  
    { 
      for ($counter = 1; $counter <= $lastpage1; $counter++)
      {
        if ($counter == $page1)
          $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999; cursor:default;'>$counter</a>";
        else
          $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
      }
    }
    elseif($lastpage1 > 5 + ($adjacents * 2)) 
    {
      
      if($page1 < 1 + ($adjacents * 2))   
      {
        for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      elseif($lastpage1 - ($adjacents * 2) > $page1 && $page1 > ($adjacents * 2))
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $page1 - $adjacents; $counter <= $page1 + $adjacents; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;' style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
        $pagination.= "...";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lpm1\">$lpm1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=$lastpage1\">$lastpage1</a>";   
      }
      
      else
      {
        $pagination.= "<a class='next' href=\"$targetpage1?page=1\">1</a>";
        $pagination.= "<a class='next' href=\"$targetpage1?page=2\">2</a>";
        $pagination.= "...";
        for ($counter = $lastpage1 - (2 + ($adjacents * 2)); $counter <= $lastpage1; $counter++)
        {
          if ($counter == $page1)
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='background-color:#999;cursor:default;'>$counter</a>";
          else
            $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\">$counter</a>";         
        }
      }
    }
    
    
    if ($page1 < $counter - 1) 
      $pagination.= "<a class='next' href=\"$targetpage1?page=$next1\"> >> </a>";
    else
      $pagination.= "<a class='next' href=\"$targetpage1?page=$counter\" onClick='return false;'style='cursor:default;'> >></a>";
    $pagination.= "</div>\n";   
  }
  mysql_close($con);
?>

  <?php
  echo "<div style='height:450px;'>";
  echo '
    <table id="customers">
        <thead><tr>
      <th>Premise Name</th>
      <th>Owner Name</th>
      <th>Owner Licence</th>
      <th>Company Phone</th>
      <th>Recipe</th>
      <th style="text-align:center">View Premise Detail</th>
            </tr>
        </thead>';
    if($total_pages > 0){
    while($row = mysql_fetch_array($result))
    {     
      echo '<tr>
      <td>'  . $row['premisesname']  . '</td>'.
    '<td>'  . $row['nokppelesen'] . '</td>'.
      '<td>'  . $row['nokppelesen'] . '</td>'.
     '<td>'  . $row['notel'] . '</td>
      <td> 
      <input id="viewdetail" title="Recipe detail" type="button" name="'. $row['id']. '" onClick=    
               "viewrecipe(this.name)" value="View Detail"/>

      </td>
        <td style="text-align:center;"> <input id="viewdetail" title="premise detail" type="button" name="'. $row['id']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            </tr> ';
  
    }
    }else{
    echo ' <tr><td colspan="5">No records found.</td></tr> '; 
    }
    echo ' </table>';
    echo "</div><br/><br/>";
    ?>
        <?php
}
?></td>
  </tr>
</table>

<table width="100%" height="100px" border="0">
  <tr>
    <td style="padding-left:45%; padding-right:45%"><?=$pagination?></td>
  </tr>
</table>
    
                    
               
     </form>
    
 
     </div><!-- /o-container -->
               




<div class="dummy2" > 

</div>


    
  </main><!-- /o-content -->

</div><!-- /o-wrapper -->

<div id="c-menu--slide-top2" class="c-menu2 c-menu--slide-top2">
<div class="dummyx" style="color:#FFF;"> View</div>
<div class="dummyxz">

<iframe src="viewform2.php" name="smallframe1" width="100%" height="360px" style="border:none"></iframe>
                <form name="myform2"  target="smallframe1" method = "post" action = "viewform2.php">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "search" type = "hidden" id="search"
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>

                          <button id="click" class="c-menu__close" style="background-color:#ffc107; color:#FFF; border:none; position:absolute; top:343px; left: 350px;">Cancel</button>
         
</div>
   
</div><!-- /c-menu slide-top -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <div class="top" style="background-image:url(A.PNG)">
           </div>
           
            <div class="mid" style="top:165px;">
            
            <div class="login-screen">
			<div class="app-title">
				<h1 style="color:#FFF">Login</h1>
			</div>

			<div class="login-form">
           
             <form class="loginform" method="POST" action="connectivity.php" > 
                 <div class="control-group">
				      <input id="login-field" id="login-name" type="text" name="user" size="25" required="required" placeholder="Staff ID">
				</div>
                     <input id="login-field" id="login-name" type="password" name="pass" size="25" required="required" minlength="10" maxlength="20" placeholder="Password">
				<div class="control-group">
				
				</div>
              
                 <input id="btnlogin" type="submit" name="submit" value="Log-In">
				<a class="login-link" href="resetpassword.php" style="color:#FFF">Lost your password?</a>
          </form>
         
      
          </div>
          </div>
          
          
          
           <button id="c-menu__close" class="c-menu__close">&larr; Close Menu</button>
           </div>
  
  
</nav><!-- /c-menu slide-left -->




<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  

  var slideTop2 = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-top2',
    menuOpenerClass: '.c-button2',
    maskId: '#c-mask'
  });

  var slideTopBtn2 = document.querySelector('#c-button--slide-top2');
  
  slideTopBtn2.addEventListener('click', function(e) {
    e.preventDefault;
    slideTop2.open();
  });
  
  
  
  

</script>

<script>
  

  
   function ouch()
{
  
    window.location=window.location;
  
  
   
}


  
 

function view(clicked_id)
{
   document.getElementById("c-button--slide-top2").click();
  // alert(clicked_id);
  // document.getElementById("yoho").innerHTML = clicked_id;
  document.myform2.searchid.value = clicked_id;
  document.forms["myform2"].submit();
  document.getElementById("search").click();
  
}

function viewrecipe(clicked_id)
{
  document.myform3.searchrecipe.value = clicked_id;
  document.forms["myform3"].submit();
  document.getElementById("searchrec").click();
  
}



  function delete_confirm(){
  var result = confirm("Are you sure to delete users?");
  if(result){
    return true;
  }else{
    return false;
  }
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
  
  $('.checkbox').on('click',function(){
    if($('.checkbox:checked').length == $('.checkbox').length){
      $('#select_all').prop('checked',true);
    }else{
      $('#select_all').prop('checked',false);
    }
  });
});






 function submitenter(myfield,e) { 
    var keycode; 
  if (window.event) keycode = window.event.keyCode; 
  else if (e) keycode = e.which; else return true; 
  if (keycode == 13) { 
  document.getElementById("sdata").click(); return false; 
  } 
    else return true; }
    
    function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }




 function guestFromPop() {
  document.getElementById("viewbutton1").click();
}

 function addgrading() {

  document.getElementById("viewbutton3").click();
}



$("#checkall").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});

</script>

</body>
</html>