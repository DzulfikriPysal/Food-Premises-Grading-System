<?php
 error_reporting(E_ALL ^ E_DEPRECATED);
$hostname_connect = "localhost";
$database_connect = "premises";
$username_connect = "root";
$password_connect = "";
$connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);


if(! $connect ) {
               die('Could not connect: ' . mysql_error());
            }
			
			else{
				die('weeee ');
			}
         
		 if(isset($_POST["delete"])){
			 
            if(! get_magic_quotes_gpc() ) {
               $id1 = addslashes ($_POST['staffid']);
            }else {
              $id1 = $_POST['staffid'];
            }
			
			
			$query = mysql_query("SELECT staffid FROM user where staffid = '$_POST[staffid]' ") or die(mysql_error());
	        $row = mysql_fetch_array($query);
	        if(!empty($row['staffid']) )
	        {
				
				$sql = "DELETE FROM user WHERE staffid='$id1'";
	
	           mysql_select_db('premises');
               $retval = mysql_query( $sql, $connect );
			 
	     
		      echo "Successfully delete";
			   
			}else{
				
				 echo "ID didnt exist";
				
			}

    
    

  
		 }
		 
		 
		 

?>