<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu"/>
  <script src="https://code.jquery.com/jquery-1.11.2.js"></script>
</head>

<body>
<div id="header">
<div class="c-buttons">
<br/>
<button id="c-button--slide-left" class="c-button"><span>Menu </span></button>
      </div>
<h1>FOOD PREMISES GRADING SYSTEM </h1>
</div>

<div id="o-wrapper" class="o-wrapper">

 <div style="width:100%; height:60px; float:left">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="background-color:#CCC; height:1100px; text-align:start;">
    
    <h1 style="text-align:center">Borang Pemeriksaan Dan Penggredan Premis Makanan</h1>
    <form method = "post" action = "<?php $_PHP_SELF ?>" >
    <table width="90%" border="0">
  <tr>
    <td style="text-align:start;">No Siri Borang</td>
    <td><input type="text"></td>
 
  </tr>
  <tr>
    <td style="text-align:start;">Owner Name</td>
    <td><input type="text"></td>
    <td style="text-align:start;">Licence Reference No</td>
    <td><input type="text"></td>
  </tr>
  <tr>
    <td style="text-align:start;">Company Name</td>
    <td><input type="text"></td>
    <td style="text-align:start;">Date</td>
    <td><input type="text"></td>
  </tr>
  <tr>
    <td style="text-align:start;">Address</td>
    <td><input type="text"></td>
    <td style="text-align:start;">Time</td>
    <td><input type="text" placeholder="Start"> <input type="text" placeholder="End"></td>
  </tr>
  <tr>
    <td style="text-align:start;">Owner Licence No</td>
    <td><input type="text"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="text-align:start;">Phone Number</td>
    <td><input type="text"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td style="text-align:start;">Pengendali</td>
    <td >Bil Pengendali<input type="radio"></td>
    <td>Suntikan pelalian ANTI Tibid<input type="radio"></td>
    <td>Kursus pengendali makanan<input type="radio"></td>
  </tr>
</table>


    <div id="first">
       
<table width="100%" border="1">
  <tr>
    <th scope="col" style="text-align:start;">Perkara</th>
    <th scope="col">Komponen</th>
    <th scope="col">Marks</th>
    <th scope="col">Demerit</th>
    <th scope="col">Catatan</th>
  </tr>
  <tr>
    <td>A Kawasan penyediaan makanan</td>
    <td>A1 Kawasan Suhu Penyimpanan Dan Penyediaan Makanan <br/>
        Peti sejuk <br/>
        &#9899; Suhu sejuk -18c hingga 0c</td>
    <td style="text-align:center">12</td>
    <td style="text-align:center"><select>
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
           <option>7</option>
           <option>8</option>
           <option>9</option>
           <option>10</option>
           <option>11</option>
           <option>12</option>
        </select></td>
    <td style="text-align:center">CCP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A2 Kawalan serangga perosak / LILATI yang efektif termasuk kawalan<br/>
        &#9899; lipas<br/>
        &#9899; lalat<br/>
        &#9899; tikus<br/>
        &#9899; lain lain haiwan<br/></td>
    <td style="text-align:center"><br/><br/>
        1<br/>
        1<br/>
        1<br/>
        1<br/></td>
    <td style="text-align:center"><br><br><input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br></td>
    <td><textarea name="text" cols="25" rows="5"></textarea>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A3 kebersihan peti sejuk<br/>
        &#9899; peti sejuk sentiasa bersih<br/>
        &#9899; susunan makanan dalam keadaan teratur<br/>
        &#9899; tiada pencemaran silang<br/></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        1</td>
    <td style="text-align:center"><br><input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A4 Kebersihan peralatan dan kemudahan memasak<br />
        &#9899; alas memotong dan kain pengelap dalam keadaan bersih<br />
        &#9899; dilarang mengunakan kertas bercetak yang bersentuhan dengan makanan<br />
        &#9899; peralatan kulinari sentiasa dalam keadaan baik dan bersih<br /></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        <br />
        1</td>
    <td style="text-align:center"><br><input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br><br>
        <input type="checkbox" name="option1" value="1">1<br></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A5 Sistem pelepasan asap dan haba<br/>
        &#9899; Berfungsi dengan baik serta tidak menimbulkan kacauganggu<br/>
        &#9899; kapasiti yang mencukupi dan efisyen<br/></td>
    <td style="text-align:center"><br />1<br />1</td>
    <td style="text-align:center"><br>
        <input type="checkbox" name="option1" value="1">1<br>
        <input type="checkbox" name="option1" value="1">1<br></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  
   <tr>
    <td>&nbsp;</td>
    <td>A6 Ruang kelegaan di antara peralatan dan dinding/lantai<br />
        &#9899; jarak minima yang sesuai untuk penyelenggaraan dan tiada kesesakan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="checkbox" name="option1" value="1">1</td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
</table>
    </div>

    <div id="second" style="display:none">
    
    <table width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>B<br/>
        Kawasan penyajian makanan   
    </td>
    <td>B1. kawalan suhu dan tempat mempamerkan makanan yang sesuai <br/> 
        mengikut keadaan dan jenis makanan<br/>
        &#9899; suhu makanan panas >60c<br/>
        &#9899; suhu makanan dingin 1c hingga 4c<br/>
        &#9899; suhu makanan sejuk beku < - 18c</td>
    <td>12</td>
    <td><select>
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
           <option>7</option>
           <option>8</option>
           <option>9</option>
           <option>10</option>
           <option>11</option>
           <option>12</option>
        </select></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B2 peralatan kulinari yang digunakan untuk penyajian  makanan<br/>
        perlu sentiasa dalam keadaan.<br/>
        &#9899; bersih<br/>
        &#9899; tidak sumbing, retak or karat</td>
    <td><br/><br/>1<br/>1</td>
    <td><br/><br/><input type="checkbox" name="option1" value="1">1<br/><input type="checkbox" name="option1" value="1">1</td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B3 KAIN PENGELAP ALAS DAN PERALATAN<BR/>
        perlu sentiasa dalam keadaan<br/>
        &#9899; Bersih<br/>
        &#9899; digunakan berasingan mengikut jenis kerja</td>
    <td><br/><br/>1<br/>1</td>
    <td><br/><br/><input type="checkbox" name="option1" value="1">1<br/><input type="checkbox" name="option1" value="1">1</td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td>B4 meja kerusi dan peralatan hendak lah<br/>
        sentiasa<br/>
        &#9899; Bersih<br/>
        &#9899; sempurna dan selamat
        </td>
    <td><br/><br/>1<br/>1</td>
    <td><br/><br/><input type="checkbox" name="option1" value="1">1<br/><input type="checkbox" name="option1" value="1">1</td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
</table>

    
       
    </div>
    
     <div id="third" style="display:none">
     
     <table width="100%" border="1">
  <tr>
 <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>C<br/>pengendali makanan</td>
    <td>C1 pemeriksa kesihatan ke atas semua pengendali makanan<br/>
         &#9899; menadapat suntikan pelalian anti tifoid<br/>
         &#9899; menghadiri kursus pengendali makanan</td>
    <td>6</td>
    <td><select>
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
        </select></td>
    <td>CPP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C2 tahap kebersihan diri yang baik<br/>
        &#9899; berpakaian bersih dan sesuai<br/>
        &#9899; memakai apron yang bersih dan berpenutup kepala<br/>
        &#9899; berkuku pendek bersih dan tidak memakai barang perhiasan diri<br/>
        &#9899; berkasut<br/>
        &#9899; tidak merokok<br/>
        &#9899; tidak melakukan apa apa perbuatan atau tindakan yang boleh <br/>
        menyebabkan pencemaran makanan </td>
    <td>1<br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1">
    <br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1">
    <br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C3 tiada masalah kesihatan yang berkaitan dengan pencemaran makanan</td>
    <td>1</td>
    <td><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
</table>

     
       
    </div>
     <div id="fourth" style="display:none">
            <table width="100%" border="1">
  <tr>
 <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>D<br/>sistem bekalan air</td>
    <td>D1 Sumber Bekalan air yg selamat<br/>
         &#9899; Terawat<br/>
         &#9899; berih dan mencukupi</td>
    <td><br/>1<br/>1</td>
    <td><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D2 pengunaan sumber bekalan air<br/>
        &#9899; diambil terus dari paip<br/>
        &#9899; dilarang penggunaan paip getah </td>
    <td><br/>1<br/>1</td>
    <td><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D3 Tiada kebocoran paip di premis</td>
    <td>1</td>
    <td><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
</table>

    </div>
     <div id="fifth" style="display:none">
     <table width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>E<br/>kemudahan sanitassi</td>
    <td>E1 keadaan kelengkapan kemudahan tandas<br/>
        &#9899; bersih dan bebas dari bau busuk<br/>
        &#9899; sempurna dan berfungsi dengan baik<br/>
        &#9899;kedudukan pintu tandas tidak boleh menghala terus ke kawasan <br/>
                penyediaan makanan<br/>
        &#9899; pengudaraan sempurna<br/>
        &#9899; bekalan air mencukupi<br/>
        &#9899; disediakan sabun dan tisu/alat pengering<br/></td>
    <td><br/>1<br/>1<br/>1<br/><br/>1<br/>1<br/>1</td>
    <td><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"><br/><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"></td>

    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E2 kemudahan mencukupi<br/>
        &#9899; sinki yang mencukupi<br>
        &#9899; perangkap sisa makanan, minyak dan lemak(fog) berfungsi dan<br/>
        diselengara dengan baik.<br/>
        &#9899; kapasiti perangkap fog yg tersusun</td>
    <td><br/>1<br/>1<br/><br/>1</td>
    <td><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"><br/><br/><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E3 kemudahan tempat mencuci tangan<br/>
        &#9899; bersih<br/>
        &#9899; sempurna<br/>
        &#9899; kemudahan sabun cecair dan pengering tangan</td>
    <td><br/>1<br/>1<br/>1</td>
    <td><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"><br/><input type="checkbox" name="option1" value="1"></td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
</table>

       
    </div>
     <div id="six" style="display:none">
     <table width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>F Struktur dan penyenggaraan premis</td>
    <td>F1 keadaan lantai dinding dan siling<br/>
       &#9899; tidak licin tahan lasak<br/>
       &#9899; mudah dibersihkan<br/>
       &#9899; kalis air<br/>
       &#9899; tidak menakung air / rata<br/>
       &#9899; bebas dari sesawang habuk kulat<br/>
    </td>
    <td><br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td>&nbsp;</td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F2 Sistem pengudaraan dan pencahayaan<br/>
        &#9899; mencukupi<br/>
        &#9899; berfungsi.</td>
    <td><br/>1<br/>1</td>
    <td>&nbsp;</td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F3 sistem perparitan yang sempurna<br/>
        &#9899; bersih<br/>
        &#9899; disenggara dengan baik<br/>
        </td>
    <td><br/>1<br/>1</td>
    <td>&nbsp;</td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F4 sistem pengurusan air imbah yang sempurna<br/>
        &#9899; mengalir lancar<br/>
        &#9899; tiada sisa makanan</td>
    <td><br/>1<br/>1</td>
    <td>&nbsp;</td>
    <td><textarea name="text" cols="25" rows="2"></textarea></td>
  </tr>
</table>

       
    </div>


    <div id="seven" style="display:none">
    
    
    <table width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>G lain lain generik</td>
    <td>G1 Maklumbalas pelangan</td>
    <td>5</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G2 kemudahan tong sampah yang mencukupi berpenutup bersih<br/>
        dan berkarung</td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G3 bahan makanan dan bahan kimai hendaklah disimpan secara <br/>
        berasingan kedua duanya mestilah berlabel</td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G4 penyediaan dan pengurusan stor yang baik(fifo kalis kulat)<br/>
        &#9899; susun atur dan ruang kelegaan<br/>
        &#9899; kebersihan<br/>
        &#9899; pengudaraan dan pencahayaan<br/></td>
    <td><br/>1<br/>1<br/>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G5 amalan pengurusan sisa pepejal yang baik<br/>
        (pengasigan di punca</td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G6 premis dan peralatan perlu disengara dengan baik dan<br/>
        jadual pembersihan mestilah di pantau secara berterusan</td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G7 Notis pemberitahuan kebersihan amalan<br/>
        keselamatan pendidikan kesihatan dan larangan<br/>
        merokok</td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G8 kawalan dan keselamatan di premis makanan<br/>
        &#9899; alat pemadam api<br/>
        &#9899; peti pertolongan ccemas<br/>
        &#9899; ruang bebas dari sebarang halangan</td>
    <td><br/>1<br/>1<br/></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

      
        <input type="submit" name="add">
    </div>
</form>
<br><br>
<div id="page_menus" style="text-align:center;">
    <a href="addreport.php" id="get_first" style="cursor:pointer">1</a>
    <a id="get_second" style="cursor:pointer">2</a>
    <a id="get_third" style="cursor:pointer">3</a>
    <a id="get_fourth" style="cursor:pointer">4</a>
    <a id="get_fifth" style="cursor:pointer">5</a>
    <a id="get_six" style="cursor:pointer">6</a>
    <a id="get_seven" style="cursor:pointer">7</a>
    
</div>

<script>
    $('#get_first').click(function(){
        $('#first').show()
        $('#second').hide()
        $('#third').hide()
		 $('#fourth').hide()
        $('#fifth').hide()
		 $('#six').hide()
        $('#seven').hide()
    })
    $('#get_second').click(function(){
        $('#first').hide()
        $('#second').show()
        $('#third').hide()
		 $('#fourth').hide()
        $('#fifth').hide()
		 $('#six').hide()
        $('#seven').hide()
    })
    $('#get_third').click(function(){
        $('#first').hide()
        $('#second').hide()
        $('#third').show()
		 $('#fourth').hide()
        $('#fifth').hide()
		 $('#six').hide()
        $('#seven').hide()
    })
	 $('#get_fourth').click(function(){
        $('#first').hide()
        $('#second').hide()
        $('#third').hide()
		 $('#fourth').show()
        $('#fifth').hide()
		 $('#six').hide()
        $('#seven').hide()
    })
	
	 $('#get_fifth').click(function(){
        $('#first').hide()
        $('#second').hide()
        $('#third').hide()
		 $('#fourth').hide()
        $('#fifth').show()
		 $('#six').hide()
        $('#seven').hide()
    })
	
	 $('#get_six').click(function(){
        $('#first').hide()
        $('#second').hide()
        $('#third').hide()
		 $('#fourth').hide()
        $('#fifth').hide()
		 $('#six').show()
        $('#seven').hide()
    })
	
	 $('#get_seven').click(function(){
        $('#first').hide()
        $('#second').hide()
        $('#third').hide()
		 $('#fourth').hide()
        $('#fifth').hide()
		 $('#six').hide()
        $('#seven').show()
    })
</script>





    
    
    
    
    </div>
    
    <div class="dummy2"> 

</div>
    
    </main>
    </div>
    
    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">VIEW RECORD</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "viewrecord.php";
            };
	        </script>
            
            
       
            
              <button class="logoutbutton" id="logoutbutton" type="button" onclick="">LOGOUT</button>
           
            <script type="text/javascript">
            document.getElementById("logoutbutton").onclick = function () {
            location.href = "homepage.php";
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  </script>
    
    
    </body>


</html>

<?php
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());


 if(isset($_POST["add"])){
	echo "hahah"; 
 }


?>


<?php
/*
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());


		 $lol = $_POST['searchid'];
		 echo $lol;
			 
       
          
	$query = mysql_query("SELECT * FROM premisesdetail where nokppelesen = '$_POST[searchid]' ") or die(   mysql_error());
	   
		
	
		 
		 mysql_close($con);*/
?>