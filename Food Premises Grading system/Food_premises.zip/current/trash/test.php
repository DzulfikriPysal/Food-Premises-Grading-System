<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php
 error_reporting(E_ALL ^ E_DEPRECATED);
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 




// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("premises")or die("cannot select DB");


$sql="SELECT * FROM  mytbl";
$result=mysql_query($sql);

$count = mysql_num_rows($sql);

?>
<table width="400" border="0" cellspacing="1" cellpadding="0">
<tr>
<td><form name="form1" method="post" action="">
<table width="600" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td bgcolor="#FFFFFF">&nbsp;</td>
<td colspan="4" bgcolor="#FFFFFF"><strong>My Total Submitted Data</strong> </td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF">#</td>
<td align="center" bgcolor="#FFFFFF"><strong>Id</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>Name</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>Age</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>City</strong></td>
<td align="center" bgcolor="#FFFFFF"><strong>Country</strong></td>

</tr>
<?php
while($rows = mysql_fetch_array($sql))
{
?>
<tr>
<td align="center" bgcolor="#FFFFFF"><input name="checkbox[]" type="checkbox" id="checkbox[]" value="<? echo $rows['id']; ?>"></td>
<td bgcolor="#FFFFFF"><? echo $rows['Id']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['Name']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['Age']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['City']; ?></td>
<td bgcolor="#FFFFFF"><? echo $rows['Country']; ?></td>

</tr>
<?php
}
?>
<tr>
<td colspan="5" align="center" bgcolor="#FFFFFF"><input name="delete" type="submit" id="delete" value="Delete"></td>
</tr>

</table>
</form>
</td>
</tr>
</table>


</body>
</html>