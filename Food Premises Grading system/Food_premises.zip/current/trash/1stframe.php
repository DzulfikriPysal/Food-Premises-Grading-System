<?php

$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'premises';
$conn = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);


if (isset($_POST['sdata']))
{
	$value = $_POST['sbox'];
	
	$query = mysqli_query($conn,"SELECT * FROM user WHERE staffid = '$value' ");
	
	echo '<form target="1stframe" name="bulk_action_form" action="action.php" method="post" onSubmit="return delete_confirm();"/>
    <table id="customers">
        <thead><tr>
            <th>Staff id</th>
            <th>Last seen</th>
            <th>Last Edit</th>
            <th>View Detail</th>
            <th>Update</th>
            <th><input type="checkbox" name="select_all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
		
		if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
					
					
	   echo '<tr> <td>'  . $row['staffid'] . '</td> <td>' 
	                     . $row['lastseen'] .'</td>
            <td>'       . $row['lastedit']. '</td>
            <td>
            
            <input id="viewdetail" type="button" name="'. $row['staffid']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            <td><input id="updatebutton" type="button" name="'.$row['staffid'].'" onClick=    
               "reply_click(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" name="checked_id[]" class="checkbox" value="'. $row['staffid'].'"/></td>    
        </tr> ';
		
		} }else{ 
		
		echo ' <tr><td colspan="5">No records found.</td></tr> ';
		
		}
		
		echo ' </table>';
		 echo ' <input id="deletebutton" type="submit" class="btn btn-danger" name="bulk_delete_submit" value="Delete"/>
</form> ';
   
   mysqli_close($conn);
}  
else{
	$query = mysqli_query($conn,"SELECT * FROM user");
	
	echo '<form target="1stframe" name="bulk_action_form" action="action.php" method="post" onSubmit="return delete_confirm();"/>
    <table id="customers">
        <thead><tr>
            <th>Staff id</th>
            <th>Last seen</th>
            <th>Last Edit</th>
            <th>View Detail</th>
            <th>Update</th>
            <th><input type="checkbox" name="select_all" id="select_all" value=""/></th>     
        </tr>
        </thead>';
		
		if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
					
					
	   echo '<tr> <td>'  . $row['staffid'] . '</td> <td>' 
	                     . $row['lastseen'] .'</td>
            <td>'       . $row['lastedit']. '</td>
            <td>
            
            <input id="viewdetail" type="button" name="'. $row['staffid']. '" onClick=    
               "view(this.name)" value="View Detail"/>
            
            
            </td>
            <td><input id="updatebutton" type="button" name="'.$row['staffid'].'" onClick=    
               "reply_click(this.name)"  value="Update"/></td>
            <td align="center">
            <input type="checkbox" name="checked_id[]" class="checkbox" value="'. $row['staffid'].'"/></td>    
        </tr> ';
		
		} }else{ 
		
		echo ' <tr><td colspan="5">No records found.</td></tr> ';
		
		}
		
		echo ' </table>';
		 echo ' <input id="deletebutton" type="submit" class="btn btn-danger" name="bulk_delete_submit" value="Delete"/>
</form> ';
   
   mysqli_close($conn);
	
}




?>

