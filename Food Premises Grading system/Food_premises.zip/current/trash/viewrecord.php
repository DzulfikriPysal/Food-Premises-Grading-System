<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Slide &amp; FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
</head>
<body>

<div id="header">
<div class="c-buttons">
<br/>
        <button id="c-button--slide-left" class="c-button"></button>
      </div>
<h1>FOOD PREMISES GRADING SYSTEM </h1>
</div>

<div id="o-wrapper" class="o-wrapper">


  <main class="o-content">
    <div class="o-container">
    <?php

error_reporting(E_ALL ^ E_DEPRECATED);
$hostname_connect = "localhost";
$database_connect = "premises";
$username_connect = "root";
$password_connect = "";
$connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR); 

 $sql = 'SELECT * FROM premisesowner';
   mysql_select_db('premises');
   $retval = mysql_query( $sql, $connect );
 
   

    
  echo' <table width="1050" border= "1px">';
  echo '<tr><th scope="col">' . "No. KPP pelesen" 
  . '</th><th scope="col">' .   "Nama Pelesen         "
  . '</th><th scope="col">' .   "Phone Number      "
  . '</th><th scope="col">' .   "No Ruj Lesen         "
  . '</th><th scope="col">' .   "Create By      "
  . '</th><th scope="col">' .   "Create At     "
  
  
  
  
  
   . "</th></tr>"; 
  
      while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
      echo 
	    '<tr><th>' .'<a href="">'. $row['nokppelesen'] ."</a>"
	  . '</th><th>'. $row['namepelesen'] 
      . '</th><th>'. $row['notel']
	  . '</th><th>'. $row['norujlesen']
	  . '</th><th>'. $row['createby']
	  . '</th><th>'. $row['datecreate']
	  . '</th><th>';
	 
	   "</th></tr>"; 
   }
   
   
  

   
  "</tr>";
  
 echo" </table>";



  
?>
    
    </div><!-- /o-container -->
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">ADD RECORD</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
            
            
              <button class="updaterecord" id="updaterecord" type="button" onclick="">UPDATE RECORD</button>
           
            <script type="text/javascript">
            document.getElementById("updaterecord").onclick = function () {
            location.href = "updaterecord.php";
            };
	        </script>
            
              <button class="deleterecord" id="deleterecord" type="button" onclick="">DELETE RECORD</button>
           
            <script type="text/javascript">
            document.getElementById("deleterecord").onclick = function () {
            location.href = "deleterecord.php";
            };
	        </script>
            
              <button class="logoutbutton" id="logoutbutton" type="button" onclick="">LOGOUT BUTTON</button>
           
            <script type="text/javascript">
            document.getElementById("logoutbutton").onclick = function () {
            location.href = "logout.php";
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  
  function otherpage(){
	  <?php
	  echo "wahahaha";
	  
	  ?>
	  
  }

</script>

</body>
</html>