<html>

<head>
<style>
#namanyay-search-btn {
background:#FFC107;
color:white;
font: 'trebuchet ms', trebuchet;
padding:10px 20px;
border:0 none;
font-weight:bold;
}
 
#namanyay-search-box {
background: #eee;
padding:10px;
border:0 none;
width:160px;
 }
  body {
  padding:1.5em;
  background: #fff
}

table {
  border: 1px #fff solid;
  font-size: .9em;
  width: 50%;
  border-collapse: collapse;
  border-radius: px;
 
}

th {
  text-align: left;
}
  
thead {
  font-weight: bold;
  color: #fff;
  background: #039BE5;
}
  
 td, th {
  padding: 1em .5em;
  vertical-align: middle;
}
  
 td {
  background: #fff;
}

a {
  color: #fff;
}
  
 @media all and (max-width: 768px) {
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
  th {
    text-align: right;
  }
  
  table {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 10px rgba(0,0,0,.2);
  }
  
  thead {
    float: left;
    white-space: nowrap;
  }
  
  tbody {
    
    position: relative;
    white-space: nowrap;
  }
  
  tr {
    display: inline-block;
    vertical-align: top;
  }
  
  
  
</style>
</head>

<body>


<form id="searchthis" action="/search" style="display:inline;" method="get">
<!-- Search box for blogger by Namanyay Goel //-->
<input id="namanyay-search-box" name="q" size="40" type="text" placeholder="  Type to search.. "/>
<input id="namanyay-search-btn" value="Search" type="submit"/>
</form>

<table>
    <thead>
    <tr>
        <th>Premise Name :</th>
        <th>Address :</th>
        <th>Owner Name :</th>
        <th>Owner License :</th>
        <th>Phone Number :</th>
        <th>License Reference Number:</th>

    </tr>
    </thead>
    
    <tbody>
    <tr>
        <td>Pangsit69</td>
        <td>Pangsit Anak Pangganas</td>
        <td>011 6969 9696</td>
        <td>1 January 0001</td>
        <td>Pangamput</td>
        <td>DzulPedo</td>
    </tr>
    </tbody>
</table>

</body>

</html>