<?php
session_start();
if (isset($_SESSION['staffid'])) {
	$_SESSION['directory'] = "searchform.php";
$timeout = 15; 
$logout_redirect_url = "sessiontimeout.php"; 

$timeout = $timeout * 60; 
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}
}
else{
	header("Location: homepage.php");
}

 $_SESSION["type"] = "viewall";
 $_SESSION["value"] = "viewall";


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
  <link rel="stylesheet" href="css4.css">
  <script type = "text/javascript" 
         src = "jquery.js"></script>
        
      <script type = "text/javascript" 
         src = "jquery-ui.js"></script>
</head>
<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; "> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; ">Report Management</td>
  </tr>
</table>

<form name="myformz" target='_parent'  method = "post" action = "<?php $_PHP_SELF ?>">
                  <input name = "searchid" type = "hidden" 
                           id = "textbox" required >
                    
                           <input name = "search321" type = "hidden" id="search" 
                              value = "Search" style="background-color:#ffc107; border:none" >
               </form>

 <?php
			   if(isset($_POST['search321'])){
				  error_reporting(E_ALL ^ E_DEPRECATED);
				  define('DB_HOST1', 'localhost');
                  define('DB_NAME1', 'premises');
                  define('DB_USER1','root');
                  define('DB_PASSWORD1','');
                  $con=mysql_connect(DB_HOST1,DB_USER1,DB_PASSWORD1) or die("Failed to connect to MySQL: " . mysql_error());
                  $db=mysql_select_db(DB_NAME1,$con) or die("Failed to connect to MySQL: " . mysql_error());
				  
				   $sid =  $_POST['searchid'];
	               $_SESSION['sid'] = $sid;
	               $query = mysql_query("SELECT * FROM premisesdetail
		                       LEFT JOIN premisesowner 

							   ON premisesdetail.namasyarikat = premisesowner.premisesname
							   where premisesdetail.nosiriborang = '$sid'") or die(   mysql_error());
		           $row = mysql_fetch_array($query);
		
       

                   mysql_close($con);
				   
				   $_SESSION["info1"] = $row['nosiriborang'];
	$_SESSION["info2"] = $row['namepelesen'];
	$_SESSION["info3"] = $row['norujlesen'];
	$_SESSION["info4"] = $row['premisesname'];
	$_SESSION["info5"] = $row['tarikh'];
	$_SESSION["info6"] = $row['notel'];
	$_SESSION["info7"] = $row['masamula'];
	$_SESSION["info8"] = $row['masatamat'];
	$_SESSION["info9"] = $row['nokppelesen'];
	$_SESSION["info10"] = $row['address'];
	$_SESSION["info11"] = $row['bilpengendali'];
	
	$_SESSION["totalmark"] = 100 - ($row['totala'] + $row['totalb'] + $row['totalc'] + $row['totald'] + $row['totale'] + $row['totalf'] + $row['totalg']);
	$_SESSION["grade"] = $row['grade'];
	
	
	  date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i");
			  
			  $_SESSION["timeprint"] = $a;
	
	
	if($row['suntikanpelali'] == 0){
		$_SESSION["info12"] = "None";
	}
	else{
		$_SESSION["info12"] = "/";
	}
	
	if($row['kursuspengendali'] == 0){
		$_SESSION["info13"] = "None";
	}
	else{
		$_SESSION["info13"] = "/";
	}

	
	 
	 
	 //textarea
	$_SESSION["ta1"] = $row['ta1'];
	$_SESSION["ta2"] = $row['ta2'];
	$_SESSION["ta3"] = $row['ta3'];
	$_SESSION["ta4"] = $row['ta4'];
	$_SESSION["ta5"] = $row['ta5'];
	$_SESSION["tb1"] = $row['tb1'];
	$_SESSION["tb2"] = $row['tb2'];
	$_SESSION["tb3"] = $row['tb3'];
	$_SESSION["tb4"] = $row['tb4'];
	$_SESSION["tc1"] = $row['tc1'];
	$_SESSION["tc2"] = $row['tc2'];
	$_SESSION["td1"] = $row['td1'];
	$_SESSION["td2"] = $row['td2'];
	$_SESSION["td3"] = $row['td3'];
	$_SESSION["te1"] = $row['te1'];
	$_SESSION["te2"] = $row['te2'];
	$_SESSION["te3"] = $row['te3'];
	$_SESSION["tf1"] = $row['tf1'];
	$_SESSION["tf2"] = $row['tf2'];
	$_SESSION["tf3"] = $row['tf3'];
	$_SESSION["tf4"] = $row['tf4'];
	$_SESSION["tg1"] = $row['tg1'];
	$_SESSION["tg2"] = $row['tg2'];
	$_SESSION["tg3"] = $row['tg3'];
	$_SESSION["tg4"] = $row['tg4'];
	$_SESSION["tg5"] = $row['tg5'];
	$_SESSION["tg6"] = $row['tg6'];
	$_SESSION["tg7"] = $row['tg7'];
	$_SESSION["tg8"] = $row['tg8'];
	
	//mark
	$_SESSION["totala"] = $row['totala'];
	$_SESSION["totalb"] = $row['totalb'];
	$_SESSION["totalc"] = $row['totalc'];
	$_SESSION["totald"] = $row['totald'];
	$_SESSION["totale"] = $row['totale'];
	$_SESSION["totalf"] = $row['totalf'];
	$_SESSION["totalg"] = $row['totalg'];
	
	//dropdown
	$_SESSION["a1"] = $row['a1'];
	$_SESSION["b1_1"] = $row['b1_1'];
	$_SESSION["c1_1"] = $row['c1_1'];
	$_SESSION["g1"] = $row['g1'];
	
	//checkbox
	$_SESSION["a2_1"] = $row['a2_1'];
	$_SESSION["a2_2"] = $row['a2_2'];
	$_SESSION["a2_3"] = $row['a2_3'];
	$_SESSION["a2_4"] = $row['a2_4'];
	$_SESSION["a3_1"] = $row['a3_1'];
	$_SESSION["a3_2"] = $row['a3_2'];
	$_SESSION["a3_3"] = $row['a3_3'];
	$_SESSION["a4_1"] = $row['a4_1'];
	$_SESSION["a4_2"] = $row['a4_2'];
	$_SESSION["a4_3"] = $row['a4_3'];
	$_SESSION["a5_1"] = $row['a5_1'];
	$_SESSION["a5_2"] = $row['a5_2'];
	$_SESSION["a6"] = $row['a6'];
	
	$_SESSION["b2_1"] = $row['b2_1'];
	$_SESSION["b2_2"] = $row['b2_2'];
	$_SESSION["b3_1"] = $row['b3_1'];
	$_SESSION["b3_2"] = $row['b3_2'];

	$_SESSION["b4_1"] = $row['b4_1'];
	$_SESSION["b4_2"] = $row['b4_2'];
	
	$_SESSION["c2_1"] = $row['c2_1'];
	$_SESSION["c2_2"] = $row['c2_2'];
	$_SESSION["c2_3"] = $row['c2_3'];
	$_SESSION["c2_4"] = $row['c2_4'];
	$_SESSION["c2_5"] = $row['c2_5'];
	$_SESSION["c2_6"] = $row['c2_6'];
	$_SESSION["c3"] = $row['c3'];
	
	$_SESSION["d1_1"] = $row['d1_1'];
	$_SESSION["d1_2"] = $row['d1_2'];
	$_SESSION["d2_1"] = $row['d2_1'];
	$_SESSION["d2_2"] = $row['d2_2'];
	$_SESSION["d3"] = $row['d3'];
	
	$_SESSION["e1_1"] = $row['e1_1'];
	$_SESSION["e1_2"] = $row['e1_2'];
	$_SESSION["e1_3"] = $row['e1_3'];
	$_SESSION["e1_4"] = $row['e1_4'];
	$_SESSION["e1_5"] = $row['e1_5'];
	$_SESSION["e1_6"] = $row['e1_6'];
	$_SESSION["e2_1"] = $row['e2_1'];
	$_SESSION["e2_2"] = $row['e2_2'];
	$_SESSION["e2_3"] = $row['e2_3'];
	$_SESSION["e3_1"] = $row['e3_1'];
	$_SESSION["e3_2"] = $row['e3_2'];
	$_SESSION["e3_3"] = $row['e3_3'];
	
	
	$_SESSION["f1_1"] = $row['f1_1'];
	$_SESSION["f1_2"] = $row['f1_2'];
	$_SESSION["f1_3"] = $row['f1_3'];
	$_SESSION["f1_4"] = $row['f1_4'];
	$_SESSION["f1_5"] = $row['f1_5'];
	$_SESSION["f2_1"] = $row['f2_1'];
	$_SESSION["f2_2"] = $row['f2_2'];
	$_SESSION["f3_1"] = $row['f3_1'];
	$_SESSION["f3_2"] = $row['f3_2'];
	$_SESSION["f4_1"] = $row['f4_1'];
	$_SESSION["f4_2"] = $row['f4_2'];
	
	$_SESSION["g2"] = $row['g2'];
	$_SESSION["g3"] = $row['g3'];
	$_SESSION["g4_1"] = $row['g4_1'];
	$_SESSION["g4_2"] = $row['g4_2'];
	$_SESSION["g4_3"] = $row['g4_3'];
	$_SESSION["g5"] = $row['g5'];
	$_SESSION["g6"] = $row['g6'];
	$_SESSION["g7"] = $row['g7'];
	$_SESSION["g8_1"] = $row['g8_1'];
	$_SESSION["g8_2"] = $row['g8_2'];
	$_SESSION["g8_3"] = $row['g8_3'];
	
	
	
	echo "<script> window.open('Untitled-19.php'); </script>";
   
			   }
			   
			   
			   ?>


</div>

<div id="o-wrapper" class="o-wrapper" style="height:400px; " >

 <div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content" style="height:400px;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">
    
 
    <table width="100%" border="0" style="text-align:left;">
  <tr>
    <td><form  method = "post" action = "<?php $_PHP_SELF ?>">
                  <input name = "viewalldata" type = "submit" id="viewbutton"  value = "Refresh" style="background-color:#ffc107; border:none" >
                  
                  
                  
                  <input name = "sbox" type = "text"  size="40" onKeyPress="return submitenter(this,event)"  id = "namanyay-search-box" placeholder="Search"  >
                  
                 
                  
                   <select name="sdown" id="namanyay-search-box" >
                  <option value="grade" title="By grade A/B/C and F for fail"> By grade</option>
                  <option value="Month" title="By number 1 - 12 to represent month"> By month</option>
                  <option value="Year" title="By number"> By year</option>
                  <option value="nokppelesen" title="Premise owner IC"> Premise owner IC</option>
                  <option value="createby" title="The Inspector name"> By Inspector</option>
                  </select>
                  
                  
                  </select>
                 
                  <input name = "sdata" type = "submit" id="sdata" value = "Search" style="background-color:#ffc107; border:none" >
                   
                  
                  
               </form></td>
    <td style="text-align:right;">
    <div id="printreport" style="cursor:pointer; float:right;">   
   </div>
    <form  name="bulk_action_form" action="action4.php" method="post" onSubmit="return delete_confirm();"/>
 

   
 
   
        </td>
  </tr>
  
</table>

    
<table width="100%" border="0">
  <tr>
    <td> <?php
		
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

?>

<?php
 if(isset($_POST['viewalldata'])){
		$_SESSION["check3"] = 0; 
		$_SESSION["page"] = 0;
		$_GET['page'] = 0;
		
		$_SESSION["type"] = "viewall";
		$_SESSION["value"] = "viewall";
	 }
	 
if(isset($_POST['sdata'])){
	$_SESSION["check3"] = 1;
	$_SESSION["searchrow"] = $_POST['sbox'];
	$_SESSION["page"] = 0;
	$_GET['page'] = 0;
	$_SESSION["sdown"] = $_POST['sdown'];
	
	$_SESSION["type"] = $_POST['sdown'];
	$_SESSION["value"] = strtoupper($_POST['sbox']);
	
	?>
    
    <?php
}


if($_SESSION["check3"] == 1){
 $tbl_name="premisesdetail";	
	$searchrow = $_SESSION['searchrow'];
	$sdown = $_SESSION['sdown'];
	
	$adjacents = 5;
	
	if( $searchrow == ""){
		$query = "SELECT COUNT(*) as num FROM $tbl_name ";
	}
	else{
		$query = "SELECT COUNT(*) as num FROM $tbl_name WHERE  ".$sdown." LIKE '%$searchrow%' ";
	}
	
	
	$total_page1s = mysql_fetch_array(mysql_query($query));
	$total_page1s = $total_page1s['num'];
	
	
	
	$targetpage11 = "searchform.php"; 	
	$limit = 7; 	
	if(isset($_GET['page1']) ) {
          $page11 = $_GET['page1'];
   }else {
          $page11 = 0;
   }
	if($page11) 
		$start1 = ($page11 - 1) * $limit; 			
	else
		$start1 = 0;								
	
	
	
	if( $searchrow == ""){
		$sql = "SELECT * FROM $tbl_name LIMIT $start1, $limit";
	}
	else{
		$sql = "SELECT * FROM $tbl_name WHERE ".$sdown." LIKE '%$searchrow%' LIMIT $start1, $limit";
	}
	$result = mysql_query($sql);
	
	
	if ($page11 == 0) $page11 = 1;					
	$prev1 = $page11 - 1;							
	$next1 = $page11 + 1;							
	$lastpage11 = ceil($total_page1s/$limit);		
	$lpm1 = $lastpage11 - 1;						
	
	
	$pagination = "";
	if($lastpage11 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px; text-align:center; \">";
		
		if ($page11 > 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$prev1\"> << </a>";
		else
			$pagination.= "<span class=\"disabled\"> << </span>";	
		
		
		if ($lastpage11 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage11; $counter++)
			{
				if ($counter == $page11)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage11 > 5 + ($adjacents * 2))	
		{
			
			if($page11 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			elseif($lastpage11 - ($adjacents * 2) > $page11 && $page11 > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page11 - $adjacents; $counter <= $page11 + $adjacents; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			else
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage11 - (2 + ($adjacents * 2)); $counter <= $lastpage11; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($page11 < $counter - 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$next1\"> >> </a>";
		else
			$pagination.= "<span class=\"disabled\"> >> </span>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
?>

	<?php
	echo "<div style='height:300px;  '>";
	echo '
    <table id="customers">
        <thead><tr>
           <th>No siri Borang</th>
			<th>Premises Name</th>
			<th>Owner IC</th>
			<th style="text-align:center">Date</th>
            <th style="text-align:center">Grade</th>
			<th style="text-align:center">Check By</th>
			<th style="text-align:center">View Detail</th> 
         
        </tr>
        </thead>';
		if($total_page1s > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>' . $row['nosiriborang'] . '</td>'.
	       '<td>'  . $row['namasyarikat'] . '</td>'.
		   '<td>'  . $row['nokppelesen'] . '</td>'.
		   '<td style="text-align:center">'  . $row['tarikh'] . '</td>'.
		   '<td style="text-align:center">'  . $row['grade'] . '</td>'.
		   '<td style="text-align:center">'  . $row['createby'] . '</td>'.
		   
		     '
		   
	       <td style="text-align:center;"> <input id="viewdetail" type="button" name="'.$row['nosiriborang'].'" onClick=    
               "viewrecord(this.name)"  value="View Detail"/>
            
            
            </td>   
          </tr> ';
	
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		 $_SESSION["type"] = "empty";
         $_SESSION["value"] = "empty";
		}
		echo ' </table>';
		echo "</div><br/><br/><br/>";
	?>
	<?php	
}
else{

	$tbl_name="premisesdetail";	
	
	$adjacents = 5;
	
	$query = "SELECT COUNT(*) as num FROM $tbl_name ";
	$total_page1s = mysql_fetch_array(mysql_query($query));
	$total_page1s = $total_page1s['num'];
	
	
	
	$targetpage11 = "searchform.php"; 	
	$limit = 7; 	
	if(isset($_GET['page1']) ) {
          $page11 = $_GET['page1'];
   }else {
          $page11 = 0;
   }
	if($page11) 
		$start1 = ($page11 - 1) * $limit; 			
	else
		$start1 = 0;								
	
	
	$sql = "SELECT * FROM $tbl_name LIMIT $start1, $limit";
	$result = mysql_query($sql);
	
	
	if ($page11 == 0) $page11 = 1;					
	$prev1 = $page11 - 1;							
	$next1 = $page11 + 1;							
	$lastpage11 = ceil($total_page1s/$limit);		
	$lpm1 = $lastpage11 - 1;						
	
	
	$pagination = "";
	if($lastpage11 > 1)
	{	
		$pagination.= "<div class=\"pagination\" style=\"height:50px; text-align:center; \">";
		
		if ($page11 > 1) 
			$pagination.= "<a href=\"$targetpage11?page1=$prev1\"> << </a>";
		else
			$pagination.= "<span class=\"disabled\"> << </span>";	
		
		
		if ($lastpage11 < 7 + ($adjacents * 2))	
		{	
			for ($counter = 1; $counter <= $lastpage11; $counter++)
			{
				if ($counter == $page11)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage11 > 5 + ($adjacents * 2))	
		{
			
			if($page11 < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			elseif($lastpage11 - ($adjacents * 2) > $page11 && $page11 > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page11 - $adjacents; $counter <= $page11 + $adjacents; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"$targetpage11?page1=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=$lastpage11\">$lastpage11</a>";		
			}
			
			else
			{
				$pagination.= "<a href=\"$targetpage11?page1=1\">1</a>";
				$pagination.= "<a href=\"$targetpage11?page1=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage11 - (2 + ($adjacents * 2)); $counter <= $lastpage11; $counter++)
				{
					if ($counter == $page11)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage11?page1=$counter\">$counter</a>";					
				}
			}
		}
		
		
		if ($page11 < $counter - 1) 
			$pagination.= "<a  href=\"$targetpage11?page1=$next1\"> >> </a>";
		else
			$pagination.= "<span class=\"disabled\"> >> </span>";
		$pagination.= "</div>\n";		
	}
	mysql_close($con);
   
?>

	<?php
	echo "<div style='height:300px; '>";
	echo '
    <table id="customers">
        <thead><tr>
           <th>No siri Borang</th>
			<th>Premises Name</th>
			<th>Owner IC</th>
			<th style="text-align:center">Date</th>
            <th style="text-align:center">Grade</th>
			<th style="text-align:center">Check By</th>
			<th style="text-align:center">View Detail</th>
         
        </tr>
        </thead>';
		if($total_page1s > 0){
		while($row = mysql_fetch_array($result))
		{			
	    echo '<tr> <td>' . $row['nosiriborang'] . '</td>'.
	       '<td>'  . $row['namasyarikat'] . '</td>'.
		   '<td>'  . $row['nokppelesen'] . '</td>'.
		   '<td style="text-align:center">'  . $row['tarikh'] . '</td>'.
		   '<td style="text-align:center">'  . $row['grade'] . '</td>'.
		   '<td style="text-align:center">'  . $row['createby'] . '</td>'.
		   
		     '
		   
	       <td style="text-align:center;"> <input id="viewdetail" type="button" name="'.$row['nosiriborang'].'" onClick=    
               "viewrecord(this.name)"  value="View Detail"/>
            
            
            </td>
          </tr> ';
	
		}
		}else{
		echo ' <tr><td colspan="5">No records found.</td></tr> ';	
		 $_SESSION["type"] = "empty";
         $_SESSION["value"] = "empty";
		}
		echo ' </table>';
		echo "</div><br/><br/><br/>";
		?>
        <?php
}
?></td>
  </tr>
</table>

<table width="100%" height="100px" border="0">
  <tr>
    <td><?=$pagination?></td>
  </tr>
</table>

    
                    
               
     
     </div><!-- /o-container -->
           </form>    




<div class="dummy2"> 


</div>
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           
           </div>
             <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   ?>
            
            </div>
           
            <div class="mid">
            
            
             <button class="reportbutton" id="reportbutton" type="button" onclick="">Homepage</button>
           
            <script type="text/javascript">
            document.getElementById("reportbutton").onclick = function () {
            location.href = "adminhomepage.php";
            };
	        </script>
            
            
           <button class="menubutton" id="menubutton" type="button" onclick="" >User Management</button>
           
            <script type="text/javascript">
            document.getElementById("menubutton").onclick = function () {
            location.href = "usermodule.php";
            };
	        </script>
            
            <button class="reportbutton" id="myinfo" type="button" onclick="">myinfo</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo.php";
            };
	        </script>
            
            <button class="reportbutton" id="notice" type="button" onclick="">Notice</button>
          <script type="text/javascript">
            document.getElementById("notice").onclick = function () {
            location.href = "notice.php";
            };
          </script>
            
              <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="logout">
            </form>
            
            
           <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
           
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
 
  
 
 function submitenter(myfield,e) { 
    var keycode; 
	if (window.event) keycode = window.event.keyCode; 
	else if (e) keycode = e.which; else return true; 
	if (keycode == 13) { 
	document.getElementById("sdata").click(); return false; 
	} 
	  else return true; }
	  
	  function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
	  
	  
	    function delete_confirm(){
	var result = confirm("Are you sure to delete users?");
	if(result){
		return true;
	}else{
		return false;
	}
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
	
	$('.checkbox').on('click',function(){
		if($('.checkbox:checked').length == $('.checkbox').length){
			$('#select_all').prop('checked',true);
		}else{
			$('#select_all').prop('checked',false);
		}
	});
});


function viewrecord(clicked_id)
              {
                   document.myformz.searchid.value = clicked_id;
                   document.forms["myformz"].submit();
                   document.getElementById("search321").click();
				   
               }
			   
			   

$(document).ready(function(){
    $("#printreport").click(function(){
		<?php
		if( $_SESSION["type"] == "empty"){
			echo 'alert("Nothing to print")';
		}
		else{
			echo 'window.open("a/index.php")';
		}
		
		
		?>

    });
});



</script>

<script>
         $(function() {
            $( document ).tooltip();
         });
      </script>
      
       <style>
         label {
            display: inline-block;
            width: 15em;
         }
      </style>

</body>
</html>