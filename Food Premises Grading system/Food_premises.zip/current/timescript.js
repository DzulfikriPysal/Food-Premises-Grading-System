  function mask(inputName, mask, evt) {
    try {
      var text = document.getElementById(inputName);
      var value = text.value;

      // If user pressed DEL or BACK SPACE, clean the value
      try {
        var e = (evt.which) ? evt.which : event.keyCode;
        if ( e == 46 || e == 8 ) {
          text.value = "";
          return;
        }
      } catch (e1) {}

      var literalPattern=/[0\*]/;
      var numberPattern=/[0-9]/;
      var newValue = "";

      for (var vId = 0, mId = 0 ; mId < mask.length ; ) {
        if (mId >= value.length)
          break;

        // Number expected but got a different value, store only the valid portion
        if (mask[mId] == '0' && value[vId].match(numberPattern) == null) {
          break;
        }

        // Found a literal
        while (mask[mId].match(literalPattern) == null) {
          if (value[vId] == mask[mId])
            break;

        newValue += mask[mId++];
      }

      newValue += value[vId++];
      mId++;
    }

    text.value = newValue;
  } catch(e) {}
}


function checktimestart(){
	 var timestart = document.getElementById("tstart").value;
	 var res1 = timestart.split(":");
	 
	 
	 
	 if(res1[0] >= 24 || res1[1] == undefined || res1[1] >= 60){
		 $("#invalidinput1").show();
		 document.getElementById("tstart").value = "";
	 }
	 else{
		  $("#invalidinput1").hide();
	 }
	
	
	if(timestart != ""){
		$("#invalidinput3").hide();
	}
	
}


function checktimeend(){
	
	 var timestart = document.getElementById("tstart").value;
	 var res1 = timestart.split(":");
	 var timeend = document.getElementById("tend").value;
	 var res2 = timeend.split(":");
	 
	
	 
	 
	  if(res2[0] >= 24 || res2[1] == undefined || res2[1] >= 60 ){
		 $("#invalidinput2").show();
		 document.getElementById("tend").value = "";
	 }
	 else{
		  $("#invalidinput2").hide();
	 }
	 
	  if(timestart == ""){
		 $("#invalidinput3").show();
		 $("#invalidinput2").hide();
		 document.getElementById("tend").value = "";
	 }
	 else{
		 $("#invalidinput3").hide();
	 }
	 
	 if(res1[0] > res2[0]){
		 $("#invalidinput2").show();
		 document.getElementById("tend").value = "";
	 }
	 else if(res1[0] < res2[0]){
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	
	 
	
}