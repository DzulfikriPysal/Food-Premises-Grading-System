
<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');

$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

function SignIn()
{
session_start();   
if(!empty($_POST['user']))  
{
	
	if(! get_magic_quotes_gpc() ) {
    $pass1 = addslashes ($_POST['pass']);
  
  }else {
    $pass1 = $_POST['pass'];
  }
  $pass1 = hash("sha512", $pass1); 

	$query = mysql_query("SELECT staffid,Password, mode , lastseen , activity  FROM user where staffid = '$_POST[user]' AND Password =    
	'$pass1'") or die(   mysql_error());
	$row = mysql_fetch_array($query);
	if(!empty($row['staffid']) AND !empty($row['Password']))
	{
		if($row['activity'] == 0){
			if($row['mode'] == 2){
			$_SESSION['staffid'] = $row['staffid'];
			$_SESSION['mode'] = $row['mode'];
			$_SESSION['lastseen'] = $row['lastseen'];
            header("Location: userhomepage.php");
			$_SESSION['success_msg'] = "Welcome to User Homepage";
			$_SESSION["check2"] = 0; 
			$_SESSION["check3"] = 0; 
			
			
			  $hostname_connect = "localhost";
              $database_connect = "premises";
              $username_connect = "root";
              $password_connect = "";
              $connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);

              if(! $connect ) {
               die('Could not connect: ' . mysql_error());
            }
			
			 
			  
			  $id = $_SESSION["staffid"];
              
               $sql = "UPDATE user ". "SET activity = '1'". 
               "WHERE staffid = '$id'" ;
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $connect );
               mysql_close($connect);
				   
		}
		
		else{
			$_SESSION['staffid'] = $row['staffid'];
			$_SESSION['mode'] = $row['mode'];
			$_SESSION['lastseen'] = $row['lastseen'];
            header("Location: adminhomepage.php");
			$_SESSION['success_msg'] = "Welcome to Admin Homepage";
			$_SESSION["check"] = 0; 
			$_SESSION["check3"] = 0; 
			
			  $hostname_connect = "localhost";
              $database_connect = "premises";
              $username_connect = "root";
              $password_connect = "";
              $connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);

              if(! $connect ) {
               die('Could not connect: ' . mysql_error());
            }
			
			 
			  
			  $id = $_SESSION["staffid"];
              
               $sql = "UPDATE user ". "SET activity = '1'". 
               "WHERE staffid = '$id'" ;
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $connect );
               mysql_close($connect);
				   
			
		}
		
			}else if($row['activity'] == 1){
				 header("Location: homepage.php");
		         $_SESSION['success_msg'] = "User Login Already";
			}
		
	}
	else
	{
		 header("Location: homepage.php");
		 $_SESSION['success_msg'] = "Fail To Login";
	}
}
}
if(isset($_POST['submit']) )
{
	SignIn();
}

mysql_close($con);

?>
