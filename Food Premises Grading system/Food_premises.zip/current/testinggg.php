<?php
session_start();
if (isset($_SESSION['hehe'])) {
	
	print '<script type="text/javascript">';
    print 'alert("Session time out!")';
    print '</script>'; 
	session_destroy(); 
}
else if(isset($_SESSION['directory'])){
	$logout_redirect_url = $_SESSION['directory'];
	header("Location: $logout_redirect_url");
}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">

  <style>


 #sec3 {
    padding: 0em;
    color: black;
    clear: left;
    text-align: center;
	position:fix;
}

#sec1 {
    float: left;
    max-width: 760px;
    margin: 0;
    padding: 1em;
    border:1px solid black;
	position:fix;
    height: 300px;
    max-height: 300px;
    width:700px;
    max-width:700px;
}
#sec4{
    float: left;
    max-width: 500px;
    margin: 0;
    padding: 0em;
    border:1px solid black;
    height: 300px;
    max-height: 300px;
    width:500px;
    max-width:700px;
	overflow: none;

}

#sec5{

	border:1px solid black;
    padding: 0em;
    overflow: hidden;
    height: 300px;
    max-height: 300px;
    overflow: none;
}



#sec2 {
  border:1px solid black;
    padding: 0em;
    overflow: hidden;
    height: 300px;
    max-height: 300px;
    overflow: none;

}

</style>
</head>
<body>

<div id="header" style=" height:100px; ">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px;color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px;  "></td>
  </tr>
</table>


</div>

<div id="o-wrapper" class="o-wrapper">
<div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
  
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>

  <main class="o-content" style=" border:0px solid black;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style=" border:0px solid black;">
    

<div id="sec1">
  
</div>

<div id="sec2">
  <div style="color:white; background-color: black; width:100%; ">
    Notice &  news
  </div>
  <?php
  error_reporting(E_ALL ^ E_DEPRECATED);
  define('DB_HOST', 'localhost');
  define('DB_NAME', 'premises');
  define('DB_USER','root');
  define('DB_PASSWORD','');

  $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
  $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

  $tbl_name="notice";

  $sql = "SELECT * FROM $tbl_name order by id desc";
  $result = mysql_query($sql); 

   while($row = mysql_fetch_array($result))
    {  
    ?>   
      <table width="100%" border="1" style="text-align:left;">
        <tr>
          <td>
            <form   method = "post" action = "viewnews_user.php">
                <input name = "searchid" type = "hidden" 
                           id = "textbox" required  value = "<?php echo $row['id']; ?>">
                    
                           <input name = "searchrec" type = "submit" id="searchrec"
                              value = "<?php echo $row['title']; ?>" style="background-color:#ffc107; border:none; width:343px; height:40px;white-space: normal; cursor:pointer;overflow: hidden;text-overflow: ellipsis; white-space: nowrap;" >
               
            </form>
            
          </td> 
        </tr>
      </table>


<?php
    }
    

  ?>
</div>



<div id="sec3">
  <div id="sec4" >
    <div style="background-color: black; color:white;">
      Highest Grade
    </div>
    <?php
  

  $tbl_name="notice";

  $sql = "SELECT * FROM $tbl_name order by id desc";
  $result = mysql_query($sql); 

   while($row = mysql_fetch_array($result))
    {  
    ?>   
      <table width="100%" border="1" style="text-align:left;">
        <tr>
          <td>
            <form   method = "post" action = "viewnews_user.php">
                <input name = "searchid" type = "hidden" 
                           id = "textbox" required  value = "<?php echo $row['id']; ?>">
                    
                           <input name = "searchrec" type = "submit" id="searchrec"
                              value = "<?php echo $row['title']; ?>" style="background-color:#ffc107;white-space: normal; border:none; width:490px; height:40px; cursor:pointer;overflow: hidden;text-overflow: ellipsis; white-space: nowrap;" >
               
            </form>
            
          </td> 
        </tr>
      </table>


<?php
    }
    

  ?>
  </div>

  
  <div id="sec5">
    <div style="background-color: black; color:white;">
      Lowest Grade
    </div>
     <?php
  

  $tbl_name="notice";

  $sql = "SELECT * FROM $tbl_name order by id desc";
  $result = mysql_query($sql); 

   while($row = mysql_fetch_array($result))
    {  
    ?>   
      <table width="100%" border="1" style="text-align:left;">
        <tr>
          <td>
            <form   method = "post" action = "viewnews_user.php">
                <input name = "searchid" type = "hidden" 
                           id = "textbox" required  value = "<?php echo $row['id']; ?>">
                    
                           <input name = "searchrec" type = "submit" id="searchrec"
                              value = "<?php echo $row['title']; ?>" style="background-color:#ffc107;white-space: normal; border:none; width:543px; height:40px; cursor:pointer;overflow: hidden;text-overflow: ellipsis; white-space: nowrap;" >
               
            </form>
            
          </td> 
        </tr>
      </table>


<?php
    }
    

  ?>
  </div>


</div>



     


    </div><!-- /o-container -->
  </main><!-- /o-content -->

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <div class="top" style="background-image:url(A.PNG)">
           </div>
           
            <div class="mid" style="top:165px;">
            
            <div class="login-screen">
			<div class="app-title">
				<h1 style="color:#FFF">Login</h1>
			</div>

			<div class="login-form">
           
             <form class="loginform" method="POST" action="connectivity.php" > 
                 <div class="control-group">
				      <input id="login-field" id="login-name" type="text" name="user" size="25" required="required" placeholder="Staff ID">
				</div>
                     <input id="login-field" id="login-name" type="password" name="pass" size="25" required="required" minlength="10" maxlength="20" placeholder="Password">
				<div class="control-group">
				
				</div>
              
                 <input id="btnlogin" type="submit" name="submit" value="Log-In">
				<a class="login-link" href="resetpassword.php" style="color:#FFF">Lost your password?</a>
          </form>
         
      
          </div>
          </div>
          
          
          
           <button id="c-menu__close" class="c-menu__close">&larr; Close Menu</button>
           </div>
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  



  
  

</script>



</body>
</html>