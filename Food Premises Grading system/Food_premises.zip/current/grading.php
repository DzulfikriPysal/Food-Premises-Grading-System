<?php
session_start();
$_SESSION['directory'] = "grading.php";
$timeout = 15;
$logout_redirect_url = "sessiontimeout.php"; 

$timeout = $timeout * 60;

if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
    <link rel="stylesheet" href="css3.css">
    <link rel="stylesheet" href="css4.css">
   <link rel="stylesheet" href="datepicker.css">
    <script type="text/javascript" src="timescript.js" ></script>
       <script type = "text/javascript" 
         src = "jquery.js"></script>
        
      <script type = "text/javascript" 
         src = "jquery-ui.js"></script>
		

    <style>
ul.pagination {
    display: inline-block;
    padding: 0;
    margin: 0;
}

ul.pagination li {display: inline;}

ul.pagination li a {
    color: black;
    float: left;
    padding: 8px 16px;
    text-decoration: none;
    border-radius: 5px;
}


ul.pagination li a:hover:not(.active) {background-color: #FF0}

#A {
    font-family: "Ubuntu", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#A td, #customers th {
    border: 1px solid #ddd;
    text-align: left;
    padding: 8px;
}

#A tr:nth-child(even){background-color: #f2f2f2}

#A tr:hover {background-color: #FFB74D;}

#A th {
    padding-top: 12px;
    padding-bottom: 12px;
    background-color: #E65100;
    color: white;
}
</style>
    
</head>

<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button" ><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; color:#FFF;">Grading Report</td>
  </tr>
</table>

</div>

<div id="o-wrapper" class="o-wrapper" >

 <div style="width:100%; height:60px; float:left">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>
  
  <main class="o-content">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style=" height:1450px; text-align:start;">
    
   
    <?php
	if(!isset($_POST['searchid'])){
		$searchid = $_SESSION['ownerid'];
		}
		else{
		$searchid = $_POST['searchid'];	
		}
  
	$_SESSION['ownerid'] = $searchid;
	
	
	
	error_reporting(E_ALL ^ E_DEPRECATED);
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'premises');
    define('DB_USER','root');
    define('DB_PASSWORD','');

    $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
    $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
	
	$query = mysql_query("SELECT * FROM premisesowner WHERE id = '$searchid' " );
	$row = mysql_fetch_array($query);

	?>

 <form name="myform" method = "post" action = "register_record.php" >
 
  <div id="aa" >
  
            
            <table width="100%" border="0">
  <tr>
    <td>mark : </td>
    <td><input type="text" name="currentmark" id="currentmark" value="100" readonly/></td>
  </tr>
  <tr>
    <td>grade : </td>
    <td><input type="text" name="currentgrade" id="currentgrade"  value="A" readonly/></td>
  </tr>
</table>

           
 
   
   
   <input type="submit"  name="add" style="float:right; margin-right:5px; cursor:pointer;"  value="Save" id="savebutton" >
    <input type="button" id="backbutton" value="cancel"/>
   
   <script type="text/javascript">
            document.getElementById("backbutton").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
   
   </div>
   
   
 
<div id="flip" style=" top: 130px; width:45px; height:30px;cursor:pointer; background-image:url(up.jpg); background-size: contain; background-repeat:no-repeat;">
</div>
<div id="oppai">
  

    <ul class="pagination" style="position:absolute; right:0px; top:0px;">
        <li> <a style="cursor:pointer;" onclick="form1();">A</a></li>
        <li><a style="cursor:pointer" onclick="form2();">B</a></li>
        <li><a style="cursor:pointer" onclick="form3();">C</a></li>
        <li><a style="cursor:pointer" onclick="form4();">D</a></li>
        <li><a style="cursor:pointer" onclick="form5();">E</a></li>
        <li><a style="cursor:pointer" onclick="form6();">F</a></li>
        <li><a style="cursor:pointer" onclick="form7();">G</a></li>
 </ul>   
    
     <div id="pantsu">

   </div>
</div>
 
   <h1 style="text-align:center">Borang Pemeriksaan Dan Penggredan Premis Makanan</h1>
   
    <table width="90%" border="0">
  <tr>
    <td style="text-align:start;">Serial Number</td>
    <td><input id="boxx" name="nosiriborang"  required type="text"><input  name="c_id"  type="hidden" value='<?php echo $row['id'] ?>'  "></td>
 
  </tr>
  <tr>
    <td style="text-align:start;">Owner Name</td>
    <td><input id="boxx" type="text" name="ownername" readonly value='<?php echo $row['namepelesen'] ?>' ></td>
    <td style="text-align:start;">Licence Reference No</td>
    <td><input id="boxx" type="text"name="refno" onkeypress='return isNumberKey(event)'  required></td>
  </tr>
  <tr>
    <td style="text-align:start;">Company Name</td>
    <td><input id="boxx" type="text" name="companyname"  readonly value='<?php echo $row['premisesname'] ?>'></td>
    <td style="text-align:start;">Date</td>
    <td> <input type="text" size="12" id="inputField"  name="date" required readonly  style="background-color: #ECF0F1; border: 2px solid transparent; border-radius: 3px; font-size: 16px;
font-weight: 200;
padding: 10px 0;
width: 250px;
transition: border .5s;"/>


   <script>
         $(function() {
            $( "#inputField" ).datepicker({ dateFormat: 'dd-mm-yy',
			                                maxDate: '0d',
											 minDate: '-6m', maxDate: '0m', numberOfMonths:1});
         });
      
	
	
	
</script></td>
  </tr>
  <tr>
    <td style="text-align:start;">Phone Number</td>
    <td><input id="boxx" type="tel" pattern="\(\d{3}\)+\d{3}-\d(4)" name="phone" onkeypress='return isNumberKey(event)' readonly value='<?php echo $row['notel'] ?>'>
   </td>
    <td style="text-align:start;">Time</td>
    <td style="text-align:start;">
    <input id="tstart" min="5"  type="text" onkeyup="mask('tstart', '00:00', event);" onBlur="checktimestart();" style="width: 100px;" placeholder="00:00" maxlength="5"  name="tstart"    required> -
    <input min="5" onkeyup="mask('tend', '00:00', event);" placeholder="00:00" maxlength="5"    onBlur="checktimeend();" type="text" placeholder="End" id="tend" name="tend" style="width: 100px;"  >
    
  
    
    
    </td>
  </tr>
  <tr>
    <td style="text-align:start;">Owner Licence No</td>
    <td><input id="boxx" type="text" name="ownerlicence" onkeypress='return isNumberKey(event)'  readonly  value='<?php echo $row['nokppelesen'] ?>'></td>
    <td>&nbsp;</td>
    <td>
<div style="width:40%; float:left; color:#F00;"><p style="visibility:hidden;"></p><p id="invalidinput1" style="display:none;">Invalid Input!</p></div><div  style="width:50%; float:left; color:#F00; display:block;"><p id="invalidinput2" style="display:none;">Invalid Input!</p>
<p id="invalidinput3" style="display:none;">Time Start is Empty!</p></div>
</td>
  </tr>
  <tr>
    <td style="text-align:start;">Address</td>
    <td><textarea id="boxx" cols="25" rows="4" name="address" readonly><?php echo $row['address'] ?></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td style="text-align:start;">Pengendali</td>
    <td >
         
         <select name="bilpengendali" id="boxx" style="width:50px">
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
        </select>
    </td>
    <td>
        <input type="hidden" value="0" name="tibid" id="tibid">
        Suntikan pelalian anti tifoid<input id="tibid" value="1" type="checkbox"  name="tibid">
    </td>
    <td>
        <input type="hidden" value="0" name="kursus" id="kursus">
        Kursus pengendali makanan<input value="1" type="checkbox" id="kursus"  name="kursus">
    </td>
  </tr>
</table>



<div id="frame1" style="visibility:visible; height:100px">
  <table id="A" width="100%" border="1">
  <tr>
    <th style="text-align:center" scope="col" style="text-align:start;">Perkara</th>
    <th scope="col">Komponen</th>
    <th scope="col">Markah</th>
    <th scope="col">Demerit</th>
    <th scope="col">Catatan</th>
  </tr>
  <tr>
    <td>A Kawasan penyediaan makanan</td>
    <td>A1 Kawasan Suhu Penyimpanan Dan Penyediaan Makanan <br/>
        Peti sejuk <br/>
        &#9899; Suhu sejuk -18c hingga 0c</td>
    <td style="text-align:center">12</td>
    <td style="text-align:center"><select name="a1" id="a1" onChange="marks1();">
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
           <option>7</option>
           <option>8</option>
           <option>9</option>
           <option>10</option>
           <option>11</option>
           <option>12</option>
        </select>
        <input type="hidden" value="0" id="hiddena1"/>
        </td>
    <td style="text-align:center">CCP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A2 Kawalan serangga perosak / LILATI yang efektif termasuk kawalan<br/>
        &#9899; lipas<br/>
        &#9899; lalat<br/>
        &#9899; tikus<br/>
        &#9899; lain lain haiwan<br/></td>
    <td style="text-align:center"><br/><br/>
        1<br/>
        1<br/>
        1<br/>
        1<br/></td>
    <td style="text-align:center"><br><br>
    
    
         
         <input type="hidden" value="0" name="a2_1">
         <input type="hidden" value="0" name="a2_2">
         <input type="hidden" value="0" name="a2_3">
         <input type="hidden" value="0" name="a2_4">
         <input type="checkbox" name="a2_1"  value="1"><br>
        <input type="checkbox"  value="1" name="a2_2"><br>
        <input type="checkbox"  value="1" name="a2_3"><br>
        <input type="checkbox"  value="1" name="a2_4"><br></td>
    <td><textarea  cols="25" rows="7" name="ta1" maxlength="50"></textarea>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A3 kebersihan peti sejuk<br/>
        &#9899; peti sejuk sentiasa bersih<br/>
        &#9899; susunan makanan dalam keadaan teratur<br/>
        &#9899; tiada pencemaran silang<br/></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        1</td>
    <td style="text-align:center"><br>
         <input type="hidden" value="0" name="a3_1">
         <input type="hidden" value="0" name="a3_2">
         <input type="hidden" value="0" name="a3_3">
        <input type="checkbox" name="a3_1" value="1"><br>
        <input type="checkbox" name="a3_2" value="1"><br>
        <input type="checkbox" name="a3_3" value="1"><br></td>
    <td><textarea cols="25" name="ta2" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A4 Kebersihan peralatan dan kemudahan memasak<br />
        &#9899; alas memotong dan kain pengelap dalam keadaan bersih<br />
        &#9899; dilarang mengunakan kertas bercetak yang bersentuhan dengan makanan<br />
        &#9899; peralatan kulinari sentiasa dalam keadaan baik dan bersih<br /></td>
    <td style="text-align:center"><br />
        1<br/>
        1<br />
        <br />
        1</td>
    <td style="text-align:center"><br>
        <input type="hidden" value="0" name="a4_1">
        <input type="hidden" value="0" name="a4_2">
        <input type="hidden" value="0" name="a4_3"> 
        <input name="a4_1" type="checkbox" value="1"><br>
        <input type="checkbox" value="1" name="a4_2"><br><br>
        <input type="checkbox" value="1" name="a4_3"><br></td>
    <td><textarea cols="25" rows="5" name="ta3"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>A5 Sistem pelepasan asap dan haba<br/>
        &#9899; Berfungsi dengan baik serta tidak menimbulkan kacauganggu<br/>
        &#9899; kapasiti yang mencukupi dan efisyen<br/></td>
    <td style="text-align:center"><br />1<br />1</td>
    <td style="text-align:center"><br>
        <input type="hidden" value="0" name="a5_1">
        <input type="hidden" value="0" name="a5_2">
        <input type="checkbox" name="a5_1" value="1"><br>
        <input type="checkbox"name="a5_2" value="1"><br></td>
    <td><textarea cols="25" name="ta4" rows="5"></textarea></td>
  </tr>
  
   <tr>
    <td>&nbsp;</td>
    <td>A6 Ruang kelegaan di antara peralatan dan dinding/lantai<br />
        &#9899; jarak minima yang sesuai untuk penyelenggaraan dan tiada kesesakan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
        <input type="hidden" value="0" name="a6_1">
        <input type="checkbox" name="a6_1" value="1"></td>
    <td><textarea cols="25" name="ta5" rows="5"></textarea></td>
  </tr>
</table>

</div>

<div id="frame2" style="visibility:hidden; height:0px">
 <table id="A" width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>B<br/>
        Kawasan penyajian makanan   
    </td>
    <td>B1. kawalan suhu dan tempat mempamerkan makanan yang sesuai <br/> 
        mengikut keadaan dan jenis makanan<br/>
        &#9899; suhu makanan panas >60c<br/>
        &#9899; suhu makanan dingin 1c hingga 4c<br/>
        &#9899; suhu makanan sejuk beku < - 18c</td>
    <td style="text-align:center">12</td>
    <td style="text-align:center"><select name="b1" id="b1" onChange="marks2();">
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
           <option>7</option>
           <option>8</option>
           <option>9</option>
           <option>10</option>
           <option>11</option>
           <option>12</option>
        </select>
        <input type="hidden" value="0" id="hiddenb1"/>
        </td>
    <td><textarea cols="25" name="tb1" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B2 peralatan kulinari yang digunakan untuk penyajian  makanan<br/>
        perlu sentiasa dalam keadaan.<br/>
        &#9899; bersih<br/>
        &#9899; tidak sumbing, retak or karat</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <input type="hidden" value="0" name="b2_1">
                  <input type="hidden" value="0" name="b2_2">
                  <input type="checkbox" name="b2_1" value="1"><br/>
                  <input type="checkbox" name="b2_2" value="1"></td>
    <td><textarea cols="25" name="tb2" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>B3 KAIN PENGELAP ALAS DAN PERALATAN<BR/>
        perlu sentiasa dalam keadaan<br/>
        &#9899; Bersih<br/>
        &#9899; digunakan berasingan mengikut jenis kerja</td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <input type="hidden" value="0" name="b3_1">
                  <input type="hidden" value="0" name="b3_2">
                  <input type="checkbox" name="b3_1" value="1"><br/>
                  <input type="checkbox" name="b3_2" value="1"></td>
    <td><textarea cols="25" name="tb3" rows="5"></textarea></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td>B4 meja kerusi dan peralatan hendak lah<br/>
        sentiasa<br/>
        &#9899; Bersih<br/>
        &#9899; sempurna dan selamat
        </td>
    <td style="text-align:center"><br/><br/>1<br/>1</td>
    <td style="text-align:center"><br/><br/>
                  <input type="hidden" value="0" name="b4_1">
                  <input type="hidden" value="0" name="b4_2">
                  <input type="checkbox" name="b4_1" value="1"><br/>
                  <input type="checkbox" name="b4_2" value="1"></td>
    <td><textarea cols="25" name="tb4" rows="5"></textarea></td>
  </tr>
</table>

</div>

<div id="frame3" style="visibility:hidden; height:0px">
<table id="A" width="100%" border="1">
  <tr>
 <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>C<br/>pengendali makanan</td>
    <td>C1 pemeriksa kesihatan ke atas semua pengendali makanan<br/>
         &#9899; menadapat suntikan pelalian anti tifoid<br/>
         &#9899; menghadiri kursus pengendali makanan</td>
    <td style="text-align:center">6</td>
    <td style="text-align:center"><select name="c1" id="c1" onChange="marks3();">
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
           <option>6</option>
        </select>
        <input type="hidden" value="0" id="hiddenc1"/>
        </td>
    <td>CPP</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C2 tahap kebersihan diri yang baik<br/>
        &#9899; berpakaian bersih dan sesuai<br/>
        &#9899; memakai apron yang bersih dan berpenutup kepala<br/>
        &#9899; berkuku pendek bersih dan tidak memakai barang perhiasan diri<br/>
        &#9899; berkasut<br/>
        &#9899; tidak merokok<br/>
        &#9899; tidak melakukan apa apa perbuatan atau tindakan yang boleh <br/>
        menyebabkan pencemaran makanan </td>
    <td style="text-align:center">1<br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center"> 
         <input type="hidden" value="0" name="c2_1">
         <input type="hidden" value="0" name="c2_2">
         <input type="hidden" value="0" name="c2_3">
         <input type="hidden" value="0" name="c2_4">
         <input type="hidden" value="0" name="c2_5">
         <input type="hidden" value="0" name="c2_6">
         <input type="checkbox" name="c2_1" value="1"><br/>
         <input type="checkbox" name="c2_2" value="1">
    <br/><input type="checkbox" name="c2_3" value="1"><br/>
         <input type="checkbox" name="c2_4" value="1">
    <br/><input type="checkbox" name="c2_5" value="1"><br/>
         <input type="checkbox" name="c2_6" value="1"></td>
    <td><textarea cols="25" name="tc1" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>C3 tiada masalah kesihatan yang berkaitan dengan pencemaran makanan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="hidden" value="0" name="c3_1">
        <input type="checkbox" name="c3_1" value="1"></td>
    <td><textarea cols="25" name="tc2" rows="5"></textarea></td>
  </tr>
</table>
</div>
<div id="frame4" style="visibility:hidden; height:0px">

<table id="A" width="100%" border="1">
  <tr>
 <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>D<br/>sistem bekalan air</td>
    <td>D1 Sumber Bekalan air yg selamat<br/>
         &#9899; Terawat<br/>
         &#9899; berih dan mencukupi</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="d1_1">
             <input type="hidden" value="0" name="d1_2">
             <input type="checkbox" name="d1_1" value="1"><br/>
             <input type="checkbox" name="d1_2" value="1"></td>
    <td><textarea cols="25" name="td1" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D2 pengunaan sumber bekalan air<br/>
        &#9899; diambil terus dari paip<br/>
        &#9899; dilarang penggunaan paip getah </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="d2_1">
             <input type="hidden" value="0" name="d2_2">
             <input type="checkbox" name="d2_1" value="1"><br/>
             <input type="checkbox" name="d2_2" value="1"></td>
    <td><textarea cols="25" name="td2" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>D3 Tiada kebocoran paip di premis</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="hidden" value="0" name="d3_1">
        <input type="checkbox" name="d3_1" value="1"></td>
    <td><textarea cols="25"  name="td3" rows="2"></textarea></td>
  </tr>
</table>
</div>
<div id="frame5" style="visibility:hidden; height:0px">
<table id="A" width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>E<br/>kemudahan sanitassi</td>
    <td>E1 keadaan kelengkapan kemudahan tandas<br/>
        &#9899; bersih dan bebas dari bau busuk<br/>
        &#9899; sempurna dan berfungsi dengan baik<br/>
        &#9899;kedudukan pintu tandas tidak boleh menghala terus ke kawasan <br/>
                penyediaan makanan<br/>
        &#9899; pengudaraan sempurna<br/>
        &#9899; bekalan air mencukupi<br/>
        &#9899; disediakan sabun dan tisu/alat pengering<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="e1_1">
             <input type="hidden" value="0" name="e1_2">
             <input type="hidden" value="0" name="e1_3">
             <input type="hidden" value="0" name="e1_4">
             <input type="hidden" value="0" name="e1_5">
             <input type="hidden" value="0" name="e1_6">
             <input type="checkbox" name="e1_1" value="1"><br/>
             <input type="checkbox" name="e1_2" value="1"><br/>
             <input type="checkbox" name="e1_3" value="1"><br/><br/>
             <input type="checkbox" name="e1_4" value="1"><br/>
             <input type="checkbox" name="e1_5" value="1"><br/>
             <input type="checkbox" name="e1_6" value="1"></td>

    <td><textarea cols="25" name="te1" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E2 kemudahan mencukupi<br/>
        &#9899; sinki yang mencukupi<br>
        &#9899; perangkap sisa makanan, minyak dan lemak(fog) berfungsi dan<br/>
        diselengara dengan baik.<br/>
        &#9899; kapasiti perangkap fog yg tersusun</td>
    <td style="text-align:center"><br/>1<br/>1<br/><br/>1</td>
    <td style="text-align:center"><br/><input type="hidden" value="0" name="e2_1">
             <input type="hidden" value="0" name="e2_2">
             <input type="hidden" value="0" name="e2_3">
             <input type="checkbox" name="e2_1" value="1"><br/>
             <input type="checkbox" name="e2_2" value="1"><br/><br/>
             <input type="checkbox" name="e2_3" value="1"></td>
    <td><textarea cols="25" name="te2" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>E3 kemudahan tempat mencuci tangan<br/>
        &#9899; bersih<br/>
        &#9899; sempurna<br/>
        &#9899; kemudahan sabun cecair dan pengering tangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="e3_1">
             <input type="hidden" value="0" name="e3_2">
             <input type="hidden" value="0" name="e3_3">
             <input type="checkbox" name="e3_1" value="1"><br/>
             <input type="checkbox" name="e3_2" value="1"><br/>
             <input type="checkbox" name="e3_3" value="1"></td>
    <td><textarea cols="25" name="te3" rows="2"></textarea></td>
  </tr>
</table>
</div>
<div id="frame6" style="visibility:hidden; height:0px">
<table id="A" width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>F Struktur dan penyenggaraan premis</td>
    <td>F1 keadaan lantai dinding dan siling<br/>
       &#9899; tidak licin tahan lasak<br/>
       &#9899; mudah dibersihkan<br/>
       &#9899; kalis air<br/>
       &#9899; tidak menakung air / rata<br/>
       &#9899; bebas dari sesawang habuk kulat<br/>
    </td>
    <td style="text-align:center"><br/>1<br/>1<br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
        <input type="hidden" value="0" name="f1_1">
        <input type="hidden" value="0" name="f1_2">
        <input type="hidden" value="0" name="f1_3">
        <input type="hidden" value="0" name="f1_4">
        <input type="hidden" value="0" name="f1_5">
        <br/><input type="checkbox" name="f1_1" value="1">
        <br/><input type="checkbox" name="f1_2" value="1">
        <br/><input type="checkbox" name="f1_3" value="1">
        <br/><input type="checkbox" name="f1_4" value="1">
        <br/><input type="checkbox" name="f1_5" value="1"></td>
    <td><textarea cols="25" name="tf1" rows="2" ></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F2 Sistem pengudaraan dan pencahayaan<br/>
        &#9899; mencukupi<br/>
        &#9899; berfungsi.</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="f2_1">
             <input type="hidden" value="0" name="f2_2">
             <input type="checkbox" name="f2_1" value="1"><br/>
             <input type="checkbox" name="f2_2" value="1"></td>
    <td><textarea cols="25" name="tf2" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F3 sistem perparitan yang sempurna<br/>
        &#9899; bersih<br/>
        &#9899; disenggara dengan baik<br/>
        </td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center"><br/>
             <input type="hidden" value="0" name="f3_1">
             <input type="hidden" value="0" name="f3_2">
             <input type="checkbox" name="f3_1" value="1"><br/>
             <input type="checkbox" name="f3_2" value="1"></td>
    <td><textarea cols="25" name="tf3" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>F4 sistem pengurusan air imbah yang sempurna<br/>
        &#9899; mengalir lancar<br/>
        &#9899; tiada sisa makanan</td>
    <td style="text-align:center"><br/>1<br/>1</td>
    <td style="text-align:center">
        <input type="hidden" value="0" name="f4_1">
        <input type="hidden" value="0" name="f4_2">
        <br/><input type="checkbox" name="f4_1" value="1">
        <br/><input type="checkbox" name="f4_2" value="1"></td>
    <td><textarea cols="25" name="tf4" rows="2"></textarea></td>
  </tr>
</table>
</div>
<div id="frame7" style="visibility:hidden; height:0px">
<table id="A" width="100%" border="1">
  <tr>
    <th scope="col">Perkara</th>
    <th scope="col">komponen</th>
    <th scope="col">markah</th>
    <th scope="col">demerit</th>
    <th scope="col">catatan</th>
  </tr>
  <tr>
    <td>G lain lain generik</td>
    <td>G1 Maklumbalas pelangan</td>
    <td style="text-align:center">5</td>
    <td style="text-align:center">
        <select name="g1" id="g1" onChange="marks4();">
           <option>0</option>
           <option>1</option>
           <option>2</option>
           <option>3</option>
           <option>4</option>
           <option>5</option>
        </select>
        <input type="hidden" value="0" id="hiddeng1"/>
    </td>
    <td><textarea cols="25" name="tg1" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G2 kemudahan tong sampah yang mencukupi berpenutup bersih<br/>
        dan berkarung</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="hidden" value="0" name="g2">
        <input type="checkbox" name="g2" value="1"></td>
    <td><textarea cols="25" name="tg2" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G3 bahan makanan dan bahan kimai hendaklah disimpan secara <br/>
        berasingan kedua duanya mestilah berlabel</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="hidden" value="0" name="g3">
        <input type="checkbox" name="g3" value="1"></td>
    <td><textarea cols="25" name="tg3" rows="2"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G4 penyediaan dan pengurusan stor yang baik(fifo kalis kulat)<br/>
        &#9899; susun atur dan ruang kelegaan<br/>
        &#9899; kebersihan<br/>
        &#9899; pengudaraan dan pencahayaan<br/></td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
        <input type="hidden" value="0" name="g4_1">
        <input type="hidden" value="0" name="g4_2">
        <input type="hidden" value="0" name="g4_3">
        <br/><input type="checkbox" name="g4_1" value="1">
        <br/><input type="checkbox" name="g4_2" value="1">
        <br/><input type="checkbox" name="g4_3" value="1"></td>
    <td><textarea cols="25" name="tg4" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G5 amalan pengurusan sisa pepejal yang baik<br/>
        (pengasigan di punca</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
     <input type="hidden" value="0" name="g5">
     <input type="checkbox" name="g5" value="1"></td>
    <td><textarea cols="25" name="tg5" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G6 premis dan peralatan perlu disengara dengan baik dan<br/>
        jadual pembersihan mestilah di pantau secara berterusan</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center"><input type="hidden" value="0" name="g6">
        <input type="checkbox" name="g6" value="1"></td>
    <td><textarea cols="25" name="tg6" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G7 Notis pemberitahuan kebersihan amalan<br/>
        keselamatan pendidikan kesihatan dan larangan<br/>
        merokok</td>
    <td style="text-align:center">1</td>
    <td style="text-align:center">
     <input type="hidden" value="0" name="g7">
     <input type="checkbox" name="g7" value="1"></td>
    <td><textarea cols="25" name="tg7" rows="3"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>G8 kawalan dan keselamatan di premis makanan<br/>
        &#9899; alat pemadam api<br/>
        &#9899; peti pertolongan ccemas<br/>
        &#9899; ruang bebas dari sebarang halangan</td>
    <td style="text-align:center"><br/>1<br/>1<br/>1</td>
    <td style="text-align:center">
        <input type="hidden" value="0" name="g8_1">
        <input type="hidden" value="0" name="g8_2">
        <input type="hidden" value="0" name="g8_3"> 
        <br/><input type="checkbox" name="g8_1" value="1">
        <br/><input type="checkbox" name="g8_2" value="1">
        <br/><input type="checkbox" name="g8_3" value="1"></td>
    <td><textarea cols="25" name="tg8" rows="5"></textarea></td>
  </tr>
</table>



</div>

  </form>




    </div>
    
    <div class="dummy2"> 

</div>
    
    </main>
    </div>
    
    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
           <button class="addrecord" id="addrecord" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
             <button class="addrecord" id="addrecord2" type="button" onclick="" >Grading Management</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord2").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
            
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "searchform2.php";
            };
	        </script>
             <button class="reportbutton" id="myinfo" type="button" onclick="">my Info</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo2.php";
            };
	        </script>
            
            
       
            
             <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="Logout">
            </form>
            
             <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js2.js"></script>
<script>
  
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
  </script>




</body>
</html>

<script>
  
  var form1 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f1.style.height = '100px';
	f2.style.height = '0px';
	f3.style.height = '0px';
	f4.style.height = '0px';
	f5.style.height = '0px';
	f6.style.height = '0px';
	f7.style.height = '0px';
	f1.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f6.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	
	window.scrollTo(0, 550);
	
  }
  
   var form2 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f2.style.height = '100px';
	f1.style.height = '0px';
	f3.style.height = '0px';
	f4.style.height = '0px';
	f5.style.height = '0px';
	f6.style.height = '0px';
	f7.style.height = '0px';
	
	f2.style.visibility = 'visible';
	f6.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	
	 window.scrollTo(0, 550);
  }
  
   var form3 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f3.style.height = '100px';
	f2.style.height = '0px';
	f1.style.height = '0px';
	f4.style.height = '0px';
	f5.style.height = '0px';
	f6.style.height = '0px';
	f7.style.height = '0px';
	f3.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f6.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	window.scrollTo(0, 550);
  }
  
   var form4 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f4.style.height = '100px';
	f2.style.height = '0px';
	f3.style.height = '0px';
	f1.style.height = '0px';
	f5.style.height = '0px';
	f6.style.height = '0px';
	f7.style.height = '0px';
	f4.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f6.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	window.scrollTo(0, 550);
  }
  
   var form5 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f5.style.height = '100px';
	f2.style.height = '0px';
	f3.style.height = '0px';
	f4.style.height = '0px';
	f1.style.height = '0px';
	f6.style.height = '0px';
	f7.style.height = '0px';
	f5.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	f6.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	window.scrollTo(0, 550);
  }
  
   var form6 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f6.style.height = '100px';
	f2.style.height = '0px';
	f3.style.height = '0px';
	f4.style.height = '0px';
	f5.style.height = '0px';
	f1.style.height = '0px';
	f7.style.height = '0px';
	f6.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f7.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	window.scrollTo(0, 550);
	
  }
  
   var form7 = function() {
	  var f1 = document.getElementById('frame1');
	  var f2 = document.getElementById('frame2');
	  var f3 = document.getElementById('frame3');
	  var f4 = document.getElementById('frame4');
	  var f5 = document.getElementById('frame5');
	  var f6 = document.getElementById('frame6');
	  var f7 = document.getElementById('frame7');
    f7.style.height = '100px';
	f2.style.height = '0px';
	f3.style.height = '0px';
	f4.style.height = '0px';
	f5.style.height = '0px';
	f6.style.height = '0px';
	f1.style.height = '0px';
	f7.style.visibility = 'visible';
	f2.style.visibility = 'hidden';
	f3.style.visibility = 'hidden';
	f4.style.visibility = 'hidden';
	f5.style.visibility = 'hidden';
	f6.style.visibility = 'hidden';
	f1.style.visibility = 'hidden';
	window.scrollTo(0, 550);

  }
  
  function submitenter(myfield,e) { 
    var keycode; 
	if (window.event) keycode = window.event.keyCode; 
	else if (e) keycode = e.which; else return true; 
	if (keycode == 13) { 
	document.getElementById("sdata").click(); return false; 
	} 
	  else return true; }
	  
	  function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }

  
  
  
    $(document).ready(function() {
            $("#flip").click(function(event){
              
			 var logo = $("#flip").css('background-image');
             var cleanup = /\"|\'|\)/g;
             
			 if(logo.split('/').pop().replace(cleanup, '') == "up.jpg"){
				$("#flip").css("background-image", "url(down.jpg)");  
			 }
			 else{
				$("#flip").css("background-image", "url(up.jpg)");   
			 }
            });
         });
		  
		 
		 
		 
		 
		 




		 $(document).ready(function(){
    $("#flip").click(function(){
        $("#pantsu,#oppai").slideToggle("slow");
    });
});



 $(document).ready(function(){
    $("#flip").click(function(){
       $("#aa").toggle('slide',{ direction: "right" },400);
    });
});

  
  
  
  
  $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
			 var id = this.id;
			 var f1 = document.getElementById('currentmark').value;
			
			if(id == "tibid" || id == "kursus"){
            
			}
			else{
			if($(this).prop("checked") == true){
				f1 = f1 - 1;
                $('#currentmark').val(f1);   
            }
            else if($(this).prop("checked") == false){
				 f1 = parseInt(f1) + 1;
                 $('#currentmark').val(f1);  
            }	
			}
			currentgrade();
        });
    });
	
	function marks1(){
	var f1 = document.getElementById('a1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddena1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddena1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddena1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddena1').val(f1);
		
	}
	
	currentgrade();
	
	}
  
  
  function marks2(){
	var f1 = document.getElementById('b1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddenb1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddenb1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenb1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenb1').val(f1);
		
	}
	currentgrade();
	
	}
  
  function marks3(){
	var f1 = document.getElementById('c1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddenc1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddenc1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenc1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddenc1').val(f1);
		
	}
	currentgrade();
	
	}
  
  function marks4(){
	var f1 = document.getElementById('g1').value;
	var f2 = document.getElementById('currentmark').value;
	var f3 = document.getElementById('hiddeng1').value;
	
	 
	if(f1 == f3){
		f2 = parseInt(f2) - parseInt(f1);
	    $('#currentmark').val(f2); 
		$('#hiddeng1').val(f1);
		
	}
	else if(f1 > f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddeng1').val(f1);
		
	}
	else if(f1 < f3){
		f2 = parseInt(f2) + parseInt(f3);
		f2 = parseInt(f2) - parseInt(f1);
		$('#currentmark').val(f2);
		$('#hiddeng1').val(f1);
		
	}
	currentgrade();
	
	}
	
	function currentgrade(){
		var f1 = document.getElementById('currentgrade').value;
		var f2 = document.getElementById('hiddena1').value;
		var f3 = document.getElementById('hiddenb1').value;
		var f4 = document.getElementById('hiddenc1').value;
		var f5 = document.getElementById('hiddeng1').value;
		var f6 = document.getElementById('currentmark').value;
		
		if(f6 >= 86 && f6 <= 100){
			if(f2 != 0 || f3 != 0 || f3 != 0){
				$('#currentgrade').val("B");
			}
			else{
				$('#currentgrade').val("A");
			}
			
			
		}
		else if(f6 >= 71 && f6 <= 85){
			$('#currentgrade').val("B");
		}
		else if(f6 >= 51 && f6 <= 70){
			$('#currentgrade').val("C");
		}
		else{
			$('#currentgrade').val("F");
		}
		
		
		
		
		
	}

	
  
  
</script>

<script>
         $(function() {
            $( document ).tooltip();
         });
      </script>
      
       <style>
         label {
            display: inline-block;
            width: 15em;
         }
      </style>



