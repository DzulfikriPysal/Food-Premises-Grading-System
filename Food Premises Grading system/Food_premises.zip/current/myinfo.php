<?php
session_start();
$_SESSION['directory'] = "myinfo.php";
$timeout = 5; // Set timeout minutes
$logout_redirect_url = "sessiontimeout.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        header("Location: $logout_redirect_url");
		
    }
}
$_SESSION['start_time'] = time();

?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$db_host = 'localhost'; // don't forget to change 
$db_user = 'root'; 
$db_pwd = '';

$database = 'premises';
$table = 'user';

if (!mysql_connect($db_host, $db_user, $db_pwd))
    die("Can't connect to database");

if (!mysql_select_db($database))
    die("Can't select database");

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
        if (isset($_FILES['photo']))
        {
            @list(, , $imtype, ) = getimagesize($_FILES['photo']['tmp_name']);
           

            if ($imtype == 3) 
                $ext="png";   
            elseif ($imtype == 2)
                $ext="jpeg";
            elseif ($imtype == 1)
                $ext="gif";
            else
                $msg = 'Error: unknown file format';

            if (!isset($msg)) 
            {
                $data = file_get_contents($_FILES['photo']['tmp_name']);
                $data = mysql_real_escape_string($data);
                
             $lol = $_SESSION["staffid"];
                mysql_query("UPDATE user
                                SET ext='$ext', 
                                    data = '$data' WHERE staffid = '$lol'");

                $msg = 'Success: image uploaded';
            }
		}
}
        
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>
<body>

<div id="header">
<div class="c-buttons">
<br/>



        <button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button>

</div>
<div style="position:absolute; top:-20px; left:280px;">
<h1>FOOD PREMISES GRADING SYSTEM </h1>
</div>
<div style=" position:absolute; left: 280px; top:30px;">
<h3>My Info</h3>
</div>

</div>

<div id="o-wrapper" class="o-wrapper" style="height:200px;">
<div style="width:100%; height:60px; float:left; ">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>


  <main class="o-content" style="background-color:#000;">
   <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:400px;">
    
    
    <?php
	
	if(isset($_POST['change'])){
		?>
		<form method = "post"  action = "updatemyinfo.php">
        <input name="oldpassword" type="text" required placeholder="Old Password">
        <input name="newpassword" type="text" required placeholder="New Password"><br/>
        <input name="change" type="submit" value="change password">
        
        
        </form>
		
		
		
		<?php
	}
	 else if(isset($_POST['update'])){
		?>
		 <img height="200px" width="200px" src="openimage.php"  alt="haha" /><br/>
    <br/>
     <?php
	  error_reporting(E_ALL ^ E_DEPRECATED);
      $hostname_connect = "localhost";
      $database_connect = "premises";
      $username_connect = "root";
      $password_connect = "";
      $connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),      E_USER_ERROR);
	  
	  $id = $_SESSION["staffid"];
	  
	          $query = mysql_query("SELECT * FROM user where staffid = '$id' ") or die(mysql_error());
	          $row = mysql_fetch_array($query);
			
              
	  ?>
      <form method = "post"  action = "updatemyinfo.php">
      <table width="100%" border="0" style=" border-bottom-color:#000;border-collapse: collapse;">
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td style=" text-align:end; width:130px;">Staff name : </td>
    <td style=" text-align:end; width:130px;"><input required type="text" name="staffname" value="<?php   echo $row['staffname']; ?>"></td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
  </tr>
 
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Phone Number : </td>
    <td style=" text-align:end; width:130px;"><input type="text" required onkeypress='return event.charCode >= 48 && event.charCode <= 57' name="phone" value="<?php  echo $row['phonenumber']; ?>"></td>
    <td>&nbsp;</td>
  </tr>
  
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Email : </td>
    <td style=" text-align:end; width:130px;"><input required type="email" name="email" value="<?php echo $row['email'];  ?>"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Address : </td>
    <td style="text-align:end;  "><br/><textarea name="address" required type="text" style="width:200px;  ;" ><?php echo $row['address'];  ?></textarea></td>
    <td>&nbsp;</td>
  </tr>
   <tr>
  <td>&nbsp;</td>
    <td>
    
    <input name="save" type="submit" value="Save">
    </form></td>
    <td></td>
    <td>&nbsp;</td>
  </tr>
</table>

      
		<?php
	}
	else{
	
	?>
      <img height="200px" width="200px" src="openimage.php"  alt="haha" /><br/>
  
<form action="<?php $_PHP_SELF ?>" method="POST" enctype="multipart/form-data">

<input type="file" name="photo" id="photo">
<input type="submit" value="Chnage profile picture">
</form>
    <br/>
    <?php
	  error_reporting(E_ALL ^ E_DEPRECATED);
      $hostname_connect = "localhost";
      $database_connect = "premises";
      $username_connect = "root";
      $password_connect = "";
      $connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),      E_USER_ERROR);
	  
	          $id = $_SESSION["staffid"];
	  
	          $query = mysql_query("SELECT * FROM user where staffid = '$id' ") or die(mysql_error());
	          $row = mysql_fetch_array($query);
			  
			  
			  
			  
			
              
	  ?>
      <table width="100%" border="0" style=" border-bottom-color:#000;border-collapse: collapse;">
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td style=" text-align:end; width:130px;">Staff name : </td>
    <td style=" text-align:end; width:130px;"><?php   echo $row['staffname']; ?></td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Staff ID : </td>
    <td style=" text-align:end; width:130px;"><?php echo $row['staffid'];  ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Phone Number : </td>
    <td style=" text-align:end; width:130px;"><?php  echo $row['phonenumber']; ?></td>
    <td>&nbsp;</td>
  </tr>
 
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Email : </td>
    <td style=" text-align:end; width:130px;"><?php echo $row['email'];  ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
    <td style=" text-align:end;">Address : </td>
    <td style="text-align:end;  "><br/><textarea style="width:200px; text-align:start;" readonly><?php echo $row['address'];  ?></textarea></td>
    <td>&nbsp;</td>
  </tr>
   <tr>
  <td>&nbsp;</td>
    <td>
    <form method = "post"  action = "myinfo.php">
    <input name="update" type="submit" value="Update">
    </td>
    <td><input name="change" type="submit" value="change password">
    </form></td>
    <td>&nbsp;</td>
  </tr>
</table>

      
      
	  <?php
	  
	  mysql_close($connect);
	}
	?>
    
    
    </div><!-- /o-container -->
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           
           </div>
             <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   ?>
            
            </div>
           
            <div class="mid">
            
             <button class="menubutton" id="homepage" type="button" onclick="" >Home page</button>
           
            <script type="text/javascript">
            document.getElementById("homepage").onclick = function () {
            location.href = "adminhomepage.php";
            };
	        </script>
           <button class="menubutton" id="menubutton" type="button" onclick="" >User Management</button>
           
            <script type="text/javascript">
            document.getElementById("menubutton").onclick = function () {
            location.href = "usermodule.php";
            };
	        </script>
            
           <button class="reportbutton" id="reportbutton" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("reportbutton").onclick = function () {
            location.href = "searchform.php";
            };
	        </script>

          <button class="reportbutton" id="notice" type="button" onclick="">Notice</button>
          <script type="text/javascript">
            document.getElementById("notice").onclick = function () {
            location.href = "notice.php";
            };
          </script>
            
            
            <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="logout">
            </form>
            
            
           <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
           
           
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
 
  
 

</script>

</body>
</html>