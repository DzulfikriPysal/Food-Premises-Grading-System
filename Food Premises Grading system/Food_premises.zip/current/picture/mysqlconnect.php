<HTML>
<HEAD>
<TITLE>List BLOB Images</TITLE>
<link href="imageStyles.css" rel="stylesheet" type="text/css" />
</HEAD>
<BODY>


<img height="50px" width="50px" src="saveimage.php?show= 5"  alt="haha" /><br/>

</BODY>
</HTML>