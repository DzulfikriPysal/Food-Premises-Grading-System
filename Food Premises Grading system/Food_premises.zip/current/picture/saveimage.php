<?php
session_start();

?>
<?php
header('Content-type: image/jpg');
error_reporting(E_ALL ^ E_DEPRECATED);
  $id = $_GET['show'];
  // do some validation here to ensure id is safe

  $link = mysql_connect("localhost", "root", "");
  mysql_select_db("shahrukh");
  $sql = "SELECT data FROM ae_gallery WHERE id=$id";
  $result = mysql_query("$sql");
  $row = mysql_fetch_assoc($result);
  mysql_close($link);
  
    echo $row['data'] . "<br /><br /><br /><br /><br /><br /><br /><br /><br />";
	
	
?>