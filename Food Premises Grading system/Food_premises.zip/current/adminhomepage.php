<?php
session_start();
if (isset($_SESSION['staffid'])) {
	$_SESSION['directory'] = "adminhomepage.php";
$timeout = 5; // Set timeout minutes
$logout_redirect_url = "sessiontimeout.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
	
	
    if ($elapsed_time >= $timeout) {
	
        header("Location: $logout_redirect_url");
		
    }
	else{
		
		$_SESSION['start_time'] = time();
		
	}
}
else{
	
$_SESSION['start_time'] = time();	
}
}
else{
	header("Location: homepage.php");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>
<body>

<div id="header">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px; "> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px; ">Homepage</td>
  </tr>
</table>






</div>

<div id="o-wrapper" class="o-wrapper">
<div style="width:100%; height:60px; float:left; ">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>


  <main class="o-content" style="background-color:#000;">
    <div class="o-container"> </div><!-- /o-container -->
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           
           </div>
             <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   ?>
            
            </div>
           
            <div class="mid">
           <button class="menubutton" id="menubutton" type="button" onclick="" >User Management</button>
           
            <script type="text/javascript">
            document.getElementById("menubutton").onclick = function () {
            location.href = "usermodule.php";
            };
	        </script>
            
           <button class="reportbutton" id="reportbutton" type="button" onclick="">Report Management</button>
           
            <script type="text/javascript">
            document.getElementById("reportbutton").onclick = function () {
            location.href = "searchform.php";
            };
	        </script>
            <button class="reportbutton" id="myinfo" type="button" onclick="">myinfo</button>
           
            <script type="text/javascript">
            document.getElementById("myinfo").onclick = function () {
            location.href = "myinfo.php";
            };
	        </script>

          <button class="reportbutton" id="notice" type="button" onclick="">Notice</button>
          <script type="text/javascript">
            document.getElementById("notice").onclick = function () {
            location.href = "notice.php";
            };
          </script>
            
            
              <form method="post" action="logout.php">
            <input class="logoutbutton" type="submit" onClick="return logout();" value="logout">
            </form>
            
            
           <script type="text/javascript">
           function logout() {
           var result = confirm("Are you sure to log out?");
	           if(result){
          return true;
	           }else{
		          return false;
	           }
            };
	        </script>
           
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  
 
  
 

</script>

</body>
</html>