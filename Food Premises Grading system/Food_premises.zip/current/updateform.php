<?php
error_reporting(E_ALL ^ E_DEPRECATED);
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>

 <style>
  body {
  padding:1em;
  background: #fff;
  height:300px
  
}

table {
  border: px #fff solid;
  font-size: .9em;
  box-shadow: 0 0px 0px rgba(0,0,0,.25);
  width: 100%;
  border-collapse: collapse;
  border-radius: 0px;
 
}

th {
  text-align: left;
}
  
thead {
  font-weight: bold;
  color: #fff;
  background: #039BE5;
}
  
 td, th {
  padding: .2em .5em;
  vertical-align: middle;
}
  
 td {
  border-bottom: 0px solid rgba(0,0,0,.1);
  background: #fff;
  height:45px;
}

a {
  color: #ff
  ;
}
  
 
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
  th {
    text-align: right;
	height:45px;
  }
  
  table {
    position: relative; 
    padding-bottom: 0;
    border: none;
    box-shadow: 0 0 5px rgba(0,0,0,.2);
  }
  
  thead {
    float: left;
    white-space: nowrap;
  }
  
  tbody {
    
    position: relative;
    white-space: nowrap;
  }
  
  tr {
    display: inline-block;
    vertical-align: top;
  }
  
  
  
</style>
    

<body>


<form name="updateform" method = "post" action = "<?php $_PHP_SELF ?>" >
    <table>
    <thead>
    <tr>
        <th>Staff Name :</th>
        <th>Phone Number :</th>
        <th>Email :</th>
        <th>Address :</th>
        <th></th>
        

    </tr>
    </thead>
    
    <tbody>
    <tr>
        <td> <?php
						   
		 echo "<input name=\"staffname\" type=\"text\" id=\"textbox\" required size=\"30\" value=\"" . $_SESSION['update2'] . "\">";
						   ?></td>
        <td> <?php
						   
		 echo "<input name=\"password\" type=\"hidden\" id=\"textbox\" required minlength=\"10\" maxlength=\"20\" size=\"30\" value=\"" . $_SESSION["update3"] . "\">";
						   ?>
                             <?php
						   
		 echo "<input name=\"staffid\" type=\"hidden\" id=\"textbox\" size=\"30\" value=\"" . $_SESSION["update"] . "\">";
						   ?>
                           
                           
                           <?php
							 
				
						   
		 echo "<input name=\"phone\" type=\"text\"
		 
		 onkeypress=\"return event.charCode >= 48 && event.charCode <= 57\"
		 
		 type=\"number\" id=\"textbox\" required minlength=\"10\" maxlength=\"20\"  value=\"" . $_SESSION["update4"] . "\">";
						   ?>
                           
                           </td>
        
        <td><?php
						   
		 echo "<input name=\"email\" type=\"email\" id=\"textbox\" required size=\"30\" value=\"" . $_SESSION['update8'] . "\">";
						   ?></td>
        <td><?php
						   
		 echo "<textarea  cols=\"40\" rows=\"3\" name=\"address\" required>". $_SESSION['update9'] ."</textarea> ";
						   ?></td>
                           <th></th>
         
       
    </tr>
    </tbody>
</table>
<br/>

 <input name = "add" type = "submit"   id = "click"   value = "Update" >
 <input  type = "button"   id = "click"    value = "Close"  onclick="closepopup();">
 
 
               </form>
              
           
        
       
               
                <?php
 error_reporting(E_ALL ^ E_DEPRECATED);

# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connect = "localhost";
$database_connect = "premises";
$username_connect = "root";
$password_connect = "";
$connect = mysql_pconnect($hostname_connect, $username_connect, $password_connect) or trigger_error(mysql_error(),E_USER_ERROR);
         
		 if(isset($_POST["add"])){
			  $idDelete = $_SESSION["update"];
			 
              $name1 = $_POST['staffname'];
              $id1 = $_POST['staffid'];
			  $pass1 = $_POST['password'];
              $phone1 = $_POST['phone'];  
			  $address = $_POST['address'];
			  $email = $_POST['email'];
			  $mode = $_SESSION["update6"];
			  $dc = $_SESSION["update5"];
			  $adminnamecreate = $_SESSION['update7'];
			  
			  $_SESSION["update"] = $id1;
			  $_SESSION["update2"] = $name1;
			  $_SESSION["update3"] = $pass1;
			  $_SESSION["update4"] = $phone1;
			  $_SESSION["update9"] = $address;
			  $_SESSION["update8"] = $email;
			  
			  
			  $adminname = $_SESSION['staffid'];
			  
              
              date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i:s.u");
			  
			   $sql = "UPDATE user ". "SET  staffname = '$name1',staffid = '$id1',phonenumber = '$phone1',lastedit = '$a',editby = '$adminname',address = '$address',email = '$email'". 
               "WHERE staffid = '$id1'" ;
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $connect );
			  mysql_close($connect);
			  
			  
	
   
		 }
		
		 
		    
   
     function refresh(){
			 
			$page = $_SERVER['PHP_SELF'];
            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
			 
		 }
		 
		 if(isset($_POST['add']))
          {
	      refresh();
          }
  
		
?>

<script>
function closepopup(){
	parent.guestFromPop();
}

</script>
   
</body>
</html>


