<?php
session_start();
if (isset($_SESSION['staffid'])) {
  $_SESSION['directory'] = "addnews.php";
$timeout = 5; // Set timeout minutes
$logout_redirect_url = "sessiontimeout.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
  
  
    if ($elapsed_time >= $timeout) {
  
        header("Location: $logout_redirect_url");
    
    }
  else{
    
    $_SESSION['start_time'] = time();
    
  }
}
else{
  
$_SESSION['start_time'] = time(); 
}
}
else{
  header("Location: homepage.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>
<body>


<div id="header" style=" height:100px; ">
<table width="350px"  border="0" style="float:left; text-align:center;" height="100%">
  <tr>
    <td><button id="c-button--slide-left" class="c-button"><span>&#9776;&nbsp;&nbsp;Menu </span></button></td>
    
  </tr>
</table>

<table  border="0" style="float:left; border-collapse:collapse;">
  <tr>
   <td style=" font-size:36px;color:#FFF;"> FOOD PREMISES GRADING SYSTEM</td>
  </tr>
   <tr>
    <td style=" font-size:19px;  "></td>
  </tr>
</table>

<form name="myform12"  method = "post" action = "notice.php">
                
  <input name = "searchid12" type = "hidden" 
                           id = "textbox" required >
                           
                    
                           <input name = "search12" type = "hidden" id="search12"
                              value = "Search" style="background-color:#ffc107; color:#FFF; border:none" >
               </form>
</div>

<div id="o-wrapper" class="o-wrapper">
<div style="width:100%; height:60px; float:left text-align:center;">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
  
<div class="alert alert-success" style="text-align:center; height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>

  <main class="o-content" style="height:400px;">
      <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">
    

      <form method = "post" action = "<?php $_PHP_SELF ?>">

        <table width="100%" border="1" style="text-align:left; border-collapse: collapse;">
          <tr>
              <td>
                Title
              </td>
              <td>
                <input id="title" name="title" type="text" />
              </td>
          </tr>
        </table>

        <table width="100%" border="1" style="text-align:left; border-collapse: collapse;">
          <tr>
              <td style="width:100%">
                <text>News or Notice</text>
              </td>
          </tr>
          <tr>
              <td style="width:100%">
                <textarea id ="news" cols="128" rows="10" name="news" maxlength="10000"></textarea>
              </td>
          </tr>
        </table>
        <input name="submit" type="submit" value="Submit"/>
        <input type="button" onClick="return new_news();" value="Cancel" />
      </form>


     <?php
  if(isset($_POST['submit'])){
      $_SESSION['success_msg'] = "Successfully add new Notice";
      header("Location: notice.php");

      $dbHost = 'localhost';
      $dbUser = 'root';
      $dbPass = '';
      $dbName = 'premises';
      $conn = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);

      $title = $_POST['title'];
      $news = $_POST['news'];
      $date = $_POST['title'];

      

       mysqli_query($conn,"INSERT INTO notice (title,notice,datez) VALUES ('$title','$news','$date')");


    }
?>


    </div><!-- /o-container -->
  </main><!-- /o-content -->

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <div class="top" style="background-image:url(A.PNG)">
           </div>
           
            <div class="mid" style="top:165px;">
            
            <div class="login-screen">
			<div class="app-title">
				<h1 style="color:#FFF">Login</h1>
			</div>

			<div class="login-form">
           
             <form class="loginform" method="POST" action="connectivity.php" > 
                 <div class="control-group">
				      <input id="login-field" id="login-name" type="text" name="user" size="25" required="required" placeholder="Staff ID">
				</div>
                     <input id="login-field" id="login-name" type="password" name="pass" size="25" required="required" minlength="10" maxlength="20" placeholder="Password">
				<div class="control-group">
				
				</div>
              
                 <input id="btnlogin" type="submit" name="submit" value="Log-In">
				<a class="login-link" href="resetpassword.php" style="color:#FFF">Lost your password?</a>
          </form>
         
      
          </div>
          </div>
          
          
          
           <button id="c-menu__close" class="c-menu__close">&larr; Close Menu</button>
           </div>
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });
  

 function new_news(clicked_id)
{
   
  document.myform12.searchid12.value = clicked_id;
  document.forms["myform12"].submit();
  document.getElementById("search12").click();
  
}
  
  

</script>


</script>

</body>
</html>