<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST', 'localhost');
define('DB_NAME', 'premises');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());


		 if(isset($_POST["search"])){
			 
              $id1 = $_POST['searchid'];
			$query = mysql_query("SELECT * FROM user where staffid = '$_POST[searchid]' ") or die(   mysql_error());
	        $row = mysql_fetch_array($query);
			
			 $_SESSION['update']  = $row['staffid'];
		     $_SESSION['update2'] = $row['staffname'];
			 $_SESSION['update3'] = $row['Password'];
		     $_SESSION['update4'] = $row['phonenumber'];
			 $_SESSION['update5'] = $row['datecreated'];
			 $_SESSION['update6'] = $row['mode'];
			 $_SESSION['update7'] = $row['adminnamecreate'];
			 $_SESSION['update8'] = $row['email'];
			 $_SESSION['update9'] = $row['address'];
			 
			 
	        if(!empty($row['staffid']) )
	        {
				 header("Location: updateform.php");
	     
		      
			   
			}else{
				
				 echo "ID didnt exist";
				
			}

    
    

  
		 }
		 
		 
		 mysql_close($con);

?>