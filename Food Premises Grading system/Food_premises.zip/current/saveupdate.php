<?php

		$_SESSION['success_msg'] = "Successfully Update";
	
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>FOOD PREMISES GRADING SYSTEM</title>
  <meta name="description" content="Some slide and push menu demos using CSS3 transitions.">
  <link rel="stylesheet" href="css.css">
  <link rel="stylesheet" href="css2.css">
  <link rel="stylesheet" href="css3.css">
</head>
<body>

<div id="header">
<div class="c-buttons">
<br/>

        <button id="c-button--slide-left" class="c-button"><span>Menu </span></button>

</div>
<div style="position:absolute; top:-20px; left:280px;">
<h1>FOOD PREMISES GRADING SYSTEM </h1>
</div>
<div style=" position:absolute; left: 280px; top:30px;">
<h3>Record</h3>
</div>

</div>

<div id="o-wrapper" class="o-wrapper" style="height:200px;">
<div style="width:100%; height:60px; float:left">
  <?php  if(!empty($_SESSION['success_msg'])){ ?>
<div class="alert alert-success" style="height:60px;"><?php echo $_SESSION['success_msg']; ?></div>
<?php unset($_SESSION['success_msg']); } ?>
  </div>


  <main class="o-content" style="height:200px;">
  <div class="dummy1"><h1></h1></div>
    <div class="o-container" style="height:200px;">
<?php
session_start();

if(isset($_POST['add']) )
{
	       
           error_reporting(E_ALL ^ E_DEPRECATED);
           define('DB_HOST', 'localhost');
           define('DB_NAME', 'premises');
           define('DB_USER','root');
           define('DB_PASSWORD','');

           $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
           $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
            
            if(! $con ) {
               die('Could not connect: ' . mysql_error());
            }
			
			
    $ta1 = $_POST['ta1'];
	$ta2 = $_POST['ta2'];
	$ta3 = $_POST['ta3'];
	$ta4 = $_POST['ta4'];
	$ta5 = $_POST['ta5'];
	$tb1 = $_POST['tb1'];
	$tb2 = $_POST['tb2'];
	$tb3 = $_POST['tb3'];
	$tb4 = $_POST['tb4'];
	$tc1 = $_POST['tc1'];
	$tc2 = $_POST['tc2'];
	$td1 = $_POST['td1'];
	$td2 = $_POST['td2'];
	$td3 = $_POST['td3'];
	$te1 = $_POST['te1'];
	$te2 = $_POST['te2'];
	$te3 = $_POST['te3'];
	$tf1 = $_POST['tf1'];
	$tf2 = $_POST['tf2'];
	$tf3 = $_POST['tf3'];
	$tf4 = $_POST['tf4'];
	$tg1 = $_POST['tg1'];
	$tg2 = $_POST['tg2'];
	$tg3 = $_POST['tg3'];
	$tg4 = $_POST['tg4'];
	$tg5 = $_POST['tg5'];
	$tg6 = $_POST['tg6'];
	$tg7 = $_POST['tg7'];
	$tg8 = $_POST['tg8'];
	
	$bilpengendali = $_POST['bilpengendali'];  
	$tibid = $_POST['tibid']; 
	$kursus = $_POST['kursus'];
	
	$a1 = $_POST['a1'];
	$a21 = $_POST['a2_1'];
	$a22 = $_POST['a2_2'];
	$a23 = $_POST['a2_3'];
	$a24 = $_POST['a2_4'];
	$a31 = $_POST['a3_1'];
	$a32 = $_POST['a3_2'];
	$a33 = $_POST['a3_3'];
	$a41 = $_POST['a4_1'];
	$a42 = $_POST['a4_2'];
	$a43 = $_POST['a4_3'];
	$a51 = $_POST['a5_1'];
	$a52 = $_POST['a5_2'];
	$a61 = $_POST['a6_1'];
	$totala = ($a1 + $a21) + ($a22 + $a23) +($a24 + $a31) + ($a32 + $a33) + ($a41 + $a42) + ($a43 + $a51) + ($a52 + $a61);
	
	$b1 = $_POST['b1'];
	$b21 = $_POST['b2_1'];
	$b22 = $_POST['b2_2'];
	$b31 = $_POST['b3_1'];
	$b32 = $_POST['b3_2'];
	$b41 = $_POST['b4_1'];
	$b42 = $_POST['b4_2'];
	$totalb = ($b1 + $b21) + ($b22 + $b31) +($b32 + $b41) + $b42;
	
	$c1 = $_POST['c1'];
	$c21 = $_POST['c2_1'];
	$c22 = $_POST['c2_2'];
	$c23 = $_POST['c2_3'];
	$c24 = $_POST['c2_4'];
	$c25 = $_POST['c2_5'];
	$c26 = $_POST['c2_6'];
	$c31 = $_POST['c3_1'];
	$totalc = ($c1 + $c21) + ($c22 + $c23) +($c24 + $c25) + ($c26 + $c31);
	
	$d11 = $_POST['d1_1'];
	$d12 = $_POST['d1_2'];
	$d21 = $_POST['d2_1'];
	$d22 = $_POST['d2_2'];
	$d31 = $_POST['d3_1'];
	$totald = ($d11 + $d12) + ($d21 + $d22) + $d31;
	
	$e11 = $_POST['e1_1'];
	$e12 = $_POST['e1_2'];
	$e13 = $_POST['e1_3'];
	$e14 = $_POST['e1_4'];
	$e15 = $_POST['e1_5'];
	$e16 = $_POST['e1_6'];
	$e21 = $_POST['e2_1'];
	$e22 = $_POST['e2_2'];
	$e23 = $_POST['e2_3'];
	$e31 = $_POST['e3_1'];
	$e32 = $_POST['e3_2'];
	$e33 = $_POST['e3_3'];
	$totale = ($e11 + $e12) + ($e13 + $e14) + ($e15 + $e16) + ($e21 + $e22) + ($e23 + $e31) + ($e32 + $e33);
	
	$f11 = $_POST['f1_1'];
	$f12 = $_POST['f1_2'];
	$f13 = $_POST['f1_3'];
	$f14 = $_POST['f1_4'];
	$f15 = $_POST['f1_5'];
	$f21 = $_POST['f2_1'];
	$f22 = $_POST['f2_2'];
	$f31 = $_POST['f3_1'];
	$f32 = $_POST['f3_2'];
    $f41 = $_POST['f4_1'];
    $f42 = $_POST['f4_2'];
	$totalf = ($f11 + $f12) + ($f13 + $f14) + ($f15 + $f21) + ($f22 + $f31) + ($f32 + $f41) + $f42;
	
	$g1 = $_POST['g1'];
	$g2 = $_POST['g2'];
	$g3 = $_POST['g3'];
	$g41 = $_POST['g4_1'];
	$g42 = $_POST['g4_2'];
	$g43 = $_POST['g4_3'];
	$g5 = $_POST['g5'];
	$g6 = $_POST['g6'];
	$g7 = $_POST['g7'];
	$g81 = $_POST['g8_1'];
	$g82 = $_POST['g8_2'];
	$g83 = $_POST['g8_3'];
	$totalg = ($g1 + $g2) + ($g3 + $g41) + ($g42 + $g43) + ($g5 + $g6) + ($g7 + $g81) + ($g82 + $g83);
	
	
	$total = $_POST['currentmark']; 
	
	
	$nosiriborang = $_POST['nosiriborang'];
	$pelesen = $_POST['ownername'];
	$refno = $_POST['refno'];
    $companyname = $_POST['companyname'];
	$date = $_POST['date'];
	$phone = $_POST['phone'];
	$start = $_POST['tstart'];
	$end = $_POST['tend'];
	$ownerlicence = $_POST['ownerlicence'];
    $address = $_POST['address'];
	$newdate = explode('-', $date);
	$year = $newdate[2];
    $month = $newdate[1];
	$grade = $_POST['currentgrade'];
	
	
	          date_default_timezone_set("Asia/Singapore");
              $t = microtime(true); 
              $micro = sprintf("%06d",($t - floor($t)) * 1000000);
              $d = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );

              $a =  $d->format("Y-m-d H:i:s.u");
			  $id = $_SESSION["staffid"];
			
			
			   $sql = "UPDATE premisesdetail ". "SET nosiriborang = '$nosiriborang', namasyarikat = '$companyname', alamatpremis = '$address', nokppelesen = '$ownerlicence', tarikh = '$date', masamula = '$start', masatamat = '$end', totala = '$totala', totalb = '$totalb', totalc = '$totalc', totald = '$totald', totale = '$totale', totalf = '$totalf', totalg = '$totalg', a1 = '$a1', a2_1 = '$a21', a2_2 = '$a22', a2_3 = '$a23', a2_4 = '$a24', a3_1 = '$a31', a3_2 = '$a32', a3_3 = '$a33', a4_1 = '$a41', a4_2 = '$a42', a4_3 = '$a43', a5_1 = '$a51', a5_2 = '$a52', a6 = '$a61', b1_1 = '$b1', b2_1 = '$b21', b2_2 = '$b22', b3_1 = '$b31', b3_2 = '$b32', b4_1 = '$b41', b4_2 = '$b42', c1_1 = '$c1', c2_1 = '$c21', c2_2 = '$c22', c2_3 = '$c23', c2_4 = '$c24', c2_5 = '$c25', c2_6 = '$c26', c3 = '$c31', d1_1 = '$d11', d1_2 = '$d12', d2_1 = '$d21', d2_2 = '$d22', d3 = '$d31', e1_1 = '$e11', e1_2 = '$e12', e1_3 = '$e13', e1_4 = '$e14', e1_5 = '$e15', e1_6 = '$e16', e2_1 = '$e21', e2_2 = '$e22', e2_3 = '$e23', e3_1 = '$e31', e3_2 = '$e32', e3_3 = '$e33', f1_1 = '$f11', f1_2 = '$f12', f1_3 = '$f13', f1_4 = '$f14', f1_5 = '$f15', f2_1 = '$f21', f2_2 = '$f22', f3_1 = '$f31', f3_2 = '$f32', f4_1 = '$f41', f4_2 = '$f42', g1 = '$g1', g2 = '$g2', g3 = '$g3', g4_1 = '$g41', g4_2 = '$g42', g4_3 = '$g43', g5 = '$g5', g6 = '$g6', g7 = '$g7', g8_1 = '$g81', g8_2 = '$g82', g8_3 = '$g83', bilpengendali = '$bilpengendali', suntikanpelali = '$tibid', kursuspengendali = '$kursus', lastupdate = '$a', updateby = '$id', ta1 = '$ta1', ta2 = '$ta2', ta3 = '$ta3', ta4 = '$ta4', ta5 = '$ta5', tb1 = '$tb1', tb2 = '$tb2', tb3 = '$tb3', tb4 = '$tb4', tc1 = '$tc1', tc2 = '$tc2', td1 = '$td1', td2 = '$td2', td3 = '$td3', te1 = '$te1', te2 = '$te2', te3 = '$te3', tf1 = '$tf1', tf2 = '$tf2', tf3 = '$tf3', tf4 = '$tf4', tg1 = '$tg1', tg2 = '$tg2', tg3 = '$tg3', tg4 = '$tg4', tg5 = '$tg5', tg6 = '$tg6', tg7 = '$tg7', tg8 = '$tg8', Month = '$month', Year = '$year', grade = '$grade'". 
               "WHERE nosiriborang = '$nosiriborang'" ;
			   
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $con );
			   
			   mysql_close($con);
}

?>
  <table width="90%" border="0">
  <tr>
    <td style="text-align:start;">Serial Number</td>
    <td><input id="boxx" name="nosiriborang"  readonly type="text" value="<?php echo $nosiriborang ?>"></td>
   
  </tr>
  <tr>
    <td style="text-align:start;">Owner Name</td>
    <td><input id="boxx" type="text" name="ownername" readonly value='<?php echo $pelesen; ?>' ></td>
    <td style="text-align:start;">Licence Reference No</td>
    <td><input id="boxx" type="text"name="refno" value="<?php echo $refno ?>" readonly></td>
  </tr>
  <tr>
    <td style="text-align:start;">Company Name</td>
    <td><input id="boxx" type="text" name="companyname"  readonly value='<?php echo $companyname ?>'></td>
    <td style="text-align:start;">Date</td>
    <td><input id="boxx" type="text" name="date"  value="<?php echo $date ?>" readonly></td>
  </tr> 
 
  <tr>
    <td style="text-align:start;">Phone Number</td>
    <td><input id="boxx" type="text" name="phone" readonly value='<?php echo $phone ?>'>
   </td>
    <td style="text-align:start;">Time</td>
    <td style="text-align:start;"><input id="boxx" type="text" style="width: 100px;" value="<?php echo $start ?>" placeholder="Start" name="tstart"  readonly> -<input type="text" placeholder="End" style="width: 100px;" name="tend" value="<?php echo $end ?>" id="boxx" readonly></td>
  </tr>
  <tr>
 
    <td style="text-align:start;">Owner Licence No</td>
    <td><input type="text" id="boxx" name="ownerlicence"  readonly value='<?php echo $ownerlicence?>'></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="text-align:start;">Address</td>
    <td><textarea  cols="25" id="boxx" rows="4" name="address" readonly><?php echo $address ?></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td style="text-align:start;">Pengendali</td>
    <td >Bil Pengendali&nbsp;&nbsp;&nbsp;<input type="text" style="width:50px; text-align:center;" id="boxx" name="bilpengendali"  readonly value='<?php echo $bilpengendali ?>'></td> <td>
        <input type="hidden" value="0" name="tibid">
        Suntikan pelalian ANTI Tibid<input value="1" type="checkbox" onclick="return false" name="tibid" <?php echo ($tibid==1 ? 'checked' : '');?>>
        
        
    </td>
    <td>
        <input type="hidden" value="0" name="kursus">
        Kursus pengendali makanan<input value="1" type="checkbox"  name="kursus" onclick="return false" <?php echo ($kursus==1 ? 'checked' : '');?>>
    </td>
  </tr>
 
</table>

<table width="40%" border="0">
  <tr>
    <td width="80px" style="text-align:center"> Mark :</td>
    <td width="20px"><input type="text" style="width:50px; text-align:center;" id="boxx" name="bilpengendali"  readonly value='<?php echo $total; ?>'></td>
    <td><input id="sdata" style="width:170px;" type="button" value="Back to Grading page">   <script type="text/javascript">
            document.getElementById("sdata").onclick = function () {
           location.href = "addreport.php";
            };
	        </script></td>
  </tr>
  <tr>
    <td width="80px" style="text-align:center">Grade :</td>
    <td width="20px"><input type="text" style="width:50px; text-align:center;" id="boxx" name="bilpengendali"  readonly value='<?php echo $grade; ?>'></td>
  </tr>
</table>

    
    


</div><!-- /o-container -->
<div class="dummy2"> 


</div>
  </main><!-- /o-content -->

  

</div><!-- /o-wrapper -->

<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
          <div class="top">
          
           
           </div>
           
            
           <div class="c2">
           </div>
            <div class="c1">
             <?php
		      echo "USER : ".$_SESSION["staffid"];
			  echo "<br/>MODE : ";
			  
			  	  if($_SESSION["mode"] == 2){
		              echo " USER ";
	              }
	              else{
		              echo " Admin ";
	              }
				  
				  echo "<br/> Last seen : ".$_SESSION['lastseen']."";
		   
		   ?>
            
            </div>
            
           
           
           
            <div class="mid">
             <button class="addrecord" id="addrecord1" type="button" onclick="" >Home Page</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord1").onclick = function () {
            location.href = "userhomepage.php";
            };
	        </script>
            
           <button class="addrecord" id="addrecord" type="button" onclick="" >GRADING MODULE</button>
           
            <script type="text/javascript">
            document.getElementById("addrecord").onclick = function () {
            location.href = "addreport.php";
            };
	        </script>
            
           <button class="viewrecord" id="viewrecord" type="button" onclick="">VIEW REPORD</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "viewrecord.php";
            };
	        </script>
            
            
             <button class="viewrecord" id="viewrecord" type="button" onclick="">MY INFO</button>
           
            <script type="text/javascript">
            document.getElementById("viewrecord").onclick = function () {
            location.href = "myinfo.php";
            };
	        </script>
            
           
            
              <button class="logoutbutton" id="logoutbutton" type="button" onclick="">LOGOUT BUTTON</button>
           
            <script type="text/javascript">
            document.getElementById("logoutbutton").onclick = function () {
            location.href = "homepage.php";
            };
	        </script>
            
            
            
           <button class="c-menu__close" id="c-menu__close" type="button" onclick="">Close Menu</button>
           
            
            
            
           </div>
           
           
          
  
  
</nav><!-- /c-menu slide-left -->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<!-- menus script -->
<script src="js2.js"></script>
<script>
  
  /**
   * Slide left instantiation and action.
   */
  var slideLeft = new Menu({
    wrapper: '#o-wrapper',
    type: 'slide-left',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var slideLeftBtn = document.querySelector('#c-button--slide-left');
  
  slideLeftBtn.addEventListener('click', function(e) {
    e.preventDefault;
    slideLeft.open();
  });

</script>

</body>
</html>


