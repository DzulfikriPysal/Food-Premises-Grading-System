<?php
session_start();
	if(isset($_POST['save'])){
           error_reporting(E_ALL ^ E_DEPRECATED);
           define('DB_HOST', 'localhost');
           define('DB_NAME', 'premises');
           define('DB_USER','root');
           define('DB_PASSWORD','');

           $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
           $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
            
            if(! $con ) {
               die('Could not connect: ' . mysql_error());
            }
            
             
			  $id = $_SESSION["staffid"];
			  $staffname = $_POST['staffname'];
			  $phone = $_POST['phone'];
			  $email = $_POST['email'];
			  $address = $_POST['address'];
			  
			  
              
               $sql = "UPDATE user ". "SET staffname = '$staffname' , phonenumber = '$phone' ,email = '$email' ,address = '$address'  ". 
               "WHERE staffid = '$id'" ;
               mysql_select_db('premises');
               $retval = mysql_query( $sql, $con );
			   
			   mysql_close($con);
			   header("Location: myinfo.php");
				  }
				  
				  else if(isset($_POST['change'])){
					  error_reporting(E_ALL ^ E_DEPRECATED);
                      define('DB_HOST', 'localhost');
                      define('DB_NAME', 'premises');
                      define('DB_USER','root');
                      define('DB_PASSWORD','');

                      $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());
                      $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
            
            if(! $con ) {
               die('Could not connect: ' . mysql_error());
            }
					  $id = $_SESSION["staffid"];
					  
					  $oldpass = $_POST['oldpassword'];
					  $newpass = $_POST['newpassword'];
					  
					  $oldpass = hash("sha512", $oldpass);
					  $newpass = hash("sha512", $newpass);
					  
					  
					  $query = mysql_query("SELECT Password FROM user where staffid = '$id' ") or die(   mysql_error());
	                  $row = mysql_fetch_array($query);
					  
					  if($oldpass == $row['Password']){
                      $sql = "UPDATE user ". "SET Password = '$newpass' ". 
                        "WHERE staffid = '$id'" ;
                         mysql_select_db('premises');
                         $retval = mysql_query( $sql, $con );
			   
			             
						  $_SESSION['success_msg'] = "Successfully update password";
					  }else{
						  $_SESSION['success_msg'] = "Old Password not same with in the database";
					  }
					  
					  
					  
					  
					   mysql_close($con);

					  header("Location: myinfo.php");
				  }
				 
?>
      